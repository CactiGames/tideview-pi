"""Settings, laid out like the Android app's settings page."""

import time

from .. import system, updates
from ..rating import rate_surf
from ..settings import NIGHT_MODES, ORIENTATIONS, REFRESH_CHOICES
from ..version import VERSION
from .display import format_clock
from .frame import FrameEditor, format_length
from .lists import ConfirmButton, ListScreen, RegionPicker, row

NIGHT_LABELS = {"off": "Off", "dim": "Dim the picture", "black": "Black picture", "screenOff": "Turn the screen off"}
ORIENTATION_LABELS = {"upright": "Upright", "sideways": "Sideways", "upright-flipped": "Upright, turned over",
                      "sideways-flipped": "Sideways, turned over"}


def _interval(m):
    return "%d minutes" % m if m < 60 else ("1 hour" if m == 60 else "%d hours" % (m // 60))


def _pct(v):
    return "%d%%" % int(round(v * 100))


class SettingsScreen(ListScreen):
    title = "TideView settings"

    def __init__(self, app):
        super().__init__(app)
        self._pi_info = None
        self._pi_info_at = 0
        self._updates = None
        self._updates_at = 0
        self._asked_at = 0  # when "Check for updates now" was tapped
        self.shutdown = ConfirmButton("Shut down the Pi", "Tap again to shut down", self._do_shutdown)
        self.restart = ConfirmButton("Restart TideView", "Tap again to restart", app.request_restart)

    def _cycle(self, key, choices):
        s = self.app.settings
        cur = s[key]
        i = choices.index(cur) if cur in choices else -1
        s.set(**{key: choices[(i + 1) % len(choices)]})

    def _toggle(self, key):
        self.app.settings.set(**{key: not self.app.settings[key]})

    def _step_time(self, key, minutes):
        s = self.app.settings
        s.set(**{key: (s[key] + minutes) % (24 * 60)})

    def _step(self, key, delta, lo, hi, digits=2):
        s = self.app.settings
        s.set(**{key: round(min(hi, max(lo, (s[key] or 0) + delta)), digits)})

    def _do_shutdown(self):
        self.app.show_message("Shutting down. Unplug when the Pi's green light stops flashing.")
        system.shutdown()

    def _check_updates(self):
        if updates.request_check():
            self._asked_at = time.time()
            self._updates_at = 0
            self.app.show_message("Checking for updates. If there's a new version, TideView installs it "
                                  "and restarts by itself in a minute or two.", 8)
        else:
            self.app.show_message("Couldn't start the update check. Try Restart TideView, then try again.", 8)

    def _update_status(self, now, use24):
        if self._updates is None or now - self._updates_at > 2:
            self._updates_at = now
            self._updates = updates.read_state()
        st = self._updates
        if now - self._asked_at < 30 and not updates.busy_text(st, now) and \
                float(st.get("last_try") or 0) < self._asked_at - 1:
            return "Checking for updates..."
        return updates.describe(st, now, lambda t: format_clock(t, use24))

    def _pi(self):
        now = time.time()
        if self._pi_info is None or now - self._pi_info_at > 10:
            self._pi_info_at = now
            ip = system.ip_address()
            temp = system.cpu_temperature()
            power = system.power_problems()
            parts = []
            if temp is not None:
                parts.append("Processor %d°C. Under 70°C is fine. Over 80°C the Pi slows itself down: "
                             "give the frame some air gaps." % round(temp))
            if power:
                parts.append(power)
            self._pi_info = {
                "net": "%s · %s" % (system.hostname(), ip or "not connected"),
                "temp": " ".join(parts) or "Not available on this computer.",
            }
        return self._pi_info

    def rows(self):
        app = self.app
        s = app.settings
        fc = app.forecast
        f = fc.forecast
        now = time.time()
        c = f.at(now) if (f is not None and f.covers(now)) else None
        r = rate_surf(fc.beach, c) if c is not None else None
        use24 = s["use24h"]
        out = [row("section", "Beach"),
               row("nav", fc.beach.name, value="Change", sub="%s. Tap to change." % fc.beach.region,
                   on_tap=lambda: app.push(RegionPicker(app)))]
        if r is not None:
            out.append(row("info", "Right now: %d/10, %s" % (r.grade, r.label),
                           sub="Size %s · wind %s · swell direction %s · period %s · tide %s"
                           % (_pct(r.size), _pct(r.wind), _pct(r.swell_direction), _pct(r.period), _pct(r.tide))))
        if c is not None and c.model_heights:
            models = " · ".join("%s %s" % (k, "-" if v is None else "%.1f m" % v) for k, v in c.model_heights.items())
            out.append(row("info", "Wave models right now",
                           sub="%s. Showing %s m." % (models, "-" if c.surf_height is None else "%.1f" % c.surf_height)))
        if c is not None:
            if c.wind_measured is not None:
                out.append(row("info", "Wind measured at %s" % c.wind_measured.station,
                               sub="Reading from %s. The forecast takes over if readings stop."
                               % format_clock(c.wind_measured.time, use24)))
            else:
                out.append(row("info", "Wind from the forecast",
                               sub="No airport weather station close to this beach, or no recent reading."))

        out += [row("section", "Forecast updates"),
                row("cycle", "Get new data every", value=_interval(s["refreshMinutes"]),
                    on_tap=lambda: self._cycle("refreshMinutes", REFRESH_CHOICES)),
                row("nav", "Refresh forecast now", sub=self._forecast_status(), on_tap=fc.refresh)]
        if f is not None:
            out.append(row("info", "Where the numbers come from",
                           sub="Swell: %s. Wind: %s. Tides: %s." % (f.swell_source, f.wind_source, f.tide_source)))
        keys = app.keys
        out.append(row("info", "Data keys", sub="NIWA tides: %s. MetService: %s. Keys are read from .env.txt in the "
                       "tideview folder on the SD card." % ("key found" if keys.get("niwa") else "no key (using a tide model)",
                                             "key found" if keys.get("metocean") else "no key (using free models)")))

        out += [row("section", "Display"),
                row("toggle", "Wave height in metres", value=s["unit"] == "m",
                    on_tap=lambda: s.set(unit="ft" if s["unit"] == "m" else "m")),
                row("toggle", "24-hour clock", value=s["use24h"], on_tap=lambda: self._toggle("use24h")),
                row("toggle", "Animate the water", value=s["animate"],
                    sub="Rolls the swell lines a few times a second. Turn off to keep the Pi coolest.",
                    on_tap=lambda: self._toggle("animate")),
                row("toggle", "Show the surf score under the beach name", value=s["showRating"],
                    on_tap=lambda: self._toggle("showRating")),
                row("cycle", "Screen", value=ORIENTATION_LABELS[s["orientation"]],
                    sub="Upright or sideways, to suit the frame. Turned over if the picture is upside down.",
                    on_tap=lambda: self._cycle("orientation", ORIENTATIONS))]

        out += [row("section", "Night"),
                row("cycle", "At night", value=NIGHT_LABELS[s["nightMode"]],
                    sub="A tap brings the picture back for a minute. If 'Turn the screen off' leaves a "
                        "'No signal' message on screen, use 'Black picture' instead.",
                    on_tap=lambda: self._cycle("nightMode", NIGHT_MODES)),
                row("stepper", "Night starts", value=format_clock(_clock(s["nightStart"]), use24),
                    on_minus=lambda: self._step_time("nightStart", -15), on_plus=lambda: self._step_time("nightStart", 15)),
                row("stepper", "Morning starts", value=format_clock(_clock(s["dayStart"]), use24),
                    on_minus=lambda: self._step_time("dayStart", -15), on_plus=lambda: self._step_time("dayStart", 15)),
                row("stepper", "How dim", value=_pct(s["dimLevel"]),
                    on_minus=lambda: self._step("dimLevel", -0.1, 0.1, 0.9),
                    on_plus=lambda: self._step("dimLevel", 0.1, 0.1, 0.9))]

        geo = app.frame_geometry
        screen = app.screen_size
        box = geo.box(screen)
        cm = s["frameInCm"]
        lx, ty, bw, bh = geo.mm(box)
        right = (screen[0] - box.right) / geo.px_per_mm
        bottom = (screen[1] - box.bottom) / geo.px_per_mm
        sw_mm, sh_mm = screen[0] / geo.px_per_mm, screen[1] / geo.px_per_mm
        step = geo.snap_mm

        def nudge(field, sign):
            return lambda: (geo.nudge(screen, field, sign), app.frame_changed())

        out += [row("section", "Frame (developer)"),
                row("toggle", "Fit the picture to a frame", value=s["frameEnabled"],
                    sub="Shrinks the display to the box below. The rest of the screen goes black.",
                    on_tap=lambda: (self._toggle("frameEnabled"), app.frame_changed())),
                row("nav", "Adjust on screen", sub="Drag the corners and the middle of the box.",
                    on_tap=lambda: app.push(FrameEditor(app))),
                row("stepper", "Width", value=format_length(bw, cm), on_minus=nudge("w", -1), on_plus=nudge("w", 1)),
                row("stepper", "Height", value=format_length(bh, cm), on_minus=nudge("h", -1), on_plus=nudge("h", 1)),
                row("stepper", "Gap from the left", value=format_length(lx, cm),
                    on_minus=nudge("x", -1), on_plus=nudge("x", 1)),
                row("stepper", "Gap from the top", value=format_length(ty, cm),
                    on_minus=nudge("y", -1), on_plus=nudge("y", 1)),
                row("info", "That leaves %s on the right and %s at the bottom."
                    % (format_length(max(0, right), cm), format_length(max(0, bottom), cm)),
                    sub="Each tap moves %s." % ("1 mm" if cm else "0.05 in")),
                row("cycle", "Units", value="Centimetres" if cm else "Inches",
                    on_tap=lambda: s.set(frameInCm=not cm)),
                row("stepper", "Screen size (diagonal)", value="%.1f in" % s["screenDiagonalIn"],
                    sub="This screen: %s by %s at %d pixels per inch. If a ruler disagrees, change the diagonal "
                        "(the Jaycar panel is 7 in)." % (format_length(sw_mm, cm), format_length(sh_mm, cm), round(geo.ppi)),
                    on_minus=lambda: (self._step("screenDiagonalIn", -0.1, 3.0, 30.0, 1), app.frame_changed()),
                    on_plus=lambda: (self._step("screenDiagonalIn", 0.1, 3.0, 30.0, 1), app.frame_changed()))]
        del step

        out += [row("section", "TideView version"),
                row("info", "Version %s" % VERSION, sub=self._update_status(now, use24))]
        if updates.available():
            out.append(row("nav", "Check for updates now",
                           sub=updates.schedule_text(self._updates or {}, lambda t: format_clock(t, use24)),
                           on_tap=self._check_updates))

        pi = self._pi()
        out += [row("section", "This Pi"),
                row("info", "Network", sub=pi["net"]),
                row("info", "Temperature and power", sub=pi["temp"]),
                row("info", "Touch screen", sub=self._touch_text()),
                row("button", self.restart.current_label(), on_tap=self.restart.tap),
                row("button", self.shutdown.current_label(), on_tap=self.shutdown.tap, color=(0x6B, 0x23, 0x23))]
        return out

    def _touch_text(self):
        names = self.app.touch_names()
        text = ", ".join(names) + "." if names else "None found. Check the USB cable."
        drops = getattr(self.app.touch, "dropouts", 0)
        if drops:
            text += (" It has dropped out %s since TideView started. If that keeps happening, the screen needs "
                     "more power: plug a phone charger into its second USB socket."
                     % ("once" if drops == 1 else "%d times" % drops))
        return text

    def _forecast_status(self):
        fc = self.app.forecast
        use24 = self.app.settings["use24h"]
        if fc.loading:
            return "Updating now..."
        parts = []
        f = fc.forecast
        if f is not None:
            parts.append("Last update %s." % format_clock(f.fetched_at, use24))
        if fc.error:
            parts.append("The last try failed: %s" % fc.error)
        if fc.next_update:
            parts.append("Next at %s." % format_clock(fc.next_update, use24))
        return " ".join(parts) or "Waiting for the first update."


def _clock(minutes):
    """A timestamp today at minutes past midnight (for formatting)."""
    lt = time.localtime()
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, minutes // 60, minutes % 60, 0, 0, 0, -1))
