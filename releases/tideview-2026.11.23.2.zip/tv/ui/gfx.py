"""Drawing helpers: fonts, cached text and icons, colours, soft shapes.

Everything expensive (rendering text, scaling icons) is cached, because the
Pi Zero's single core is slow at it and the screen changes little.
"""

import os
from collections import OrderedDict

import pygame

from ..settings import APP_DIR

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
NIGHT = (0x0B, 0x10, 0x28)  # the sky / panel blue
MIST = (0xD9, 0xDC, 0xD3)
ACCENT = (0x2F, 0x8C, 0x44)

ASSETS = os.path.join(APP_DIR, "assets")


def lerp(a, b, t):
    """Mix two RGB colours: t = 0 gives a, 1 gives b."""
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


class _LRU(OrderedDict):
    def __init__(self, limit):
        super().__init__()
        self.limit = limit

    def get_or(self, key, make):
        v = self.get(key)
        if v is not None:
            self.move_to_end(key)
            return v
        v = make()
        self[key] = v
        if len(self) > self.limit:
            self.popitem(last=False)
        return v


class Gfx:
    def __init__(self):
        if not pygame.font.get_init():
            pygame.font.init()
        self._font_paths = {
            False: os.path.join(ASSETS, "fonts", "JosefinSans-SemiBold.ttf"),
            True: os.path.join(ASSETS, "fonts", "JosefinSans-Bold.ttf"),
        }
        self._fonts = {}
        self._text = _LRU(400)
        self._icons_src = {}
        self._icons = _LRU(120)
        self._misc = _LRU(60)

    # -- text -----------------------------------------------------------

    def font(self, size, bold=False):
        size = max(6, int(round(size)))
        key = (size, bold)
        f = self._fonts.get(key)
        if f is None:
            f = pygame.font.Font(self._font_paths[bold], size)
            self._fonts[key] = f
        return f

    def text(self, s, size, bold=False, opacity=1.0, color=WHITE, shadow=False):
        """Antialiased text as a per-pixel-alpha surface. Its height is the
        font size (the font's ascent + descent), like Flutter's height 1.0.
        With shadow, a soft drop shadow is baked in and the surface has a
        margin around the text; use text_offset() to place it."""
        key = (s, int(round(size)), bold, round(opacity, 3), color, shadow)
        return self._text.get_or(key, lambda: self._render_text(s, size, bold, opacity, color, shadow))

    def text_size(self, s, size, bold=False):
        return self.font(size, bold).size(s)

    def shadow_margin(self, size):
        return max(2, int(round(size * 0.12)))

    def text_offset(self, size, shadow):
        """Where the text's own top-left sits inside a text() surface."""
        m = self.shadow_margin(size) if shadow else 0
        return m, m

    def _render_text(self, s, size, bold, opacity, color, shadow):
        f = self.font(size, bold)
        glyphs = f.render(s, True, color)
        if opacity < 1:
            glyphs.fill((255, 255, 255, int(round(255 * opacity))), special_flags=pygame.BLEND_RGBA_MULT)
        if not shadow:
            return glyphs
        # Soft shadow like the Android app's (black at 20%, blurred, 2 px down):
        # shrink and re-grow a black copy, which blurs it cheaply.
        m = self.shadow_margin(size)
        w, h = glyphs.get_width() + 2 * m, glyphs.get_height() + 2 * m
        sh = pygame.Surface((w, h), pygame.SRCALPHA)
        dark = f.render(s, True, BLACK)
        sh.blit(dark, (m, m + max(1, int(round(size * 0.02)))))
        k = max(2, int(round(size / 22)))
        small = pygame.transform.smoothscale(sh, (max(1, w // k), max(1, h // k)))
        sh = pygame.transform.smoothscale(small, (w, h))
        sh.fill((255, 255, 255, int(255 * 0.22 * opacity)), special_flags=pygame.BLEND_RGBA_MULT)
        sh.blit(glyphs, (m, m))
        return sh

    def wrap(self, s, size, width, bold=False):
        """Splits s into lines that fit width pixels."""
        f = self.font(size, bold)
        lines, line = [], ""
        for word in s.split():
            trial = word if not line else line + " " + word
            if f.size(trial)[0] <= width or not line:
                line = trial
            else:
                lines.append(line)
                line = word
        if line:
            lines.append(line)
        return lines

    # -- icons ----------------------------------------------------------

    def icon(self, name, size, color=WHITE):
        size = max(4, int(round(size)))
        return self._icons.get_or((name, size, color), lambda: self._scaled_icon(name, size, color))

    def _source_icon(self, name):
        src = self._icons_src.get(name)
        if src is None:
            src = pygame.image.load(os.path.join(ASSETS, "icons", name + ".png"))
            if src.get_bitsize() != 32 or not (src.get_flags() & pygame.SRCALPHA):
                tmp = pygame.Surface(src.get_size(), pygame.SRCALPHA)
                tmp.blit(src, (0, 0))
                src = tmp
            # White everywhere, shape in the alpha channel (no dark fringes
            # when scaled).
            src.fill((255, 255, 255, 0), special_flags=pygame.BLEND_RGBA_MAX)
            self._icons_src[name] = src
        return src

    def _scaled_icon(self, name, size, color):
        img = pygame.transform.smoothscale(self._source_icon(name), (size, size))
        if color != WHITE:
            img.fill(color + (255,), special_flags=pygame.BLEND_RGBA_MULT)
        return img

    def arrow(self, degrees_from, size):
        """Paper-plane arrow pointing the way the swell or wind is going
        (degrees_from is where it comes FROM, as forecasts report it)."""
        size = max(4, int(round(size)))
        angle = int(round(degrees_from)) % 360

        def make():
            base = self.icon("arrow", size * 2)
            # pygame turns anticlockwise; compass bearings go clockwise.
            img = pygame.transform.rotozoom(base, -(angle + 180), 0.5)
            return img
        return self._icons.get_or(("arrow", size, angle), make)

    # -- shapes ---------------------------------------------------------

    def disc(self, diameter, fill, ring=None, ring_width=0):
        """A smooth circle (drawn 4x larger and shrunk)."""
        d = max(2, int(round(diameter)))
        key = ("disc", d, fill, ring, round(ring_width, 2))

        def make():
            k = 4
            big = pygame.Surface((d * k, d * k), pygame.SRCALPHA)
            c = d * k // 2
            if ring:
                pygame.draw.circle(big, ring, (c, c), c)
                pygame.draw.circle(big, fill, (c, c), max(1, int(c - ring_width * k)))
            else:
                pygame.draw.circle(big, fill, (c, c), c)
            return pygame.transform.smoothscale(big, (d, d))
        return self._misc.get_or(key, make)

    def panel(self, w, h, radius, fill_rgba, border_rgba=None):
        """A rounded, see-through panel."""
        w, h = max(1, int(w)), max(1, int(h))
        key = ("panel", w, h, int(radius), fill_rgba, border_rgba)

        def make():
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.rect(s, fill_rgba, s.get_rect(), border_radius=int(radius))
            if border_rgba:
                line = pygame.Surface((w, h), pygame.SRCALPHA)
                pygame.draw.rect(line, border_rgba, line.get_rect(), width=1, border_radius=int(radius))
                s.blit(line, (0, 0))
            return s
        return self._misc.get_or(key, make)


def blit_text(dst, gfx, s, size, x, y, bold=False, opacity=1.0, shadow=False, anchor="tl", color=WHITE):
    """Draws text with its box (width x font size) anchored at (x, y).
    anchor: t/m/b (top, middle, bottom) + l/c/r (left, centre, right)."""
    surf = gfx.text(s, size, bold, opacity, color, shadow)
    ox, oy = gfx.text_offset(size, shadow)
    w = surf.get_width() - 2 * ox
    h = surf.get_height() - 2 * oy
    v, hz = anchor[0], anchor[1]
    left = x if hz == "l" else (x - w / 2 if hz == "c" else x - w)
    top = y if v == "t" else (y - h / 2 if v == "m" else y - h)
    dst.blit(surf, (int(round(left - ox)), int(round(top - oy))))
    return pygame.Rect(int(left), int(top), w, h)
