"""Forecast data for one spot, and the conditions at a moment.

Times are Unix timestamps (seconds). Hourly series are lists lined up with
Forecast.hours; any value can be None when a source has a gap. This mirrors
lib/models/forecast.dart in the Android app.
"""

from bisect import bisect_right

from .compass import lerp_bearing


class TidePoint:
    __slots__ = ("time", "level")

    def __init__(self, time, level):
        self.time = time  # Unix seconds
        self.level = level  # metres relative to mean sea level


class TideExtreme:
    __slots__ = ("time", "level", "is_high")

    def __init__(self, time, level, is_high):
        self.time = time
        self.level = level
        self.is_high = is_high

    def __repr__(self):
        return "TideExtreme(%s, %.2f, %s)" % (self.time, self.level, "high" if self.is_high else "low")


class WindObservation:
    """Wind measured at an airport weather station."""
    __slots__ = ("time", "station", "speed", "gust", "direction", "temperature")

    def __init__(self, time, station, speed, gust=None, direction=None, temperature=None):
        self.time = time
        self.station = station
        self.speed = speed  # km/h
        self.gust = gust  # km/h
        self.direction = direction  # degrees, FROM
        self.temperature = temperature  # deg C


class Conditions:
    """Conditions at one moment."""

    def __init__(self, **kw):
        self.air_temp = kw.get("air_temp")
        self.weather_code = kw.get("weather_code")
        self.is_day = kw.get("is_day", True)
        self.wind_speed = kw.get("wind_speed")  # km/h
        self.wind_gust = kw.get("wind_gust")  # km/h
        self.wind_direction = kw.get("wind_direction")  # degrees, FROM
        self.wave_height = kw.get("wave_height")  # m
        self.wave_period = kw.get("wave_period")  # s
        self.swell_height = kw.get("swell_height")  # m
        self.swell_period = kw.get("swell_period")  # s
        self.swell_direction = kw.get("swell_direction")  # degrees, FROM
        self.sea_temp = kw.get("sea_temp")
        self.tide_level = kw.get("tide_level")
        self.tide_fraction = kw.get("tide_fraction")  # 0 low .. 1 high
        self.next_high = kw.get("next_high")
        self.next_low = kw.get("next_low")
        self.wind_measured = kw.get("wind_measured")  # WindObservation or None
        self.model_heights = kw.get("model_heights") or {}

    @property
    def surf_height(self):
        """Significant wave height, falling back to the primary swell."""
        return self.wave_height if self.wave_height is not None else self.swell_height

    @property
    def period(self):
        """Period of the primary swell, falling back to the mean wave period."""
        return self.swell_period if self.swell_period is not None else self.wave_period


def find_tide_extremes(pts):
    """Highs and lows in an evenly spaced sea-level series. Each turning
    point is refined with a parabola through its neighbours, so the time is
    better than the sample spacing."""
    out = []
    for k in range(1, len(pts) - 1):
        a, b, c = pts[k - 1].level, pts[k].level, pts[k + 1].level
        is_high = b >= a and b > c
        is_low = b <= a and b < c
        if not is_high and not is_low:
            continue
        denom = a - 2 * b + c
        offset = 0.0 if denom == 0 else max(-0.5, min(0.5, 0.5 * (a - c) / denom))
        step = pts[k + 1].time - pts[k].time
        t = pts[k].time + round(step * offset)
        level = b - 0.25 * (a - c) * offset
        e = TideExtreme(t, level, is_high)
        # Ignore wiggles: real turning points alternate and sit hours apart.
        if out:
            prev = out[-1]
            if prev.is_high == e.is_high:
                better = e.level > prev.level if e.is_high else e.level < prev.level
                if better:
                    out[-1] = e
                continue
            if e.time - prev.time < 3 * 3600:
                continue
        out.append(e)
    return out


class Forecast:
    def __init__(self, fetched_at, hours, air_temp, weather_code, is_day, wind_speed, wind_gust,
                 wind_direction, wave_height, wave_period, swell_height, swell_period, swell_direction,
                 sea_temp, tide, tide_source, model_heights=None, observation=None,
                 swell_source="Open-Meteo", wind_source="Open-Meteo forecast"):
        self.fetched_at = fetched_at
        self.hours = hours
        self.air_temp = air_temp
        self.weather_code = weather_code
        self.is_day = is_day
        self.wind_speed = wind_speed
        self.wind_gust = wind_gust
        self.wind_direction = wind_direction
        self.wave_height = wave_height
        self.wave_period = wave_period
        self.swell_height = swell_height
        self.swell_period = swell_period
        self.swell_direction = swell_direction
        self.sea_temp = sea_temp
        self.tide = tide
        self.tide_source = tide_source
        self.model_heights = model_heights or {}
        self.observation = observation
        self.swell_source = swell_source
        self.wind_source = wind_source
        self.tide_extremes = find_tide_extremes(tide)
        self._tide_times = [p.time for p in tide]
        self._tide_min = min((p.level for p in tide), default=0.0)
        self._tide_max = max((p.level for p in tide), default=1.0)

    def covers(self, t):
        """True when t is inside the hourly series."""
        return bool(self.hours) and self.hours[0] <= t < self.hours[-1] + 3600

    def at(self, t):
        """Conditions at time t, interpolated between the surrounding hours."""
        hours = self.hours
        n = len(hours)
        if n == 0:
            return Conditions()
        i = min(max(bisect_right(hours, t) - 1, 0), n - 1)
        j = min(i + 1, n - 1)
        span = hours[j] - hours[i]
        f = 0.0 if span <= 0 else max(0.0, min(1.0, (t - hours[i]) / span))
        nearest = i if f < 0.5 else j

        def lin(v):
            a, b = v[i], v[j]
            if a is None:
                return b
            if b is None:
                return a
            return a + (b - a) * f

        def ang(v):
            a, b = v[i], v[j]
            if a is None:
                return b
            if b is None:
                return a
            return lerp_bearing(a, b, f)

        # A measurement from the last 90 minutes beats the forecast for "now".
        obs = self.observation
        use_obs = obs is not None and abs(t - obs.time) < 91 * 60

        code = self.weather_code[nearest]
        if code is None:
            code = self.weather_code[i]
        day = self.is_day[nearest]
        return Conditions(
            air_temp=obs.temperature if use_obs and obs.temperature is not None else lin(self.air_temp),
            weather_code=code,
            is_day=True if day is None else day,
            wind_speed=obs.speed if use_obs else lin(self.wind_speed),
            wind_gust=(obs.gust if obs.gust is not None else obs.speed) if use_obs else lin(self.wind_gust),
            wind_direction=obs.direction if use_obs and obs.direction is not None else ang(self.wind_direction),
            wind_measured=obs if use_obs else None,
            model_heights={k: v[nearest] for k, v in self.model_heights.items()},
            wave_height=lin(self.wave_height),
            wave_period=lin(self.wave_period),
            swell_height=lin(self.swell_height),
            swell_period=lin(self.swell_period),
            swell_direction=ang(self.swell_direction),
            sea_temp=lin(self.sea_temp),
            tide_level=self.tide_level_at(t),
            tide_fraction=self.tide_fraction_at(t),
            next_high=self._next_extreme(t, True),
            next_low=self._next_extreme(t, False),
        )

    def tide_level_at(self, t):
        tide = self.tide
        if len(tide) < 2 or t < tide[0].time or t > tide[-1].time:
            return None
        k = min(max(bisect_right(self._tide_times, t) - 1, 0), len(tide) - 2)
        a, b = tide[k], tide[k + 1]
        span = b.time - a.time
        f = 0 if span == 0 else (t - a.time) / span
        return a.level + (b.level - a.level) * f

    def tide_fraction_at(self, t):
        """Where the water is within the current tide: 0 at low water, 1 at
        high water, between the low and high either side of t. So every high
        tide reaches 1 and every low tide 0, big tide or small."""
        level = self.tide_level_at(t)
        if level is None:
            return None
        before = after = None
        for e in self.tide_extremes:
            if e.time > t:
                after = e
                break
            before = e
        lo, hi = self._tide_min, self._tide_max
        if before is not None and after is not None and before.is_high != after.is_high:
            lo = after.level if before.is_high else before.level
            hi = before.level if before.is_high else after.level
        if hi - lo < 0.05:
            return None
        return max(0.0, min(1.0, (level - lo) / (hi - lo)))

    def tide_rising_at(self, t):
        for e in self.tide_extremes:
            if e.time > t:
                return e.is_high
        return None

    def _next_extreme(self, t, high):
        for e in self.tide_extremes:
            if e.is_high == high and e.time > t:
                return e
        return None
