"""Surf score on a 1 (worst) to 10 (best) scale, the same as the Android app
(lib/services/rating.dart)."""

from .compass import angle_between

GRADE_LABELS = [
    "Flat or blown out",
    "Very poor",
    "Poor",
    "Poor to fair",
    "Fair",
    "Average",
    "Fair to good",
    "Good",
    "Very good",
    "Firing",
]

# Red (1) through orange and yellow (average) to a rich dark green (10).
GRADE_COLORS = [
    (0x7A, 0x1C, 0x1C),  # 1
    (0x9B, 0x26, 0x26),  # 2
    (0xB5, 0x3A, 0x2A),  # 3
    (0xC7, 0x5A, 0x2B),  # 4
    (0xCF, 0x7F, 0x2D),  # 5
    (0xC9, 0xA6, 0x35),  # 6 average: yellow
    (0x9D, 0xB0, 0x3E),  # 7
    (0x63, 0xA6, 0x4A),  # 8 light green
    (0x2F, 0x8C, 0x44),  # 9
    (0x16, 0x65, 0x3A),  # 10 rich dark green
]


class SurfRating:
    __slots__ = ("grade", "score", "size", "period", "swell_direction", "wind", "tide")

    def __init__(self, grade, score, size, period, swell_direction, wind, tide):
        self.grade = grade  # 1..10
        self.score = score  # 0..1 before rounding into a grade
        # Each part is 0 (bad) .. 1 (ideal).
        self.size = size
        self.period = period
        self.swell_direction = swell_direction
        self.wind = wind
        self.tide = tide

    @property
    def label(self):
        return GRADE_LABELS[self.grade - 1]

    @property
    def color(self):
        return GRADE_COLORS[self.grade - 1]


UNKNOWN = SurfRating(5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5)


def _curve(x, pts):
    """Piecewise-linear lookup through (x, y) points sorted by x."""
    if x <= pts[0][0]:
        return pts[0][1]
    for i in range(1, len(pts)):
        if x <= pts[i][0]:
            a, b = pts[i - 1], pts[i]
            return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])
    return pts[-1][1]


def grade_for_score(score):
    return max(1, min(10, 1 + int(max(0.0, min(1.0, score)) * 9.999)))


def rate_surf(beach, c):
    """Scores how surfable conditions c are at beach."""
    height_m = c.surf_height
    period_s = c.period
    if height_m is None or period_s is None:
        return UNKNOWN
    # How square-on the swell hits the break. Swell from the wrong side is
    # blocked by the land, so it barely counts towards the size.
    swell_off = 45.0 if c.swell_direction is None else angle_between(c.swell_direction, beach.ideal_swell_deg)
    exposure = _curve(swell_off, [(0, 1.0), (30, 0.95), (60, 0.7), (90, 0.35), (120, 0.1), (150, 0.0)])
    ft = height_m * 3.28084 * exposure

    # Size reaching the beach: flat is useless, 3-7 ft is the sweet spot,
    # very big gets messy.
    size = _curve(ft, [(0.3, 0.0), (1, 0.2), (2, 0.5), (3, 0.8), (4, 1.0), (7, 1.0), (10, 0.7), (15, 0.3)])

    # Period: short wind swell is weak and messy, long groundswell is clean.
    period = _curve(period_s, [(4, 0.0), (6, 0.3), (8, 0.6), (10, 0.8), (12, 0.95), (14, 1.0)])

    # Swell direction against what the break likes (shape, not just size).
    swell_dir = _curve(swell_off, [(0, 1.0), (20, 0.95), (45, 0.7), (70, 0.4), (100, 0.1), (130, 0.0)])

    # Wind: light wind is always fine, offshore holds up when it's stronger,
    # onshore ruins it quickly.
    wind = 0.6
    if c.wind_speed is not None:
        kmh = c.wind_speed
        gust = c.wind_gust if c.wind_gust is not None else kmh
        off = 90.0 if c.wind_direction is None else angle_between(c.wind_direction, beach.ideal_wind_deg)
        if off <= 45:
            tolerance, falloff = 25.0, 35.0
        elif off <= 100:
            tolerance, falloff = 12.0, 25.0
        else:
            tolerance, falloff = 7.0, 18.0
        effective = kmh + max(0.0, gust - kmh - 15) * 0.3
        wind = max(0.0, min(1.0, 1 - max(0.0, effective - tolerance) / falloff))

    # Tide: only matters for breaks that prefer one end of it.
    tide = 1.0
    f = c.tide_fraction
    if f is not None:
        if beach.tide == "high":
            tide = 0.3 + 0.7 * f
        elif beach.tide == "low":
            tide = 0.3 + 0.7 * (1 - f)

    # The swell sets how good it can be; wind and tide decide how much of
    # that you actually get. No amount of nice wind makes a flat day good.
    swell = size * 0.45 + period * 0.25 + swell_dir * 0.30
    score = swell * (0.3 + 0.7 * wind) * (0.8 + 0.2 * tide) * min(1.0, 0.15 + 1.2 * size)
    score = max(0.0, min(1.0, score))
    return SurfRating(grade_for_score(score), score, size, period, swell_dir, wind, tide)
