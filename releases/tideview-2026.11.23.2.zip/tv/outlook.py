"""Morning, midday and evening surf scores for the week strip (same rules as
lib/services/outlook.dart)."""

from datetime import date, datetime

from .rating import grade_for_score, rate_surf

# Hours averaged for each session.
SESSIONS = (
    ("Morning", (6, 7, 8, 9)),
    ("Midday", (11, 12, 13, 14)),
    ("Evening", (16, 17, 18, 19)),
)


class SessionOutlook:
    __slots__ = ("name", "grade", "is_past")

    def __init__(self, name, grade=None, is_past=False):
        self.name = name
        self.grade = grade  # 1..10, or None beyond the forecast
        self.is_past = is_past  # already over (today only)


class DayOutlook:
    __slots__ = ("day", "sessions", "grade", "max_height")

    def __init__(self, day, sessions, grade=None, max_height=None):
        self.day = day  # datetime.date
        self.sessions = sessions
        self.grade = grade  # the day's best session, since that's when you'd go
        self.max_height = max_height  # biggest surf (m) between 6 am and 8 pm


def _local(d, hour):
    """Unix time for a local clock hour on date d (handles daylight saving)."""
    return datetime(d.year, d.month, d.day, hour).timestamp()


def week_outlook(forecast, beach, now, days=7):
    out = []
    today = datetime.fromtimestamp(now).date()
    for k in range(days):
        day = date.fromordinal(today.toordinal() + k)
        sessions = []
        for name, hours in SESSIONS:
            scores = []
            for h in hours:
                t = _local(day, h)
                if not forecast.covers(t):
                    continue
                c = forecast.at(t)
                if c.surf_height is None:
                    continue
                scores.append(rate_surf(beach, c).score)
            end = _local(day, hours[-1] + 1)
            grade = grade_for_score(sum(scores) / len(scores)) if scores else None
            sessions.append(SessionOutlook(name, grade, end < now))
        max_h = None
        for h in range(6, 21):
            t = _local(day, h)
            if not forecast.covers(t):
                continue
            v = forecast.at(t).surf_height
            if v is not None and (max_h is None or v > max_h):
                max_h = v
        grades = [s.grade for s in sessions if s.grade is not None]
        out.append(DayOutlook(day, sessions, max(grades) if grades else None, max_h))
    return out
