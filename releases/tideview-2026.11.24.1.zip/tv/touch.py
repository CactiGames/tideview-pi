"""Reads the touch screen straight from Linux (/dev/input/event*), so no
desktop is needed. Works with USB touch panels (single touch or multi-touch;
only the first finger is used).

Positions come out as fractions of the panel (0..1 across and down), which
the app turns into picture coordinates for the screen's orientation.
"""

import errno
import fcntl
import glob
import logging
import os
import queue
import select
import struct
import threading
import time

log = logging.getLogger("tideview.touch")

EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
SYN_REPORT = 0
BTN_TOUCH, BTN_LEFT = 0x14A, 0x110
ABS_X, ABS_Y = 0x00, 0x01
ABS_MT_SLOT, ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_TRACKING_ID = 0x2F, 0x35, 0x36, 0x39
INPUT_PROP_POINTER, INPUT_PROP_DIRECT = 0x00, 0x01

EVENT = struct.Struct("llHHi")  # struct input_event (time is two longs on 32-bit and 64-bit)


def _ioc(direction, nr, size):
    return (direction << 30) | (size << 16) | (ord("E") << 8) | nr


def _eviocgbit(ev, size):
    return _ioc(2, 0x20 + ev, size)


def _eviocgabs(code):
    return _ioc(2, 0x40 + code, 24)


def _eviocgname(size):
    return _ioc(2, 0x06, size)


def _eviocgprop(size):
    return _ioc(2, 0x09, size)


def _bit(buf, n):
    return n // 8 < len(buf) and bool(buf[n // 8] & (1 << (n % 8)))


class _Device:
    def __init__(self, path):
        self.path = path
        self.fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        try:
            name = bytearray(256)
            fcntl.ioctl(self.fd, _eviocgname(len(name)), name, True)
            self.name = bytes(name).split(b"\0", 1)[0].decode("utf-8", "replace")
            absbits = bytearray(8)
            fcntl.ioctl(self.fd, _eviocgbit(EV_ABS, len(absbits)), absbits, True)
            keybits = bytearray(96)
            fcntl.ioctl(self.fd, _eviocgbit(EV_KEY, len(keybits)), keybits, True)
            props = bytearray(4)
            try:
                fcntl.ioctl(self.fd, _eviocgprop(len(props)), props, True)
            except OSError:
                pass
            self.has_xy = _bit(absbits, ABS_X) and _bit(absbits, ABS_Y)
            self.has_mt = _bit(absbits, ABS_MT_POSITION_X) and _bit(absbits, ABS_MT_POSITION_Y)
            # A touch screen: absolute positions plus a touch (or left
            # button) signal. Touchpads say they are pointers; skip those.
            self.is_touch = (self.has_xy or self.has_mt) and not _bit(props, INPUT_PROP_POINTER) and (
                _bit(keybits, BTN_TOUCH) or _bit(keybits, BTN_LEFT) or _bit(props, INPUT_PROP_DIRECT))
            if not self.is_touch:
                return
            ax, ay = (ABS_X, ABS_Y) if self.has_xy else (ABS_MT_POSITION_X, ABS_MT_POSITION_Y)
            self.range_x = self._absrange(ax)
            self.range_y = self._absrange(ay)
            self.mt_range_x = self._absrange(ABS_MT_POSITION_X) if self.has_mt else self.range_x
            self.mt_range_y = self._absrange(ABS_MT_POSITION_Y) if self.has_mt else self.range_y
        except OSError:
            os.close(self.fd)
            raise
        self.x = self.y = None
        self.touching = False
        self.slot = 0
        self.changed = False
        self.seen_btn_touch = False
        self.was_touching = False

    def _absrange(self, code):
        info = bytearray(24)
        fcntl.ioctl(self.fd, _eviocgabs(code), info, True)
        _value, lo, hi, _fuzz, _flat, _res = struct.unpack("6i", info)
        return lo, hi if hi > lo else lo + 1

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass


class TouchReader:
    """Background thread that turns touch events into ("down"|"move"|"up",
    u, v) tuples on a queue. u, v are 0..1 across/down the panel."""

    def __init__(self, events=None):
        self.events = events or queue.Queue()
        self._devices = {}
        self._stop = False
        self._thread = threading.Thread(target=self._run, name="touch", daemon=True)
        self._last_scan = 0.0
        self.dropouts = 0  # times a touch screen went away (usually a power problem)

    @property
    def found(self):
        return bool(self._devices)

    def device_names(self):
        return [d.name for d in self._devices.values()]

    def start(self):
        self._scan()
        self._thread.start()

    def stop(self):
        self._stop = True

    def _scan(self):
        self._last_scan = time.time()
        for path in sorted(glob.glob("/dev/input/event*")):
            if path in self._devices:
                continue
            try:
                d = _Device(path)
            except OSError:
                continue
            if d.is_touch:
                self._devices[path] = d
                log.info("touch screen: %s (%s)", d.name, path)
            else:
                d.close()

    def _run(self):
        while not self._stop:
            if not self._devices or time.time() - self._last_scan > 15:
                # Look again for a touch screen plugged in later.
                if time.time() - self._last_scan > (2 if not self._devices else 15):
                    self._scan()
                if not self._devices:
                    time.sleep(1)
                    continue
            fds = {d.fd: d for d in self._devices.values()}
            try:
                ready, _, _ = select.select(list(fds), [], [], 1.0)
            except (OSError, ValueError):
                ready = []
            for fd in ready:
                d = fds[fd]
                try:
                    data = os.read(fd, EVENT.size * 64)
                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        continue
                    log.info("touch screen %s went away", d.path)
                    d.close()
                    self._devices.pop(d.path, None)
                    self.dropouts += 1
                    continue
                for off in range(0, len(data) - EVENT.size + 1, EVENT.size):
                    _s, _us, etype, code, value = EVENT.unpack_from(data, off)
                    self._handle(d, etype, code, value)

    def _handle(self, d, etype, code, value):
        if etype == EV_KEY and code in (BTN_TOUCH, BTN_LEFT):
            if code == BTN_TOUCH:
                d.seen_btn_touch = True
            d.touching = value != 0
            d.changed = True
        elif etype == EV_ABS:
            if code == ABS_X and d.has_xy:
                d.x = (value - d.range_x[0]) / (d.range_x[1] - d.range_x[0])
                d.changed = True
            elif code == ABS_Y and d.has_xy:
                d.y = (value - d.range_y[0]) / (d.range_y[1] - d.range_y[0])
                d.changed = True
            elif code == ABS_MT_SLOT:
                d.slot = value
            elif d.slot == 0 and code == ABS_MT_POSITION_X and not d.has_xy:
                d.x = (value - d.mt_range_x[0]) / (d.mt_range_x[1] - d.mt_range_x[0])
                d.changed = True
            elif d.slot == 0 and code == ABS_MT_POSITION_Y and not d.has_xy:
                d.y = (value - d.mt_range_y[0]) / (d.mt_range_y[1] - d.mt_range_y[0])
                d.changed = True
            elif d.slot == 0 and code == ABS_MT_TRACKING_ID and not d.seen_btn_touch:
                d.touching = value != -1
                d.changed = True
        elif etype == EV_SYN and code == SYN_REPORT and d.changed:
            d.changed = False
            if d.x is None or d.y is None:
                return
            u, v = min(1.0, max(0.0, d.x)), min(1.0, max(0.0, d.y))
            was = d.was_touching
            if d.touching and not was:
                self.events.put(("down", u, v))
            elif d.touching:
                self.events.put(("move", u, v))
            elif was:
                self.events.put(("up", u, v))
            d.was_touching = d.touching
