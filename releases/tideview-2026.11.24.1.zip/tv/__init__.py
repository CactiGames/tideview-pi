"""TideView for Raspberry Pi: data, surf rating, screen output, touch and
the app itself. tideview.py (one folder up) starts it."""
