"""Airport weather stations that publish observations (METAR) every 30-60
minutes. When one is close to a beach, TideView shows its measured wind for
"now" instead of the forecast."""

import math


class Station:
    __slots__ = ("icao", "name", "lat", "lng")

    def __init__(self, icao, name, lat, lng):
        self.icao = icao
        self.name = name
        self.lat = lat
        self.lng = lng


STATIONS = [
    Station("NZWN", "Wellington Airport", -41.3272, 174.8053),
    Station("NZPP", "Paraparaumu Airport", -40.9047, 174.9890),
    Station("NZWU", "Whanganui Airport", -39.9622, 175.0253),
    Station("NZNP", "New Plymouth Airport", -39.0086, 174.1792),
    Station("NZWP", "Whenuapai", -36.7878, 174.6303),
    Station("NZKT", "Kaitaia Airport", -35.0700, 173.2853),
    Station("NZWR", "Whangarei Airport", -35.7683, 174.3650),
    Station("NZTG", "Tauranga Airport", -37.6719, 176.1961),
    Station("NZWK", "Whakatane Airport", -37.9206, 176.9142),
    Station("NZGS", "Gisborne Airport", -38.6633, 177.9783),
    Station("NZNR", "Napier Airport", -39.4658, 176.8700),
    Station("NZCH", "Christchurch Airport", -43.4894, 172.5322),
]


def distance_km(lat1, lng1, lat2, lng2):
    r = 6371.0
    rad = math.radians
    d_lat, d_lng = rad(lat2 - lat1), rad(lng2 - lng1)
    a = math.sin(d_lat / 2) ** 2 + math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.sin(d_lng / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def nearest_station(beach, max_km=20.0):
    """The closest station within max_km of the beach, or None. Wind changes
    a lot over short distances, so only nearby stations are worth using."""
    best, best_km = None, max_km
    for s in STATIONS:
        d = distance_km(beach.lat, beach.lng, s.lat, s.lng)
        if d <= best_km:
            best, best_km = s, d
    return best


def station_by_icao(icao):
    for s in STATIONS:
        if s.icao == icao:
            return s
    return None
