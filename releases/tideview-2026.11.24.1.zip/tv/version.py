"""This copy of TideView's version, from the VERSION file next to
tideview.py (written when a release is made)."""

import os

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read():
    try:
        with open(os.path.join(APP_DIR, "VERSION"), encoding="utf-8") as f:
            return f.read().strip() or "dev"
    except OSError:
        return "dev"


VERSION = _read()
