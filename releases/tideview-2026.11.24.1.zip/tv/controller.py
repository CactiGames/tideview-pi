"""Keeps the forecast for the preferred beach fresh, on a background thread.

Loads the cached copy straight away, refreshes on the interval chosen in
Settings, and retries sooner after a failure (Wi-Fi may drop overnight). A
failed update keeps the last good data on screen. Same behaviour as
lib/services/forecast_controller.dart.
"""

import json
import logging
import os
import threading
import time

from . import sources

log = logging.getLogger("tideview.data")

RETRY_DELAYS = (60, 180, 600)  # seconds, after the 1st, 2nd, 3rd+ failure


class ForecastController:
    def __init__(self, beach, keys, interval_minutes, cache_path):
        self._lock = threading.Condition()
        self._keys = keys
        self._cache_path = cache_path
        self._beach = beach
        self._interval = interval_minutes * 60
        self._generation = 0  # bumped when the beach changes
        self.forecast = None
        self._raw = None
        self.error = None
        self.loading = False
        self.last_attempt = None
        self.next_update = None
        self._failures = 0
        self._due = 0.0  # fetch straight away
        self._poked = True
        self._stop = False
        self.version = 0  # bumped whenever anything above changes
        self._load_cache()
        self._thread = threading.Thread(target=self._run, name="forecast", daemon=True)

    # -- called from the UI thread --------------------------------------

    @property
    def beach(self):
        return self._beach

    def start(self):
        self._thread.start()

    def stop(self):
        with self._lock:
            self._stop = True
            self._lock.notify_all()

    def refresh(self):
        with self._lock:
            self._poked = True
            self._lock.notify_all()

    def set_beach(self, beach):
        with self._lock:
            if beach.id == self._beach.id:
                return
            # Forget the old beach (a fetch still running for it is ignored)
            # and start on the new one now.
            self._generation += 1
            self._beach = beach
            self.forecast = None
            self._raw = None
            self.error = None
            self._failures = 0
            self.loading = False
            self._load_cache()
            self._poked = True
            self.version += 1
            self._lock.notify_all()

    def set_interval(self, minutes):
        with self._lock:
            if minutes * 60 == self._interval:
                return
            self._interval = minutes * 60
            if not self.loading and self._failures == 0:
                self._schedule_next()
            self.version += 1
            self._lock.notify_all()

    def set_keys(self, keys):
        with self._lock:
            if keys != self._keys:
                self._keys = keys
                self._poked = True
                self._lock.notify_all()

    @property
    def is_stale(self):
        """True when the data on screen is clearly out of date."""
        f = self.forecast
        if f is None:
            return True
        max_age = max(2 * 3600, self._interval * 2 + 600)
        return time.time() - f.fetched_at > max_age

    # -- background thread ----------------------------------------------

    def _load_cache(self):
        try:
            with open(self._cache_path, encoding="utf-8") as fh:
                cached = json.load(fh)
            if cached.get("beach") != self._beach.id:
                return
            raw = cached["raw"]
            self.forecast = sources.parse_forecast(raw)
            self._raw = raw
        except (OSError, ValueError, KeyError, TypeError):
            self.forecast = None
            self._raw = None

    def _save_cache(self, beach_id, raw):
        tmp = self._cache_path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"beach": beach_id, "raw": raw}, fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self._cache_path)
        except OSError as e:
            log.warning("could not save the forecast cache: %s", e)

    def _schedule_next(self):
        now = time.time()
        delay = self._interval
        if self._failures > 0:
            retry = RETRY_DELAYS[min(self._failures - 1, len(RETRY_DELAYS) - 1)]
            delay = min(delay, retry)
        elif self.forecast is not None:
            # Count from the last good update, so a new interval takes effect
            # straight away.
            due = self.forecast.fetched_at + self._interval - now
            delay = max(0.0, min(due, delay))
        self._due = now + delay
        self.next_update = self._due

    def _run(self):
        while True:
            with self._lock:
                while not self._stop and not self._poked and time.time() < self._due:
                    self._lock.wait(timeout=max(0.2, min(30.0, self._due - time.time())))
                if self._stop:
                    return
                self._poked = False
                beach, generation, previous, keys = self._beach, self._generation, self._raw, self._keys
                self.loading = True
                self.last_attempt = time.time()
                self.next_update = None
                self.version += 1

            raw = parsed = failure = None
            try:
                raw = sources.fetch(beach, keys.get("niwa", ""), keys.get("metocean", ""), previous)
                parsed = sources.parse_forecast(raw)
            except Exception as e:  # noqa: BLE001
                failure = e
                log.warning("update failed for %s: %r", beach.name, e)

            if failure is None and generation == self._generation:
                self._save_cache(beach.id, raw)
                log.info("updated %s (swell: %s, wind: %s, tides: %s)", beach.name,
                         parsed.swell_source, parsed.wind_source, parsed.tide_source)

            with self._lock:
                if generation != self._generation:
                    continue  # the beach changed while this ran
                self.loading = False
                if failure is None:
                    self.forecast = parsed
                    self._raw = raw
                    self.error = None
                    self._failures = 0
                else:
                    self.error = sources.describe_error(failure)
                    self._failures += 1
                self._schedule_next()
                self.version += 1
