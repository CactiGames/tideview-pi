"""Downloads surf, weather and tide data, and turns it into a Forecast.

Same sources and rules as the Android app (lib/services/forecast_service.dart):

- Open-Meteo (no key): wind, weather, air temperature, waves from three wave
  models (the middle value is the total height, and their swell and wind
  chop are averaged), sea temperature, modelled sea level.
- MetService / MetOcean Point Forecast (METOCEAN_API_KEY): MetService's
  global wave and wind models. Its swell and chop join the average, its peak
  period is used, and its wind replaces the free forecast.
- NIWA tide predictions (NIWA_API_KEY): replace the modelled sea level.
  Tides don't change, so they're only downloaded every 12 hours.
- The nearest airport weather station within 20 km (METAR, no key): the
  measured wind, shown under the forecast wind (and used for the score only
  when Settings asks for it).

The raw replies are kept as a dict (cached to disk) so the display keeps
working through Wi-Fi drop-outs and can be parsed again offline.
"""

import gzip
import json
import math
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from .model import Forecast, TidePoint, WindObservation
from .stations import nearest_station, station_by_icao

USER_AGENT = "TideView/1.0 (personal surf display)"
TIMEOUT = 20  # seconds per request
RETRY_PAUSES = (2, 5)  # seconds before the 2nd and 3rd try
TIDE_REUSE = 12 * 3600  # use downloaded tides this long before asking again
TIDE_FALLBACK = 5 * 86400  # ...and up to this old when NIWA can't be reached

# The waves come split at 8 seconds: above is the swell, below is the local
# wind chop (which, with an offshore wind, is heading out to sea).
METOCEAN_VARIABLES = [
    "wave.height",
    "wave.period.peak",
    "wave.direction.peak",
    "wave.height.above-8s",
    "wave.period.above-8s.peak",
    "wave.direction.above-8s.peak",
    "wave.height.below-8s",
    "wave.period.below-8s.peak",
    "wave.direction.below-8s.peak",
    "wind.speed.at-10m",
    "wind.direction.at-10m",
    "wind.speed.gust.at-10m",
]

# Wave models averaged for the swell (Open-Meteo id -> name).
WAVE_MODELS = {
    "meteofrance_wave": "MeteoFrance",
    "ecmwf_wam": "ECMWF",
    "ncep_gfswave025": "NOAA",
}


# ---------------------------------------------------------------- errors


class ForecastError(Exception):
    """A data source answered with an HTTP error."""

    def __init__(self, source, status):
        super().__init__("%s answered %s" % (source, status))
        self.source = source
        self.status = status

    @property
    def worth_retrying(self):
        # Busy or briefly broken servers; anything else won't fix itself.
        return self.status in (408, 429) or self.status >= 500


def is_temporary_network_error(e):
    return isinstance(e, (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError,
                          ssl.SSLError, OSError)) and not isinstance(e, urllib.error.HTTPError)


def describe_error(e):
    """A short, plain reason for a failed update, for the screen."""
    if isinstance(e, ForecastError):
        if e.status in (401, 403):
            return "The forecast server refused the request (error %d)." % e.status
        if e.status == 429:
            return "The forecast server is busy (too many requests)."
        if e.status >= 500:
            return "The forecast server is having problems (error %d)." % e.status
        return "The forecast server answered with an error (%d)." % e.status
    text = str(e)
    reason = getattr(e, "reason", None)
    if reason is not None:
        text += " " + str(reason)
    if isinstance(e, (socket.timeout, TimeoutError)) or "timed out" in text:
        return "The forecast server took too long to answer."
    if ("Name or service not known" in text or "Temporary failure in name resolution" in text
            or "Network is unreachable" in text or "No address associated" in text
            or "nodename nor servname" in text):
        return "No internet connection. Check the Wi-Fi."
    if isinstance(e, ssl.SSLError) or isinstance(reason, ssl.SSLError) or "CERTIFICATE" in text:
        return "Couldn't make a secure connection. Check the Pi's date and time."
    if is_temporary_network_error(e):
        return "The connection to the forecast server dropped."
    if isinstance(e, (ValueError, KeyError, TypeError)):
        return "The forecast server sent something unexpected."
    return "Couldn't update the forecast."


# ---------------------------------------------------------------- HTTP


def _request(source, url, headers=None, data=None):
    """GET (or POST when data is given), retried after a short pause when it
    fails on the way: a dropped connection, a timeout, or the server being
    briefly unavailable."""
    hdrs = {"User-Agent": USER_AGENT, "Accept-Encoding": "gzip"}
    if headers:
        hdrs.update(headers)
    last = None
    for attempt in range(len(RETRY_PAUSES) + 1):
        if attempt:
            time.sleep(RETRY_PAUSES[attempt - 1])
        req = urllib.request.Request(url, data=data, headers=hdrs, method="POST" if data else "GET")
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as res:
                body = res.read()
                if res.headers.get("Content-Encoding", "").lower() == "gzip":
                    body = gzip.decompress(body)
                return body.decode("utf-8")
        except urllib.error.HTTPError as e:
            err = ForecastError(source, e.code)
            if not err.worth_retrying:
                raise err
            last = err
        except Exception as e:  # noqa: BLE001 - network errors come in many types
            if not is_temporary_network_error(e):
                raise
            last = e
    raise last


def _optional(fn, *args):
    """Extra sources are nice to have: if one fails, carry on without it."""
    try:
        return fn(*args)
    except Exception:  # noqa: BLE001
        return None


def _offset(lat, lng, bearing, km):
    """A point km away from (lat, lng) along bearing degrees."""
    d = km / 6371.0
    b = math.radians(bearing)
    la, lo = math.radians(lat), math.radians(lng)
    la2 = math.asin(math.sin(la) * math.cos(d) + math.cos(la) * math.sin(d) * math.cos(b))
    lo2 = lo + math.atan2(math.sin(b) * math.sin(d) * math.cos(la), math.cos(d) - math.sin(la) * math.sin(la2))
    return math.degrees(la2), math.degrees(lo2)


def _open_meteo_urls(beach):
    lat, lng = "%.4f" % beach.lat, "%.4f" % beach.lng
    common = {"latitude": lat, "longitude": lng, "past_days": "1", "forecast_days": "7",
              "timeformat": "unixtime", "timezone": "auto"}
    weather = dict(common, hourly="temperature_2m,weather_code,is_day,wind_speed_10m,wind_direction_10m,wind_gusts_10m",
                   wind_speed_unit="kmh")
    marine = dict(common, hourly="wave_height,wave_period,swell_wave_height,swell_wave_period,"
                                 "swell_wave_direction,wind_wave_height,wind_wave_period,wind_wave_direction,"
                                 "sea_surface_temperature",
                  minutely_15="sea_level_height_msl", cell_selection="sea")
    waves = dict(common, hourly="wave_height,wave_period,wave_peak_period,wave_direction,"
                                "swell_wave_height,swell_wave_period,swell_wave_peak_period,swell_wave_direction,"
                                "wind_wave_height,wind_wave_period,wind_wave_direction",
                 models=",".join(WAVE_MODELS), cell_selection="sea")
    enc = lambda q: urllib.parse.urlencode(q, safe=",")  # noqa: E731
    return ("https://api.open-meteo.com/v1/forecast?" + enc(weather),
            "https://marine-api.open-meteo.com/v1/marine?" + enc(marine),
            "https://marine-api.open-meteo.com/v1/marine?" + enc(waves))


def _fetch_metocean(beach, key):
    """MetService's forecast via the MetOcean Point Forecast API. The free
    plan serves their global models (the WW3 wave model on a 0.2 degree grid
    and global weather models), not the local Cook Strait models behind
    MetService's surf pages. Billing is per variable per request, so a week
    of hourly data for these 12 variables costs 12 units: about 35,000 a
    month at one fetch every 15 minutes, well inside the 500,000 free."""
    # Nudge the point ~2 km out to sea (towards where the swell comes from)
    # so the model's coastline doesn't treat it as land. (On the global grid
    # this barely changes the numbers.)
    lat, lng = _offset(beach.lat, beach.lng, beach.ideal_swell_deg, 2.0)
    start = datetime.fromtimestamp(time.time() - 24 * 3600, tz=timezone.utc).replace(minute=0, second=0, microsecond=0)
    body = json.dumps({
        "points": [{"lon": lng, "lat": lat}],
        "variables": METOCEAN_VARIABLES,
        "time": {"from": start.strftime("%Y-%m-%dT%H:%M:%SZ"), "interval": "1h", "repeat": 24 * 8},
    }).encode("utf-8")
    return _request("MetService", "https://forecast-v2.metoceanapi.com/point/time",
                    headers={"x-api-key": key, "Content-Type": "application/json", "Accept": "application/json"},
                    data=body)


def _fetch_metar(icao):
    q = urllib.parse.urlencode({"ids": icao, "format": "json", "hours": "3"})
    return _request("aviationweather.gov", "https://aviationweather.gov/api/data/metar?" + q)


def _fetch_niwa(beach, key):
    start = datetime.fromtimestamp(time.time() - 86400, tz=timezone.utc)
    q = urllib.parse.urlencode({
        "lat": "%.4f" % beach.lat, "long": "%.4f" % beach.lng, "numberOfDays": "8",
        "startDate": start.strftime("%Y-%m-%d"), "datum": "MSL", "interval": "15",
        # NIWA's gateway takes the key as a header or a query parameter; send both.
        "apikey": key,
    })
    return _request("NIWA", "https://api.niwa.co.nz/tides/data?" + q, headers={"x-apikey": key})


def fetch(beach, niwa_key="", metocean_key="", previous=None):
    """Downloads everything for a beach. previous is the last good raw fetch
    for the same beach: its tide predictions are reused while recent.
    Raises if Open-Meteo (the minimum needed) can't be reached."""
    weather_url, marine_url, waves_url = _open_meteo_urls(beach)
    station = nearest_station(beach)
    now = time.time()
    niwa_key = (niwa_key or "").strip()
    metocean_key = (metocean_key or "").strip()
    old = previous if (niwa_key and previous and previous.get("niwa") and previous.get("niwaFetchedAt")) else None
    niwa_age = None if old is None else now - old["niwaFetchedAt"] / 1000.0
    reuse_niwa = niwa_age is not None and 0 <= niwa_age < TIDE_REUSE

    with ThreadPoolExecutor(max_workers=6) as pool:
        weather = pool.submit(_request, "Open-Meteo", weather_url)
        marine = pool.submit(_request, "Open-Meteo marine", marine_url)
        waves = pool.submit(_optional, _request, "Open-Meteo waves", waves_url)
        niwa = pool.submit(_optional, _fetch_niwa, beach, niwa_key) if niwa_key and not reuse_niwa else None
        metar = pool.submit(_optional, _fetch_metar, station.icao) if station else None
        metocean = pool.submit(_optional, _fetch_metocean, beach, metocean_key) if metocean_key else None
        result = {
            "weather": weather.result(),
            "marine": marine.result(),
            "waves": waves.result(),
            "niwa": niwa.result() if niwa else None,
            "metar": metar.result() if metar else None,
            "metocean": metocean.result() if metocean else None,
        }

    # Tides: fresh download, else the recent copy, else (NIWA unreachable) a
    # copy up to a few days old, which still covers today.
    niwa_at = int(now * 1000) if result["niwa"] else None
    if result["niwa"] is None and niwa_age is not None and (reuse_niwa or niwa_age < TIDE_FALLBACK):
        result["niwa"] = old["niwa"]
        niwa_at = old["niwaFetchedAt"]
    result["niwaFetchedAt"] = niwa_at
    result["station"] = station.icao if (station and result["metar"]) else None
    result["fetchedAt"] = int(now * 1000)
    return result


# ---------------------------------------------------------------- parsing


def _times(values):
    return [float(v) for v in (values or [])]


def _floats(values, length):
    src = values or []
    out = []
    for i in range(length):
        v = src[i] if i < len(src) else None
        out.append(float(v) if v is not None else None)
    return out


def _aligned(block, key, hours):
    """A series from an Open-Meteo hourly block, lined up with hours."""
    times = _times(block.get("time"))
    src = _floats(block.get(key), len(times))
    index = {int(t): i for i, t in enumerate(times)}
    out = []
    for t in hours:
        i = index.get(int(t))
        out.append(None if i is None else src[i])
    return out


def median(values):
    """Middle value, ignoring gaps (mean of the middle two for an even count)."""
    v = sorted(x for x in values if x is not None)
    if not v:
        return None
    mid = len(v) // 2
    return v[mid] if len(v) % 2 else (v[mid - 1] + v[mid]) / 2


def mean_bearing(values):
    """Average of compass bearings, with vectors so 350 and 10 give 0."""
    v = [x for x in values if x is not None]
    if not v:
        return None
    x = sum(math.sin(math.radians(d)) for d in v)
    y = sum(math.cos(math.radians(d)) for d in v)
    if abs(x) < 1e-9 and abs(y) < 1e-9:
        return v[0]
    return math.degrees(math.atan2(x, y)) % 360


class _Waves:
    """One group of waves (the swell, or the wind chop) from one source, as
    hourly series lined up with the forecast hours."""
    __slots__ = ("height", "period", "direction")

    def __init__(self, height, period, direction):
        self.height = height
        self.period = period
        self.direction = direction

    @classmethod
    def of(cls, block, hours, prefix, model=None):
        """Open-Meteo series named like swell_wave_height[_model]."""
        suffix = "" if model is None else "_" + model
        return cls(_aligned(block, prefix + "_height" + suffix, hours),
                   _aligned(block, prefix + "_period" + suffix, hours),
                   _aligned(block, prefix + "_direction" + suffix, hours))

    @property
    def any(self):
        return any(v is not None for v in self.height)

    @staticmethod
    def average(sources, n, prefer_period_of=None):
        """Hour by hour: the mean height, and the height-weighted mean period
        and direction of the sources. prefer_period_of's period is used
        instead where it carries a fair share of the waves (MetService's is a
        true peak period, the free models' are averages, which read a couple
        of seconds short)."""
        h, t, d = [None] * n, [None] * n, [None] * n
        p = prefer_period_of
        for i in range(n):
            sum_h = sum_t = weight_t = x = y = 0.0
            count = 0
            for s in sources:
                if i >= len(s.height) or s.height[i] is None:
                    continue
                hi = s.height[i]
                sum_h += hi
                count += 1
                ti = s.period[i] if i < len(s.period) else None
                if ti is not None and ti > 0:
                    sum_t += ti * hi
                    weight_t += hi
                di = s.direction[i] if i < len(s.direction) else None
                if di is not None:
                    x += hi * math.sin(math.radians(di))
                    y += hi * math.cos(math.radians(di))
            if count == 0:
                continue
            h[i] = sum_h / count
            t[i] = sum_t / weight_t if weight_t > 0 else None
            if p is not None and i < len(p.height):
                ph, pt = p.height[i], p.period[i]
                if ph is not None and pt is not None and pt > 0 and ph >= 0.5 * h[i]:
                    t[i] = pt
            if abs(x) > 1e-9 or abs(y) > 1e-9:
                d[i] = math.degrees(math.atan2(x, y)) % 360
        return _Waves(h, t, d)


def _wave_consensus(j, hours):
    h = j["hourly"]

    def series(key):
        return _aligned(h, key, hours)

    def first_of(keys):
        all_series = [series(k) for k in keys]
        out = []
        for i in range(len(hours)):
            out.append(next((s[i] for s in all_series if s[i] is not None), None))
        return out

    heights, periods, dirs = {}, [], []
    for model_id, model_name in WAVE_MODELS.items():
        heights[model_name] = series("wave_height_" + model_id)
        # Surfers quote the peak period of the main swell; use the closest
        # thing each model offers.
        periods.append(first_of(["swell_wave_peak_period_" + model_id, "wave_peak_period_" + model_id,
                                 "swell_wave_period_" + model_id, "wave_period_" + model_id]))
        dirs.append(first_of(["swell_wave_direction_" + model_id, "wave_direction_" + model_id]))
    n = len(hours)
    return (
        [median([s[i] for s in heights.values()]) for i in range(n)],
        [median([s[i] for s in periods]) for i in range(n)],
        [mean_bearing([s[i] for s in dirs]) for i in range(n)],
        heights,
    )


def _iso_seconds(text):
    """Unix seconds for an ISO time such as 2026-11-22T03:00:00Z."""
    t = text.strip()
    if t.endswith("Z"):
        t = t[:-1] + "+00:00"
    d = datetime.fromisoformat(t)
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.timestamp()


def parse_metocean(body, hours):
    """MetService Point Forecast (v2) reply -> series per variable, lined up
    with hours. Values flagged as no-data come back as None."""
    j = json.loads(body)
    times = [int(round(_iso_seconds(t))) for t in j["dimensions"]["time"]["data"]]
    index = {t: i for i, t in enumerate(times)}
    variables = j["variables"]
    # Each value has a flag; the codes differ between replies, so look up the
    # one meaning "good" (normally 0).
    reasons = j.get("noDataReasons")
    good = reasons.get("GOOD") if isinstance(reasons, dict) else None
    good = int(good) if isinstance(good, (int, float)) and not isinstance(good, bool) else 0
    out = {}
    for vid in METOCEAN_VARIABLES:
        v = variables.get(vid) or {}
        data = v.get("data") or []
        no_data = v.get("noData") or []
        series = []
        for h in hours:
            i = index.get(int(round(h)))
            flag = no_data[i] if (i is not None and i < len(no_data) and no_data[i] is not None) else good
            if i is None or i >= len(data) or flag != good or not isinstance(data[i], (int, float)):
                series.append(None)
            else:
                series.append(float(data[i]))
        out[vid] = series
    return out


def parse_metar(body, station):
    """Latest observation from an aviationweather.gov METAR JSON list."""
    items = json.loads(body)
    if not isinstance(items, list) or not items:
        return None
    latest, latest_time = None, 0
    for item in items:
        if not isinstance(item, dict):
            continue
        t = int(item.get("obsTime") or 0)
        if t > latest_time:
            latest, latest_time = item, t
    if latest is None or latest_time == 0:
        return None
    knots = 1.852
    wspd = latest.get("wspd")
    if not isinstance(wspd, (int, float)):
        return None
    wdir = latest.get("wdir")
    gust = latest.get("wgst")
    temp = latest.get("temp")
    name = station.name if station else (latest.get("name") or latest.get("icaoId") or "Airport")
    return WindObservation(
        time=float(latest_time),
        station=name,
        speed=wspd * knots,
        gust=gust * knots if isinstance(gust, (int, float)) else None,
        # "VRB" (variable) or calm gives no usable direction.
        direction=float(wdir) if isinstance(wdir, (int, float)) and wspd >= 2 else None,
        temperature=float(temp) if isinstance(temp, (int, float)) else None,
    )


def _parse_niwa(body):
    j = json.loads(body)
    out = []
    for v in j["values"]:
        try:
            t = _iso_seconds(v["time"])
        except (KeyError, ValueError, AttributeError):
            continue
        level = v.get("value")
        if isinstance(level, (int, float)):
            out.append(TidePoint(t, float(level)))
    out.sort(key=lambda p: p.time)
    return out


def parse_forecast(raw):
    """Turns cached or fresh replies into a Forecast."""
    w = json.loads(raw["weather"])
    m = json.loads(raw["marine"])
    wh, mh = w["hourly"], m["hourly"]
    hours = _times(wh.get("time"))
    n = len(hours)

    def weather_series(key):
        return _floats(wh.get(key), n)

    def marine_series(key):
        return _aligned(mh, key, hours)

    codes = [None if v is None else int(round(v)) for v in weather_series("weather_code")]
    is_day = [None if v is None else v >= 0.5 for v in weather_series("is_day")]

    # Total wave height: middle value of the wave models, falling back to
    # Open-Meteo's single best match where the models have gaps.
    wave_height = marine_series("wave_height")
    best_swell_period = marine_series("swell_wave_period")
    best_wave_period = marine_series("wave_period")
    period = [a if a is not None else b for a, b in zip(best_swell_period, best_wave_period)]
    direction = marine_series("swell_wave_direction")
    model_heights = {}

    # The swell and the local wind chop, from every source that splits them.
    # What reaches the beach is worked out per beach (see rating.py): wind
    # chop made by an offshore wind is heading out to sea and doesn't count.
    swells, seas = {}, {}
    if raw.get("waves"):
        try:
            models = json.loads(raw["waves"])
            ch, cp, cd, per_model = _wave_consensus(models, hours)
            wave_height = [a if a is not None else b for a, b in zip(ch, wave_height)]
            period = [a if a is not None else b for a, b in zip(cp, period)]
            direction = [a if a is not None else b for a, b in zip(cd, direction)]
            model_heights.update(per_model)
            for model_id, model_name in WAVE_MODELS.items():
                sw = _Waves.of(models["hourly"], hours, "swell_wave", model_id)
                if sw.any:
                    swells[model_name] = sw
                sea = _Waves.of(models["hourly"], hours, "wind_wave", model_id)
                if sea.any:
                    seas[model_name] = sea
        except Exception:  # noqa: BLE001 - keep the best-match series
            pass

    wind_speed = weather_series("wind_speed_10m")
    wind_gust = weather_series("wind_gusts_10m")
    wind_direction = weather_series("wind_direction_10m")
    wind_source = "Open-Meteo forecast"

    # MetService (MetOcean), when a key is set: its swell and chop join the
    # averages, its swell period (a true peak period, as surf forecasts
    # quote) is used, and its wind replaces the free forecast.
    if raw.get("metocean"):
        try:
            mo = parse_metocean(raw["metocean"], hours)
            if any(v is not None for v in mo["wave.height"]):
                height = mo["wave.height"]
                wave_height = [height[i] if height[i] is not None else wave_height[i] for i in range(n)]
                model_heights["MetService"] = height
                sw = _Waves(mo["wave.height.above-8s"], mo["wave.period.above-8s.peak"],
                            mo["wave.direction.above-8s.peak"])
                if sw.any:
                    swells["MetService"] = sw
                sea = _Waves(mo["wave.height.below-8s"], mo["wave.period.below-8s.peak"],
                             mo["wave.direction.below-8s.peak"])
                if sea.any:
                    seas["MetService"] = sea
                if not sw.any:
                    # No split: fall back to the peak of all the waves.
                    peak, d = mo["wave.period.peak"], mo["wave.direction.peak"]
                    period = [peak[i] if peak[i] is not None else period[i] for i in range(n)]
                    direction = [d[i] if d[i] is not None else direction[i] for i in range(n)]
            if any(v is not None for v in mo["wind.speed.at-10m"]):
                ws, wg, wd = mo["wind.speed.at-10m"], mo["wind.speed.gust.at-10m"], mo["wind.direction.at-10m"]
                wind_speed = [wind_speed[i] if ws[i] is None else ws[i] * 3.6 for i in range(n)]
                wind_gust = [wind_gust[i] if wg[i] is None else wg[i] * 3.6 for i in range(n)]
                wind_direction = [wd[i] if wd[i] is not None else wind_direction[i] for i in range(n)]
                wind_source = "MetService's global forecast model"
        except Exception:  # noqa: BLE001 - keep the free sources
            pass

    # Open-Meteo's single best match stands in for the free models when
    # their split didn't come through.
    if all(k == "MetService" for k in swells):
        sw = _Waves.of(mh, hours, "swell_wave")
        if sw.any:
            swells["Open-Meteo"] = sw
    if all(k == "MetService" for k in seas):
        sea = _Waves.of(mh, hours, "wind_wave")
        if sea.any:
            seas["Open-Meteo"] = sea

    # Averaging the models' swell tracks MetService's surf page closely: on
    # their global model alone the swell reads low, the free models one high
    # and one low.
    swell = _Waves.average(list(swells.values()), n, prefer_period_of=swells.get("MetService"))
    sea = _Waves.average(list(seas.values()), n)
    swell_height = swell.height
    swell_period = [a if a is not None else b for a, b in zip(swell.period, period)]
    swell_direction = [a if a is not None else b for a, b in zip(swell.direction, direction)]

    # The swell on its own can't be bigger than all the waves together (the
    # sources come from different models).
    for i in range(n):
        if swell_height[i] is not None and wave_height[i] is not None and swell_height[i] > wave_height[i]:
            wave_height[i] = swell_height[i]

    names = sorted(swells, key=lambda k: k != "MetService")  # MetService first, the rest in order
    if not names:
        swell_source = "Open-Meteo"
    elif len(names) == 1:
        swell_source = "%s swell model" % names[0]
    else:
        swell_source = "Average of %s and %s swell models" % (", ".join(names[:-1]), names[-1])

    tide, tide_source = [], "Open-Meteo sea level model"
    if raw.get("niwa"):
        try:
            tide = _parse_niwa(raw["niwa"])
            if len(tide) > 8:
                tide_source = "NIWA tide predictions"
        except Exception:  # noqa: BLE001
            tide = []
    if len(tide) <= 8:
        q = m.get("minutely_15")
        if q:
            t = _times(q.get("time"))
            v = _floats(q.get("sea_level_height_msl"), len(t))
            tide = [TidePoint(t[i], v[i]) for i in range(len(t)) if v[i] is not None]
        tide_source = "Open-Meteo sea level model"

    observation = None
    if raw.get("metar"):
        try:
            observation = parse_metar(raw["metar"], station_by_icao(raw.get("station")))
        except Exception:  # noqa: BLE001
            observation = None

    return Forecast(
        fetched_at=raw["fetchedAt"] / 1000.0,
        hours=hours,
        air_temp=weather_series("temperature_2m"),
        weather_code=codes,
        is_day=is_day,
        wind_speed=wind_speed,
        wind_gust=wind_gust,
        wind_direction=wind_direction,
        wave_height=wave_height,
        wave_period=best_wave_period,
        swell_height=swell_height,
        swell_period=swell_period,
        swell_direction=swell_direction,
        sea_height=sea.height,
        sea_period=sea.period,
        sea_direction=sea.direction,
        sea_temp=marine_series("sea_surface_temperature"),
        tide=tide,
        tide_source=tide_source,
        model_heights=model_heights,
        model_swell_heights={k: v.height for k, v in swells.items()},
        observation=observation,
        swell_source=swell_source,
        wind_source=wind_source,
    )
