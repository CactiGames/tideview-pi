"""TideView's side of automatic updates. The updater itself is tvupdate.py,
next to tideview.py, and runs as its own service. This module reads its
state for Settings, asks it to check now, and tells it once this version
has proved itself by running for a few minutes."""

import json
import os
import subprocess
import time

from . import settings as settings_mod
from .version import VERSION

PROVE_AFTER = 180  # seconds of running before this version counts as working
UPDATE_UNIT = "/etc/systemd/system/tideview-update.service"


def _path(name):
    return os.path.join(settings_mod.state_dir(), name)


def read_state():
    try:
        with open(_path("update.json"), encoding="utf-8") as f:
            st = json.load(f)
        return st if isinstance(st, dict) else {}
    except (OSError, ValueError):
        return {}


def available():
    """True on a Pi where install.sh has set up the updater."""
    return os.path.exists(UPDATE_UNIT) and hasattr(os, "geteuid") and os.geteuid() == 0


def request_check():
    """Asks the updater to check now, and to install a new version straight
    away. Returns False if it can't be asked."""
    if not available():
        return False
    try:
        with open(_path("update-request"), "w") as f:
            f.write("%d\n" % time.time())
        subprocess.run(["systemctl", "start", "--no-block", "tideview-update.service"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def mark_working():
    """Tells the updater that this version works, so it's kept."""
    path = _path("running-ok")
    try:
        with open(path + ".tmp", "w") as f:
            f.write(VERSION + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def _alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except (TypeError, ValueError, OverflowError, ProcessLookupError):
        return False
    except (PermissionError, AttributeError):
        return True


def _when(t, now, clock):
    if time.localtime(t)[:3] == time.localtime(now)[:3]:
        return "at %s" % clock(t)
    return "on %s at %s" % (time.strftime("%a %d %b", time.localtime(t)).replace(" 0", " "), clock(t))


def _hour(h, clock):
    lt = time.localtime()
    return clock(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, h % 24, 0, 0, 0, 0, -1)))


def schedule_text(st, clock):
    """When updates install by themselves."""
    if not st.get("auto", True):
        return "Updates only install when you tap Check for updates now (set in /etc/tideview/update.conf)."
    q = st.get("quiet") or [2, 5]
    return "Updates also install by themselves, between %s and %s." % (_hour(q[0], clock), _hour(q[1], clock))


def busy_text(st, now):
    b = st.get("busy")
    if isinstance(b, dict) and _alive(b.get("pid")) and now - float(b.get("since") or 0) < 1800:
        return b.get("text") or "Checking for updates..."
    return None


def describe(st, now, clock):
    """What Settings says about updates. clock formats a timestamp."""
    if not st and not available():
        return "On the Pi, TideView updates itself once install.sh has set that up."
    busy = busy_text(st, now)
    if busy:
        return busy
    parts = []
    ev = st.get("event") if isinstance(st.get("event"), dict) else {}
    age = now - float(ev.get("at") or 0)
    if ev.get("kind") == "rollback" and age < 7 * 86400:
        parts.append("Version %s didn't start properly %s, so TideView went back to %s and won't try %s again."
                     % (ev.get("from"), _when(ev.get("at", now), now, clock), ev.get("to"), ev.get("from")))
    elif ev.get("kind") == "update" and ev.get("to") == VERSION and age < 3 * 86400:
        parts.append("Updated to this version %s." % _when(ev.get("at", now), now, clock))
        if ev.get("notes"):
            parts.append("New: %s" % ev["notes"])
    staged = st.get("staged")
    if staged and staged != VERSION:
        if st.get("auto", True):
            q = st.get("quiet") or [2, 5]
            parts.append("Version %s is ready. It installs between %s and %s, or tap Check for updates now."
                         % (staged, _hour(q[0], clock), _hour(q[1], clock)))
        else:
            parts.append("Version %s is ready. Tap Check for updates now to install it." % staged)
    last_check = float(st.get("last_check") or 0)
    if st.get("last_error") and float(st.get("last_error_at") or 0) >= last_check:
        parts.append("The last check, %s, didn't work: %s. It tries again every hour."
                     % (_when(st["last_error_at"], now, clock), st["last_error"]))
    elif last_check and not staged:
        parts.append("Up to date. Last checked %s." % _when(last_check, now, clock))
    elif not last_check:
        parts.append("Checks for updates every hour.")
    return " ".join(parts)


def announcement(now):
    """A message about an update or rollback that just happened, once."""
    st = read_state()
    ev = st.get("event")
    if not isinstance(ev, dict) or ev.get("to") != VERSION or now - float(ev.get("at") or 0) > 6 * 3600:
        return None
    if ev.get("kind") == "update":
        text = "TideView updated itself to version %s." % VERSION
        if ev.get("notes"):
            text += " New: %s" % ev["notes"]
    elif ev.get("kind") == "rollback":
        text = "A new version of TideView didn't start properly, so it went back to version %s." % VERSION
    else:
        return None
    shown = _path("update-shown")
    try:
        with open(shown, encoding="utf-8") as f:
            if f.read().strip() == str(ev.get("id")):
                return None
    except OSError:
        pass
    try:
        with open(shown, "w", encoding="utf-8") as f:
            f.write("%s\n" % ev.get("id"))
    except OSError:
        pass
    return text
