"""Small facts about the Pi for the settings screen, and power actions."""

import os
import socket
import subprocess


def ip_address():
    """This Pi's address on the home network, or None when offline."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 9))  # no packet is sent; it just picks the route
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


def hostname():
    return socket.gethostname()


def cpu_temperature():
    """Degrees C, or None when not on a Pi."""
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            return int(f.read().strip()) / 1000.0
    except (OSError, ValueError):
        return None


def power_problems():
    """Plain words for the Pi's power and heat warnings, or None if fine or
    unknown. Uses vcgencmd get_throttled."""
    try:
        out = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=3).stdout
        value = int(out.strip().split("=")[1], 16)
    except (OSError, ValueError, IndexError, subprocess.SubprocessError):
        return None
    now, before = [], []
    if value & 0x1:
        now.append("the power supply is too weak right now")
    if value & 0x4 or value & 0x8:
        now.append("it's too hot right now")
    if value & 0x10000 and not value & 0x1:
        before.append("the power dipped since start-up")
    if (value & 0x40000 or value & 0x80000) and not (value & 0x4 or value & 0x8):
        before.append("it got too hot since start-up")
    if not now and not before:
        return "No power or heat problems since start-up."
    return "Warning: " + "; ".join(now + before) + "."


def uptime_hours():
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0]) / 3600
    except (OSError, ValueError, IndexError):
        return None


def _is_root():
    return hasattr(os, "geteuid") and os.geteuid() == 0


def shutdown():
    """Shuts the Pi down safely (wait for the green light to stop before
    unplugging)."""
    if _is_root():
        subprocess.Popen(["systemctl", "poweroff"])
        return True
    return False


def reboot():
    if _is_root():
        subprocess.Popen(["systemctl", "reboot"])
        return True
    return False
