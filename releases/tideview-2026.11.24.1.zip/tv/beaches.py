"""NZ surf breaks and the swell and wind directions that suit each one.

Same list as the Android app (lib/data/beaches.dart): name, region, latitude,
longitude, best swell direction (where it comes FROM), offshore wind direction
(where it blows FROM) and the part of the tide the break prefers."""

from .compass import degrees as _deg


class Beach:
    __slots__ = ("name", "region", "lat", "lng", "ideal_swell", "ideal_wind", "tide",
                 "id", "ideal_swell_deg", "ideal_wind_deg")

    def __init__(self, name, region, lat, lng, ideal_swell, ideal_wind, tide):
        self.name = name
        self.region = region
        self.lat = lat
        self.lng = lng
        self.ideal_swell = ideal_swell
        self.ideal_wind = ideal_wind
        self.tide = tide  # "any", "low" or "high"
        self.id = region + "/" + name  # saved as the preferred beach
        self.ideal_swell_deg = _deg(ideal_swell)
        self.ideal_wind_deg = _deg(ideal_wind)

    def __repr__(self):
        return "Beach(%r)" % self.id


BEACHES = [
    Beach('Lyall Bay', 'Wellington', -41.3399, 174.7943, 'S', 'NW', 'any'),
    Beach('Houghton Bay', 'Wellington', -41.3434, 174.7849, 'S', 'N', 'any'),
    Beach('Breaker Bay', 'Wellington', -41.3309, 174.8336, 'S', 'NW', 'any'),
    Beach('Eastbourne', 'Wellington', -41.315, 174.8769, 'S', 'ENE', 'any'),
    Beach('Tihati Bay', 'Wellington', -41.1061, 174.8341, 'NW', 'SE', 'any'),
    Beach('Plimmerton Beach', 'Wellington', -41.087, 174.8653, 'NW', 'E', 'high'),
    Beach('Pukerua Bay', 'Wellington', -41.0288, 174.8947, 'NW', 'SE', 'high'),
    Beach('Paekakariki Beach', 'Wellington', -40.9806, 174.9526, 'NW', 'SE', 'any'),
    Beach('Waikanae Beach', 'Wellington', -40.8605, 175.0197, 'NW', 'ESE', 'any'),
    Beach('Otaki', 'Wellington', -40.7373, 175.1141, 'NW', 'SE', 'any'),
    Beach('South Beach', 'Whanganui', -39.9647, 175.0127, 'SW', 'NE', 'any'),
    Beach('North Mole', 'Whanganui', -39.9472, 174.9797, 'SW', 'NE', 'any'),
    Beach('Castlecliff Beach', 'Whanganui', -39.9405, 174.9743, 'SW', 'NE', 'any'),
    Beach('Kai Iwi', 'Whanganui', -39.8876, 174.8983, 'SW', 'NE', 'any'),
    Beach('Waiinui Beach', 'Whanganui', -39.8676, 174.7474, 'SW', 'N', 'any'),
    Beach('Waverley', 'Taranaki', -39.8342, 174.6348, 'SW', 'NE', 'any'),
    Beach('Patea River Mouth', 'Taranaki', -39.772, 174.4841, 'SW', 'NE', 'any'),
    Beach('Opunake Beach', 'Taranaki', -39.459, 173.855, 'SW', 'NE', 'high'),
    Beach('Oakura Beach', 'Taranaki', -39.1122, 173.9481, 'W', 'SE', 'any'),
    Beach('Back Beach', 'Taranaki', -39.0686, 174.0177, 'SW', 'E', 'any'),
    Beach('Belt Road', 'Taranaki', -39.0567, 174.0557, 'SW', 'SE', 'any'),
    Beach('East End Beach', 'Taranaki', -39.0456, 174.0906, 'SW', 'SE', 'high'),
    Beach('Fitzroy', 'Taranaki', -39.0443, 174.0969, 'W', 'SE', 'any'),
    Beach('The Groyne', 'Taranaki', -39.0374, 174.1031, 'W', 'SE', 'any'),
    Beach('Bell Block', 'Taranaki', -39.0177, 174.1485, 'SW', 'S', 'low'),
    Beach('Waitara Beach', 'Taranaki', -38.9863, 174.2334, 'SW', 'SE', 'any'),
    Beach('Mokau', 'Taranaki', -38.6988, 174.6144, 'SW', 'W', 'any'),
    Beach('Awakino', 'Taranaki', -38.6667, 174.6171, 'SW', 'E', 'any'),
    Beach('Kiritehere', 'Waikato', -38.3233, 174.7071, 'SW', 'E', 'any'),
    Beach('Ruapuke Beach', 'Waikato', -37.9003, 174.7661, 'NW', 'E', 'high'),
    Beach('Whale Bay', 'Waikato', -37.8224, 174.8006, 'SW', 'SE', 'high'),
    Beach('Manu Bay', 'Waikato', -37.8223, 174.8176, 'SW', 'SE', 'any'),
    Beach('Ngarunui Beach', 'Waikato', -37.8181, 174.8267, 'NW', 'E', 'high'),
    Beach('Sunset Beach', 'Waikato', -37.3971, 174.7097, 'SW', 'E', 'any'),
    Beach('Karioitahi Beach', 'Auckland West', -37.2842, 174.6518, 'SW', 'E', 'any'),
    Beach('Karekare Beach', 'Auckland West', -36.9884, 174.4686, 'N', 'N', 'any'),
    Beach('South Piha Beach', 'Auckland West', -36.9566, 174.4653, 'N', 'N', 'any'),
    Beach('North Piha Beach', 'Auckland West', -36.9435, 174.4613, 'WNW', 'ENE', 'any'),
    Beach('Anawhata', 'Auckland West', -36.9312, 174.4543, 'W', 'ENE', 'any'),
    Beach('Te Henga/Bethells Beach', 'Auckland West', -36.8933, 174.4421, 'W', 'E', 'any'),
    Beach('Muriwai Beach', 'Auckland West', -36.8289, 174.4245, 'W', 'E', 'any'),
    Beach('Baylys Beach', 'Northland West', -35.9544, 173.7406, 'SW', 'ENE', 'any'),
    Beach('Shipwreck Bay', 'Northland West', -35.1777, 173.1209, 'SW', 'S', 'low'),
    Beach('Ninety Mile Beach', 'Northland West', -34.7203, 172.9263, 'NW', 'ENE', 'any'),
    Beach('Scott Point/Kahokawa Beach', 'Northland West', -34.5289, 172.7261, 'SW', 'E', 'high'),
    Beach('Twilight Beach', 'Northland West', -34.4969, 172.6935, 'SW', 'NE', 'high'),
    Beach('Tapotupotu Beach', 'Northland East', -34.4357, 172.7138, 'N', 'S', 'any'),
    Beach('Spirits Bay', 'Northland East', -34.4441, 172.833, 'N', 'SE', 'any'),
    Beach('Rarawa Beach', 'Northland East', -34.7472, 173.0786, 'NE', 'SW', 'any'),
    Beach('Henderson Bay', 'Northland East', -34.7408, 173.1185, 'NE', 'SW', 'any'),
    Beach('Puheke Beach', 'Northland East', -34.8594, 173.3219, 'N', 'S', 'any'),
    Beach('Tokerau Beach', 'Northland East', -34.8807, 173.3761, 'E', 'W', 'any'),
    Beach('Taipa Bay', 'Northland East', -34.9921, 173.4654, 'NE', 'S', 'any'),
    Beach('Taupo Bay', 'Northland East', -34.9935, 173.7133, 'ENE', 'SSW', 'any'),
    Beach('Matauri Bay', 'Northland East', -35.0351, 173.9149, 'E', 'W', 'any'),
    Beach('Elliot Bay', 'Northland East', -35.2746, 174.2904, 'E', 'W', 'any'),
    Beach('Bland Bay', 'Northland East', -35.3422, 174.3538, 'NE', 'W', 'any'),
    Beach('Oakura Bay', 'Northland East', -35.3908, 174.3464, 'E', 'W', 'any'),
    Beach('Sandy Bay', 'Northland East', -35.5556, 174.4758, 'NE', 'SW', 'any'),
    Beach('Ngunguru', 'Northland East', -35.6393, 174.5109, 'NE', 'NW', 'any'),
    Beach('Pataua Bar', 'Northland East', -35.7093, 174.522, 'NE', 'SW', 'any'),
    Beach('Ocean Beach', 'Northland East', -35.8217, 174.5682, 'E', 'SW', 'any'),
    Beach('Ruakaka Beach', 'Northland East', -35.909, 174.4624, 'E', 'W', 'any'),
    Beach('Waipu Cove', 'Northland East', -36.0268, 174.5068, 'ENE', 'SW', 'any'),
    Beach('Langs Beach', 'Northland East', -36.0442, 174.5349, 'NE', 'SW', 'any'),
    Beach('Mangawhai Beach', 'Northland East', -36.0799, 174.5999, 'E', 'W', 'any'),
    Beach('Omaha Beach', 'Auckland East', -36.3384, 174.783, 'E', 'W', 'any'),
    Beach('Tawharanui', 'Auckland East', -36.3656, 174.8298, 'NNE', 'S', 'any'),
    Beach('Oneroa Bay', 'Auckland East', -36.7815, 175.012, 'NNE', 'SW', 'any'),
    Beach('Orewa Beach', 'Auckland East', -36.5848, 174.6984, 'NE', 'WSW', 'any'),
    Beach('Waikawau', 'Coromandel', -36.5998, 175.5312, 'NE', 'WSW', 'any'),
    Beach('New Chums', 'Coromandel', -36.6971, 175.6077, 'NE', 'SW', 'any'),
    Beach('Whangapoua', 'Coromandel', -36.7106, 175.6137, 'NE', 'SW', 'any'),
    Beach('Matarangi', 'Coromandel', -36.7243, 175.6453, 'N', 'S', 'any'),
    Beach('Kuaotunu', 'Coromandel', -36.7223, 175.7223, 'N', 'S', 'any'),
    Beach('Otama Beach', 'Coromandel', -36.7072, 175.7468, 'N', 'S', 'high'),
    Beach('Opito Bay', 'Coromandel', -36.7144, 175.7963, 'NE', 'W', 'any'),
    Beach('Whitianga', 'Coromandel', -36.8235, 175.7051, 'ENE', 'SW', 'any'),
    Beach('Hahei', 'Coromandel', -36.838, 175.8073, 'E', 'SW', 'high'),
    Beach('Hot Water Beach', 'Coromandel', -36.8819, 175.8207, 'NE', 'SW', 'any'),
    Beach('Tairua Beach', 'Coromandel', -36.9921, 175.8607, 'NE', 'SW', 'high'),
    Beach('Pauanui', 'Coromandel', -37.0165, 175.8693, 'ENE', 'SW', 'any'),
    Beach('Onemana', 'Coromandel', -37.1511, 175.8816, 'E', 'W', 'any'),
    Beach('Whangamata Beach', 'Coromandel', -37.2099, 175.8791, 'NE', 'SW', 'any'),
    Beach('Whiritoa', 'Coromandel', -37.2841, 175.905, 'ENE', 'WSW', 'any'),
    Beach('Waihi Beach', 'Bay of Plenty', -37.3995, 175.9425, 'NE', 'SW', 'any'),
    Beach('Bowentown', 'Bay of Plenty', -37.462, 175.9883, 'NE', 'SW', 'any'),
    Beach('Maunganui', 'Bay of Plenty', -37.6306, 176.1801, 'NE', 'SW', 'any'),
    Beach('Shark Alley', 'Bay of Plenty', -37.6322, 176.1859, 'NE', 'SW', 'high'),
    Beach('Tay Street', 'Bay of Plenty', -37.6459, 176.2007, 'NE', 'WSW', 'any'),
    Beach('Arataki', 'Bay of Plenty', -37.6719, 176.2377, 'NE', 'SW', 'any'),
    Beach('Papamoa', 'Bay of Plenty', -37.6964, 176.2889, 'NE', 'SW', 'any'),
    Beach('Maketu Beach', 'Bay of Plenty', -37.7538, 176.4566, 'NE', 'S', 'high'),
    Beach('Pukehina Beach', 'Bay of Plenty', -37.7568, 176.482, 'NE', 'SW', 'any'),
    Beach('Matata', 'Bay of Plenty', -37.8856, 176.7632, 'NE', 'SW', 'any'),
    Beach('Opotiki', 'East Cape', -37.9906, 177.286, 'N', 'S', 'any'),
    Beach('Totere', 'East Cape', -37.9482, 177.4874, 'NNW', 'S', 'low'),
    Beach('Waihau Bay', 'East Cape', -37.6138, 177.9541, 'N', 'S', 'any'),
    Beach('Hicks Bay', 'East Cape', -37.5849, 178.2966, 'E', 'W', 'high'),
    Beach('Waipiro Bay', 'East Cape', -38.0215, 178.3362, 'E', 'W', 'any'),
    Beach('Tokomaru Bay', 'East Cape', -38.1334, 178.3187, 'SE', 'NW', 'high'),
    Beach('Tolaga Bay', 'Gisborne', -38.3697, 178.3087, 'E', 'W', 'any'),
    Beach('Wainui Beach', 'Gisborne', -38.6841, 178.0777, 'E', 'NW', 'high'),
    Beach('Sponge Bay', 'Gisborne', -38.6998, 178.058, 'SE', 'NNW', 'any'),
    Beach('Midway Beach', 'Gisborne', -38.6717, 178.0053, 'SSE', 'N', 'any'),
    Beach('Mahanga Beach', 'Gisborne', -39.0162, 177.8864, 'E', 'W', 'any'),
    Beach('Opoutama Beach', 'Gisborne', -39.0606, 177.8375, 'S', 'NE', 'any'),
    Beach('Mohaka River', "Hawke's Bay", -39.125, 177.1972, 'SE', 'N', 'any'),
    Beach('Waipatiki Beach', "Hawke's Bay", -39.3019, 176.9767, 'SE', 'NW', 'high'),
    Beach('Stingray Bay', "Hawke's Bay", -39.3372, 176.9363, 'E', 'NW', 'high'),
    Beach('Tangoio Beach', "Hawke's Bay", -39.3378, 176.9222, 'SE', 'NW', 'high'),
    Beach('Westshore', "Hawke's Bay", -39.475, 176.8831, 'NE', 'W', 'low'),
    Beach('Awatoto', "Hawke's Bay", -39.5412, 176.9213, 'E', 'W', 'any'),
    Beach('Haumoana', "Hawke's Bay", -39.6065, 176.9522, 'E', 'W', 'any'),
    Beach('Ocean Beach', "Hawke's Bay", -39.7437, 177.0128, 'SE', 'W', 'any'),
    Beach('Whakataki', 'Wairarapa', -40.8671, 176.2348, 'E', 'W', 'high'),
    Beach('Castlepoint', 'Wairarapa', -40.8969, 176.2216, 'NE', 'SW', 'low'),
    Beach('The Gap', 'Wairarapa', -40.9075, 176.221, 'SE', 'NW', 'any'),
    Beach('Riversdale Beach', 'Wairarapa', -41.0887, 176.0757, 'ESE', 'NW', 'any'),
    Beach('White Rock Point', 'Wairarapa', -41.5694, 175.3904, 'SE', 'NW', 'high'),
    Beach('Pines Beach', 'Canterbury', -43.3804, 172.7142, 'SE', 'NW', 'any'),
    Beach('New Brighton', 'Canterbury', -43.5092, 172.7348, 'NE', 'W', 'any'),
    Beach('South Shore', 'Canterbury', -43.5528, 172.7531, 'NE', 'W', 'high'),
    Beach('Sumner', 'Canterbury', -43.5668, 172.7614, 'ENE', 'SW', 'high'),
    Beach("Taylor's Mistake", 'Canterbury', -43.5835, 172.7774, 'ENE', 'SW', 'any'),
]

DEFAULT_BEACH_ID = "Wellington/Lyall Bay"


def beach_by_id(beach_id):
    """The beach with this id, or Lyall Bay if it is unknown."""
    for b in BEACHES:
        if b.id == beach_id:
            return b
    for b in BEACHES:
        if b.id == DEFAULT_BEACH_ID:
            return b
    return BEACHES[0]


def regions():
    """Region names in list order."""
    seen = []
    for b in BEACHES:
        if b.region not in seen:
            seen.append(b.region)
    return seen
