"""Frame size and position (developer setting): shrink the picture to a box
of a set physical size and position, with the rest of the screen black, to
match the window of a picture frame. Same idea as the Android app's
Settings > Developer > Frame size and position.

Sizes are real millimetres, worked out from the screen's diagonal (7" for
the Jaycar panel). If a ruler disagrees, change the diagonal in Settings.
"""

import math

import pygame

from .display import draw_sea
from .gfx import NIGHT, WHITE, blit_text

MM_PER_INCH = 25.4
MIN_SIDE = 120  # smallest box side, pixels


def format_length(mm, cm):
    return "%.1f cm" % (mm / 10) if cm else "%.2f in" % (mm / MM_PER_INCH)


class FrameGeometry:
    def __init__(self, settings, panel_size):
        self.settings = settings
        self.panel_size = panel_size

    @property
    def ppi(self):
        diag = self.settings["screenDiagonalIn"] or 7.0
        pw, ph = self.panel_size
        return math.hypot(pw, ph) / diag

    @property
    def px_per_mm(self):
        return self.ppi / MM_PER_INCH

    @property
    def snap_mm(self):
        """Step for dragging and the +/- buttons: 1 mm, or 0.05 in."""
        return 1.0 if self.settings["frameInCm"] else MM_PER_INCH / 20

    def box(self, screen):
        """The box on a screen of (w, h) pixels, kept on screen."""
        sw, sh = screen
        s = self.settings
        if s["frameWidthMm"] is None or s["frameHeightMm"] is None:
            r = pygame.Rect(0, 0, int(sw * 0.8), int(sh * 0.8))
            r.center = (sw // 2, sh // 2)
        else:
            k = self.px_per_mm
            r = pygame.Rect(int(round((s["frameLeftMm"] or 0) * k)), int(round((s["frameTopMm"] or 0) * k)),
                            int(round(s["frameWidthMm"] * k)), int(round(s["frameHeightMm"] * k)))
        return clamp_to_screen(r, screen)

    def save(self, rect):
        k = self.px_per_mm
        self.settings.set(frameLeftMm=round(rect.x / k, 2), frameTopMm=round(rect.y / k, 2),
                          frameWidthMm=round(rect.w / k, 2), frameHeightMm=round(rect.h / k, 2))

    def mm(self, rect):
        k = self.px_per_mm
        return rect.x / k, rect.y / k, rect.w / k, rect.h / k

    def nudge(self, screen, field, steps):
        """Grows or moves the box by a number of snap steps."""
        r = self.box(screen)
        d = steps * self.snap_mm * self.px_per_mm
        x, y, w, h = float(r.x), float(r.y), float(r.w), float(r.h)
        if field == "w":
            w += d
        elif field == "h":
            h += d
        elif field == "x":
            x += d
        elif field == "y":
            y += d
        nr = clamp_to_screen(pygame.Rect(int(round(x)), int(round(y)), int(round(w)), int(round(h))), screen)
        self.save(nr)
        if not self.settings["frameEnabled"]:
            self.settings.set(frameEnabled=True)


def clamp_to_screen(r, screen):
    sw, sh = screen
    w = min(max(r.w, min(MIN_SIDE, sw)), sw)
    h = min(max(r.h, min(MIN_SIDE, sh)), sh)
    x = min(max(r.x, 0), sw - w)
    y = min(max(r.y, 0), sh - h)
    return pygame.Rect(x, y, w, h)


class FrameEditor:
    """Drag the box's corners to resize it and its middle to move it. Uses
    the whole screen, whatever the current box."""

    full_screen = True

    def __init__(self, app):
        self.app = app
        self.g = app.gfx
        self.geo = app.frame_geometry
        self._drag = None  # live rect while dragging
        self._grab = None
        self._start = None
        self._start_rect = None
        self._dirty = True
        self._buttons = {}
        if not app.settings["frameEnabled"]:
            app.settings.set(frameEnabled=True)

    def invalidate(self):
        self._dirty = True

    def needs_render(self, now):
        return self._dirty

    def next_change(self, now):
        return now + 3600

    def render(self, canvas, now):
        self._dirty = False
        g = self.g
        sw, sh = canvas.get_size()
        u = min(sw, sh) / 600
        rect = self._drag or self.geo.box((sw, sh))
        canvas.fill((0, 0, 0))
        sea = pygame.Surface(rect.size, 0, 32)  # its own surface: see draw_sea
        draw_sea(sea, (0x2F, 0x8C, 0x44), 0.55, 0.0, 0)
        canvas.blit(sea, rect.topleft)
        cm = self.app.settings["frameInCm"]
        lx, ty, bw, bh = self.geo.mm(rect)
        rx = (sw - rect.right) / self.geo.px_per_mm
        by = (sh - rect.bottom) / self.geo.px_per_mm
        # Info panel in the middle of the box.
        lines = [
            ("%s wide, %s tall" % (format_length(bw, cm), format_length(bh, cm)), 24 * u, True),
            ("Gaps: left %s, right %s" % (format_length(lx, cm), format_length(rx, cm)), 17 * u, False),
            ("top %s, bottom %s" % (format_length(ty, cm), format_length(by, cm)), 17 * u, False),
            ("Drag a corner to resize, the middle to move.", 15 * u, False),
        ]
        bsize = 19 * u
        labels = [("units", "cm" if not cm else "in"), ("centre", "Centre"), ("full", "Full screen"), ("done", "Done")]
        bwid = [g.text_size(t, bsize)[0] + 30 * u for _, t in labels]
        row_w = sum(bwid) + 10 * u * (len(labels) - 1)
        pw = max(max(g.text_size(t, s, b)[0] for t, s, b in lines), row_w) + 40 * u
        ph = sum(s * 1.35 for _, s, _ in lines) + 54 * u + 36 * u
        scale = min(1.0, (rect.w - 16 * u) / pw, (rect.h - 16 * u) / ph)
        panel = pygame.Surface((int(pw), int(ph)), pygame.SRCALPHA)
        pygame.draw.rect(panel, NIGHT + (0xE8,), panel.get_rect(), border_radius=int(18 * u))
        y = 18 * u
        for t, s, b in lines:
            blit_text(panel, g, t, s, pw / 2, y, bold=b, anchor="tc", opacity=1.0 if b else 0.85)
            y += s * 1.35
        y += 14 * u
        x = (pw - row_w) / 2
        self._buttons = {}
        btn_rects = {}
        for (key, t), wdt in zip(labels, bwid):
            br = pygame.Rect(int(x), int(y), int(wdt), int(42 * u))
            pygame.draw.rect(panel, (0x2F, 0x8C, 0x44) if key == "done" else (0x26, 0x30, 0x56), br,
                             border_radius=int(12 * u))
            blit_text(panel, g, t, bsize, br.centerx, br.centery + 1 * u, anchor="mc")
            btn_rects[key] = br
            x += wdt + 10 * u
        if scale < 1.0:
            panel = pygame.transform.smoothscale(panel, (max(1, int(pw * scale)), max(1, int(ph * scale))))
        px = rect.centerx - panel.get_width() // 2
        py = rect.centery - panel.get_height() // 2
        canvas.blit(panel, (px, py))
        for key, br in btn_rects.items():
            self._buttons[key] = pygame.Rect(int(px + br.x * scale), int(py + br.y * scale),
                                             int(br.w * scale), int(br.h * scale)).inflate(int(8 * u), int(8 * u))
        # Outline and corner handles.
        pygame.draw.rect(canvas, WHITE, rect, 2)
        for cpt in (rect.topleft, (rect.right - 1, rect.top), (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1)):
            handle = g.disc(30 * u, WHITE, ring=NIGHT, ring_width=0)
            canvas.blit(handle, (cpt[0] - handle.get_width() // 2, cpt[1] - handle.get_height() // 2))
        return [canvas.get_rect()]

    def on_touch(self, kind, x, y, now):
        sw, sh = self.app.screen_size
        rect = self._drag or self.geo.box((sw, sh))
        u = min(sw, sh) / 600
        if kind == "down":
            for key, br in self._buttons.items():
                if br.collidepoint(x, y):
                    self._grab = ("button", key)
                    return
            self._grab = self._grab_at(x, y, rect, 50 * u)
            self._start = (x, y)
            self._start_rect = pygame.Rect(rect)
            return
        if self._grab is None:
            return
        if self._grab[0] == "button":
            if kind == "up":
                key = self._grab[1]
                self._grab = None
                for k2, br in self._buttons.items():
                    if k2 == key and br.collidepoint(x, y):
                        self._press(key, (sw, sh), rect)
            return
        if kind == "move":
            self._drag = self._dragged(x - self._start[0], y - self._start[1], (sw, sh))
            self._dirty = True
        elif kind == "up":
            if self._drag is not None:
                self.geo.save(self._drag)
                self.app.frame_changed()
            self._drag = None
            self._grab = None
            self._dirty = True

    def _press(self, key, screen, rect):
        s = self.app.settings
        if key == "units":
            s.set(frameInCm=not s["frameInCm"])
        elif key == "centre":
            r = pygame.Rect(rect)
            r.center = (screen[0] // 2, screen[1] // 2)
            self.geo.save(clamp_to_screen(r, screen))
        elif key == "full":
            self.geo.save(pygame.Rect(0, 0, screen[0], screen[1]))
        elif key == "done":
            self.app.close_screen()
            return
        self.app.frame_changed()
        self._dirty = True

    @staticmethod
    def _grab_at(x, y, r, reach):
        corners = {"tl": r.topleft, "tr": (r.right, r.top), "bl": (r.left, r.bottom), "br": (r.right, r.bottom)}
        best, best_d = None, reach
        for k, (cx, cy) in corners.items():
            d = math.hypot(x - cx, y - cy)
            if d < best_d:
                best, best_d = k, d
        if best:
            return ("corner", best)
        return ("move", None) if r.collidepoint(x, y) else None

    def _dragged(self, dx, dy, screen):
        """The box after dragging, snapped to whole millimetres (or 1/20 in)
        and kept on screen."""
        sw, sh = screen
        k = self.geo.px_per_mm
        step = self.geo.snap_mm

        def snap(px):
            return round(px / k / step) * step * k

        r0 = self._start_rect
        min_w, min_h = min(MIN_SIDE, sw), min(MIN_SIDE, sh)
        if self._grab[0] == "move":
            x = min(max(snap(r0.x + dx), 0), sw - r0.w)
            y = min(max(snap(r0.y + dy), 0), sh - r0.h)
            return pygame.Rect(int(round(x)), int(round(y)), r0.w, r0.h)
        left, top, right, bottom = r0.left, r0.top, r0.right, r0.bottom
        corner = self._grab[1]
        if "l" in corner:
            left = min(max(snap(left + dx), 0), right - min_w)
        if "r" in corner:
            right = min(max(snap(right + dx), left + min_w), sw)
        if "t" in corner:
            top = min(max(snap(top + dy), 0), bottom - min_h)
        if "b" in corner:
            bottom = min(max(snap(bottom + dy), top + min_h), sh)
        return pygame.Rect(int(round(left)), int(round(top)), int(round(right - left)), int(round(bottom - top)))
