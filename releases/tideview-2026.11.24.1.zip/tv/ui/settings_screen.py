"""Settings, laid out like the Android app's settings page."""

import threading
import time

from .. import compass, system, updates
from ..rating import FEET, exposure_for, rate_surf
from ..settings import NIGHT_MODES, ORIENTATIONS, REFRESH_CHOICES
from ..version import VERSION
from .display import format_clock, round_half_up, wind_number
from .frame import FrameEditor, format_length
from .lists import ConfirmButton, ListScreen, RegionPicker, row

NIGHT_LABELS = {"off": "Off", "dim": "Dim the picture", "black": "Black picture", "screenOff": "Turn the screen off"}
ORIENTATION_LABELS = {"upright": "Upright", "sideways": "Sideways", "upright-flipped": "Upright, turned over",
                      "sideways-flipped": "Sideways, turned over"}


def _interval(m):
    return "%d minutes" % m if m < 60 else ("1 hour" if m == 60 else "%d hours" % (m // 60))


def _pct(v):
    return "%d%%" % round_half_up(v * 100)


def _m(v):
    return "-" if v is None else "%.1f m" % v


def _from(d):
    return "" if d is None else " from " + compass.name(d)


class SettingsScreen(ListScreen):
    title = "TideView settings"

    def __init__(self, app):
        super().__init__(app)
        self._pi_info = None
        self._pi_info_at = 0
        self._updates = None
        self._updates_at = 0
        self._asked_at = 0  # when "Check for updates now" was tapped
        self.shutdown = ConfirmButton("Shut down the Pi", "Tap again to shut down", self._do_shutdown)
        self.restart = ConfirmButton("Restart TideView", "Tap again to restart", app.request_restart)
        self.unlink = ConfirmButton("Unlink all phones", "Tap again to unlink them", self._unlink)

    def _unlink(self):
        if self.app.remote is not None:
            self.app.remote.unlink_all()

    def _later(self, fn, seconds=1.0):
        """For a phone: answer it first, then do fn (restart, shut down)."""
        def run():
            t = threading.Timer(seconds, fn)
            t.daemon = True
            t.start()
        return run

    def _choose(self, key, choices):
        return lambda i: self.app.settings.set(**{key: choices[i]})

    def _choices(self, key, choices, labels):
        """Extra fields for a cycle row, so a phone can show a list."""
        cur = self.app.settings[key]
        return {"options": [labels(c) for c in choices],
                "selected": choices.index(cur) if cur in choices else -1,
                "on_choose": self._choose(key, choices)}

    def _cycle(self, key, choices):
        s = self.app.settings
        cur = s[key]
        i = choices.index(cur) if cur in choices else -1
        s.set(**{key: choices[(i + 1) % len(choices)]})

    def _toggle(self, key):
        self.app.settings.set(**{key: not self.app.settings[key]})

    def _step_time(self, key, minutes):
        s = self.app.settings
        s.set(**{key: (s[key] + minutes) % (24 * 60)})

    def _step(self, key, delta, lo, hi, digits=2):
        s = self.app.settings
        s.set(**{key: round(min(hi, max(lo, (s[key] or 0) + delta)), digits)})

    def _do_shutdown(self):
        self.app.show_message("Shutting down. Unplug when the Pi's green light stops flashing.")
        system.shutdown()

    def _check_updates(self):
        if updates.request_check():
            self._asked_at = time.time()
            self._updates_at = 0
            self.app.show_message("Checking for updates. If there's a new version, TideView installs it "
                                  "and restarts by itself in a minute or two.", 8)
        else:
            self.app.show_message("Couldn't start the update check. Try Restart TideView, then try again.", 8)

    def _update_status(self, now, use24):
        if self._updates is None or now - self._updates_at > 2:
            self._updates_at = now
            self._updates = updates.read_state()
        st = self._updates
        if now - self._asked_at < 30 and not updates.busy_text(st, now) and \
                float(st.get("last_try") or 0) < self._asked_at - 1:
            return "Checking for updates..."
        return updates.describe(st, now, lambda t: format_clock(t, use24))

    def _pi(self):
        now = time.time()
        if self._pi_info is None or now - self._pi_info_at > 10:
            self._pi_info_at = now
            ip = system.ip_address()
            temp = system.cpu_temperature()
            power = system.power_problems()
            parts = []
            if temp is not None:
                parts.append("Processor %d°C. Under 70°C is fine. Over 80°C the Pi slows itself down: "
                             "give the frame some air gaps." % round(temp))
            if power:
                parts.append(power)
            self._pi_info = {
                "net": "%s · %s" % (system.hostname(), ip or "not connected"),
                "temp": " ".join(parts) or "Not available on this computer.",
            }
        return self._pi_info

    def rows(self, remote=False):
        """The rows to draw. remote=True: the rows a phone shows (no
        on-screen-only rows, plus a few that only make sense there)."""
        app = self.app
        s = app.settings
        fc = app.forecast
        f = fc.forecast
        now = time.time()
        c = f.at(now) if (f is not None and f.covers(now)) else None
        if c is not None and s["useMeasuredWind"]:
            c = c.with_measured_wind()
        r = rate_surf(fc.beach, c) if c is not None else None
        use24 = s["use24h"]
        out = [row("section", "Beach"),
               row("nav", fc.beach.name, value="Change", sub="%s. Tap to change." % fc.beach.region,
                   on_tap=lambda: app.push(RegionPicker(app)), id="beach", opens="beach")]
        if r is not None:
            out.append(row("info", "Right now: %d/10, %s" % (r.grade, r.label),
                           sub="Size %s · wind %s · swell direction %s · period %s · tide %s"
                           % (_pct(r.size), _pct(r.wind), _pct(r.swell_direction), _pct(r.period), _pct(r.tide))))
        if f is not None and c is not None:
            wind_title = ("measured at %s" % c.wind_measured.station) if c.wind_is_measured else f.wind_source
            out += [row("section", "Where the numbers come from"),
                    row("info", "Swell: %s" % f.swell_source, sub=self._swell_detail(c, r)),
                    row("info", "Wind: %s" % wind_title, sub=self._wind_detail(c)),
                    row("toggle", "Score with the airport's measured wind", value=s["useMeasuredWind"], id="useMeasuredWind",
                        sub="Off: the score and the big wind number use the forecast wind, like MetService's "
                            "surf page. On: they use the latest airport reading when there is one. Either way "
                            "the airport reading is shown under the wind.",
                        on_tap=lambda: self._toggle("useMeasuredWind")),
                    row("info", "Tide: %s" % f.tide_source)]

        out += [row("section", "Forecast updates"),
                row("cycle", "Get new data every", value=_interval(s["refreshMinutes"]), id="refreshMinutes",
                    on_tap=lambda: self._cycle("refreshMinutes", REFRESH_CHOICES),
                    **self._choices("refreshMinutes", REFRESH_CHOICES, _interval)),
                row("nav", "Refresh forecast now", sub=self._forecast_status(), on_tap=fc.refresh, id="refresh")]
        keys = app.keys
        out.append(row("info", "Data keys", sub="NIWA tides: %s. MetService: %s. Keys are read from .env.txt in the "
                       "tideview folder on the SD card." % ("key found" if keys.get("niwa") else "no key (using a tide model)",
                                             "key found" if keys.get("metocean") else "no key (using free models)")))

        out += [row("section", "Display"),
                row("toggle", "Wave height in metres", value=s["unit"] == "m", id="unit",
                    on_tap=lambda: s.set(unit="ft" if s["unit"] == "m" else "m")),
                row("toggle", "Wind in knots", value=s["windInKnots"], id="windInKnots",
                    sub="Instead of km/h. MetService's surf and marine pages use knots.",
                    on_tap=lambda: self._toggle("windInKnots")),
                row("toggle", "24-hour clock", value=s["use24h"], on_tap=lambda: self._toggle("use24h"), id="use24h"),
                row("toggle", "Animate the water", value=s["animate"], id="animate",
                    sub="Rolls the swell lines a few times a second. Turn off to keep the Pi coolest.",
                    on_tap=lambda: self._toggle("animate")),
                row("toggle", "Show the surf score under the beach name", value=s["showRating"], id="showRating",
                    on_tap=lambda: self._toggle("showRating")),
                row("cycle", "Screen", value=ORIENTATION_LABELS[s["orientation"]], id="orientation",
                    sub="Upright or sideways, to suit the frame. Turned over if the picture is upside down.",
                    on_tap=lambda: self._cycle("orientation", ORIENTATIONS),
                    **self._choices("orientation", ORIENTATIONS, ORIENTATION_LABELS.get))]

        out += [row("section", "Night"),
                row("cycle", "At night", value=NIGHT_LABELS[s["nightMode"]], id="nightMode",
                    sub="A tap brings the picture back for a minute. If 'Turn the screen off' leaves a "
                        "'No signal' message on screen, use 'Black picture' instead.",
                    on_tap=lambda: self._cycle("nightMode", NIGHT_MODES),
                    **self._choices("nightMode", NIGHT_MODES, NIGHT_LABELS.get)),
                row("stepper", "Night starts", value=format_clock(_clock(s["nightStart"]), use24), id="nightStart",
                    on_minus=lambda: self._step_time("nightStart", -15), on_plus=lambda: self._step_time("nightStart", 15)),
                row("stepper", "Morning starts", value=format_clock(_clock(s["dayStart"]), use24), id="dayStart",
                    on_minus=lambda: self._step_time("dayStart", -15), on_plus=lambda: self._step_time("dayStart", 15)),
                row("stepper", "How dim", value=_pct(s["dimLevel"]), id="dimLevel",
                    on_minus=lambda: self._step("dimLevel", -0.1, 0.1, 0.9),
                    on_plus=lambda: self._step("dimLevel", 0.1, 0.1, 0.9))]
        if remote and s["nightMode"] != "off":
            out.append(row("nav", "Light up the screen for a minute", id="wake",
                           sub="When the night setting has dimmed it or turned it off.", on_tap=self._wake))

        geo = app.frame_geometry
        screen = app.screen_size
        box = geo.box(screen)
        cm = s["frameInCm"]
        lx, ty, bw, bh = geo.mm(box)
        right = (screen[0] - box.right) / geo.px_per_mm
        bottom = (screen[1] - box.bottom) / geo.px_per_mm
        sw_mm, sh_mm = screen[0] / geo.px_per_mm, screen[1] / geo.px_per_mm
        step = geo.snap_mm

        def nudge(field, sign):
            return lambda: (geo.nudge(screen, field, sign), app.frame_changed())

        out += [row("section", "Frame (developer)"),
                row("toggle", "Fit the picture to a frame", value=s["frameEnabled"], id="frameEnabled",
                    sub="Shrinks the display to the box below. The rest of the screen goes black.",
                    on_tap=lambda: (self._toggle("frameEnabled"), app.frame_changed()))]
        if not remote:  # dragging needs the touch screen
            out.append(row("nav", "Adjust on screen", sub="Drag the corners and the middle of the box.",
                           on_tap=lambda: app.push(FrameEditor(app))))
        out += [row("stepper", "Width", value=format_length(bw, cm), on_minus=nudge("w", -1), on_plus=nudge("w", 1),
                    id="frameWidth"),
                row("stepper", "Height", value=format_length(bh, cm), on_minus=nudge("h", -1), on_plus=nudge("h", 1),
                    id="frameHeight"),
                row("stepper", "Gap from the left", value=format_length(lx, cm), id="frameLeft",
                    on_minus=nudge("x", -1), on_plus=nudge("x", 1)),
                row("stepper", "Gap from the top", value=format_length(ty, cm), id="frameTop",
                    on_minus=nudge("y", -1), on_plus=nudge("y", 1)),
                row("info", "That leaves %s on the right and %s at the bottom."
                    % (format_length(max(0, right), cm), format_length(max(0, bottom), cm)),
                    sub="Each tap moves %s." % ("1 mm" if cm else "0.05 in")),
                row("cycle", "Units", value="Centimetres" if cm else "Inches", id="frameInCm",
                    on_tap=lambda: s.set(frameInCm=not cm), options=["Inches", "Centimetres"],
                    selected=1 if cm else 0, on_choose=lambda i: s.set(frameInCm=i == 1)),
                row("stepper", "Screen size (diagonal)", value="%.1f in" % s["screenDiagonalIn"], id="screenDiagonal",
                    sub="This screen: %s by %s at %d pixels per inch. If a ruler disagrees, change the diagonal "
                        "(the Jaycar panel is 7 in)." % (format_length(sw_mm, cm), format_length(sh_mm, cm), round(geo.ppi)),
                    on_minus=lambda: (self._step("screenDiagonalIn", -0.1, 3.0, 30.0, 1), app.frame_changed()),
                    on_plus=lambda: (self._step("screenDiagonalIn", 0.1, 3.0, 30.0, 1), app.frame_changed()))]
        del step

        out += self._phone_rows(remote, now)

        out += [row("section", "TideView version"),
                row("info", "Version %s" % VERSION, sub=self._update_status(now, use24))]
        if updates.available():
            out.append(row("nav", "Check for updates now", id="checkUpdates",
                           sub=updates.schedule_text(self._updates or {}, lambda t: format_clock(t, use24)),
                           on_tap=self._check_updates))

        pi = self._pi()
        out += [row("section", "This Pi"),
                row("info", "Network", sub=pi["net"]),
                row("info", "Temperature and power", sub=pi["temp"]),
                row("info", "Touch screen", sub=self._touch_text()),
                row("button", self.restart.current_label(), on_tap=self.restart.tap, id="restart",
                    remote_tap=self._later(app.request_restart),
                    confirm="Restart TideView? The screen goes black for about half a minute."),
                row("button", self.shutdown.current_label(), on_tap=self.shutdown.tap, color=(0x6B, 0x23, 0x23),
                    id="shutdown", remote_tap=self._later(self._do_shutdown),
                    confirm="Shut down the Pi? To start it again, unplug it and plug it back in.")]
        if app.net is not None and app.net.online is not None:
            out.insert(len(out) - 3, row("info", "Wi-Fi", sub=self._wifi_text()))
        return out

    def _phone_rows(self, remote, now):
        app = self.app
        rc = app.remote
        out = [row("section", "Phone control")]
        if rc is None:
            return out + [row("info", "Off", sub="Phone control couldn't start. Restart TideView to try again.")]
        out.append(row("info", "Linked phones", sub=rc.pairing.describe(now)))
        address = rc.web_address()
        if rc.running() and address:
            from ..remote import pretty_code
            out.append(row("info", "Address", sub="%s · code %s. In the TideView app, scan the code on the main "
                           "screen, or type these in." % (address, pretty_code(rc.pairing.code))))
            if remote:
                out.append(row("nav", "Show the code on the TideView", id="showCode",
                               sub="For 5 minutes, so another phone can scan it.", on_tap=rc.show_code))
            else:
                out.append(row("nav", "Show the code to link a phone", id="showCode",
                               sub="On the main screen, for 5 minutes.",
                               on_tap=lambda: (rc.show_code(), app.home())))
        elif rc.running():
            out.append(row("info", "Waiting for Wi-Fi", sub="The code to link a phone shows once TideView is on Wi-Fi."))
        else:
            out.append(row("info", "Not running", sub=rc.error or "Starting..."))
        if rc.pairing.linked:
            out.append(row("button", self.unlink.current_label(), on_tap=self.unlink.tap, id="unlink",
                           remote_tap=rc.unlink_all,
                           confirm="Unlink every phone? Each one will need to scan the new code on the TideView."))
        return out

    def _wake(self):
        app = self.app
        app.night.wake_briefly(time.time())
        app.frame_changed()
        app.display.invalidate()

    def _wifi_text(self):
        net = self.app.net
        if net.online:
            text = "Connected."
        else:
            gone = time.monotonic() - (net.offline_since or time.monotonic())
            text = "Not connected for %d min. TideView keeps trying to reconnect by itself." % max(1, round(gone / 60))
            if net.diagnosis:
                text += " " + net.diagnosis
        if net.clock_ok is False:
            text += " The clock hasn't been set from the internet since the Pi started, so it may be wrong."
        return text

    def _swell_detail(self, c, r):
        """What reaches the beach right now, the swell and wind chop it comes
        from, and how much the wave models agree."""
        beach = self.app.forecast.beach
        lines = []
        surf = r.surf if r is not None else None
        if surf is not None:
            lines.append("At the beach: sets about %s (%d ft)%s%s" % (
                _m(surf.face), round_half_up(surf.face * FEET),
                "" if surf.period is None else " at %d s" % round_half_up(surf.period), _from(surf.direction)))
        lines.append("Swell %s%s%s" % (_m(c.swell_height), _from(c.swell_direction),
                                       "" if c.period is None else " at %d s" % round_half_up(c.period)))
        if c.sea_height is not None and c.sea_height >= 0.1:
            d = c.sea_direction
            offshore = d is not None and exposure_for(compass.angle_between(d, beach.ideal_swell_deg)) < 0.15
            lines.append("Wind chop %s%s%s" % (_m(c.sea_height), _from(d),
                                               ", heading out to sea, so it doesn't reach the beach" if offshore else ""))
        if c.wave_height is not None:
            lines.append("All the waves together out at sea: %s" % _m(c.wave_height))
        if len(c.model_swell_heights) > 1:
            lines.append("Swell by model: " + " · ".join("%s %s" % (k, _m(v)) for k, v in c.model_swell_heights.items()))
        return "\n".join(lines)

    def _wind_detail(self, c):
        s = self.app.settings
        knots = s["windInKnots"]

        def speed(v):
            if v is None:
                return "-"
            return "%d kt" % wind_number(v, True) if knots else "%d km/h" % round_half_up(v)

        lines = []
        if c.wind_is_measured:
            lines.append("Forecast for now: %s%s" % (speed(c.forecast_wind_speed), _from(c.forecast_wind_direction)))
        else:
            lines.append("Forecast for now: %s%s%s" % (speed(c.wind_speed), _from(c.wind_direction),
                                                       "" if c.wind_gust is None else ", gusts " + speed(c.wind_gust)))
        m = c.wind_measured
        if m is not None:
            lines.append("%s measured %s%s%s at %s" % (m.station, speed(m.speed), _from(m.direction),
                                                       "" if m.gust is None else ", gusts " + speed(m.gust),
                                                       format_clock(m.time, s["use24h"])))
        else:
            lines.append("No recent reading from an airport near this beach.")
        return "\n".join(lines)

    def _touch_text(self):
        names = self.app.touch_names()
        text = ", ".join(names) + "." if names else "None found. Check the USB cable."
        drops = getattr(self.app.touch, "dropouts", 0)
        if drops:
            text += (" It has dropped out %s since TideView started. If that keeps happening, the screen needs "
                     "more power: plug a phone charger into its second USB socket."
                     % ("once" if drops == 1 else "%d times" % drops))
        return text

    def _forecast_status(self):
        fc = self.app.forecast
        use24 = self.app.settings["use24h"]
        if fc.loading:
            return "Updating now..."
        parts = []
        f = fc.forecast
        if f is not None:
            parts.append("Last update %s." % format_clock(f.fetched_at, use24))
        if fc.error:
            parts.append("The last try failed: %s" % fc.error)
        if fc.next_update:
            parts.append("Next at %s." % format_clock(fc.next_update, use24))
        return " ".join(parts) or "Waiting for the first update."


def _clock(minutes):
    """A timestamp today at minutes past midnight (for formatting)."""
    lt = time.localtime()
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, minutes // 60, minutes % 60, 0, 0, 0, -1))
