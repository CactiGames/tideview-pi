"""The always-on display: time, beach, swell, wind, tides and the week, over
a sea whose colour is the surf score and whose swell lines follow the tide.

Ported from the Android app's ForecastScreen, SeaPainter and WeekStrip. The
upright (portrait) layout is the tablet's, scaled from its 768 x 1024 design;
the sideways (landscape) layout is new, designed at 1024 x 600 for the 7"
panel turned on its side.
"""

import math
import time
from datetime import datetime

import pygame

from .. import compass
from ..outlook import week_outlook
from ..rating import GRADE_COLORS, rate_surf
from .gfx import MIST, NIGHT, WHITE, blit_text, lerp

LOADING_COLOR = (0x4A, 0x5A, 0x6A)
DAY_NAMES = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]


# ------------------------------------------------------------- formatting


def format_clock(t, use24h, with_period=True):
    d = datetime.fromtimestamp(t)
    if use24h:
        return "%02d:%02d" % (d.hour, d.minute)
    h = d.hour % 12 or 12
    if not with_period:
        return "%d:%02d" % (h, d.minute)
    return "%d:%02d %s" % (h, d.minute, "AM" if d.hour < 12 else "PM")


def format_height(metres, unit):
    """Surf height as shown big on screen, e.g. ("4-5", "FT") or ("1.4", "M")."""
    if unit == "m":
        return "%.1f" % metres, "M"
    ft = metres * 3.28084
    if ft < 1:
        return "0-1", "FT"
    lo = int(math.floor(ft))
    if lo < 10:
        return "%d-%d" % (lo, lo + 1), "FT"
    if lo < 15:
        return "%d-%d" % (lo, lo + 2), "FT"
    return "%d+" % lo, "FT"


def round_half_up(x):
    """Rounds half up, like the Android app (Python's round() goes to even)."""
    return int(math.floor(x + 0.5))


def format_small_height(metres, unit):
    """A smaller height for captions: "1.3 M" or "4 FT"."""
    return "%.1f M" % metres if unit == "m" else "%d FT" % round_half_up(metres * 3.28084)


def swell_caption(c, unit):
    """The line under the swell: where the swell comes from and how big it is
    on its own, e.g. "S SWELL 1.3 M"."""
    d = "" if c.swell_direction is None else compass.name(c.swell_direction) + " "
    if c.swell_height is not None:
        return "%sSWELL %s" % (d, format_small_height(c.swell_height, unit))
    return "FROM " + d.strip() if d else ""


def wind_number(kmh, knots):
    """A wind speed (given in km/h) as a whole number in the chosen unit."""
    return round_half_up(kmh / 1.852 if knots else kmh)


def format_wind(kmh, knots):
    """"46 KM/H" or "25 KT"."""
    return "%d %s" % (wind_number(kmh, knots), "KT" if knots else "KM/H")


def wind_caption(c, knots=False):
    """The line under the wind: the airport's measured wind when there's a
    recent reading (so a forecast that's off is easy to spot), otherwise the
    gusts."""
    m = c.wind_measured
    if c.wind_is_measured:
        f = c.forecast_wind_speed
        return "MEASURED AT AIRPORT" if f is None else "AIRPORT NOW · FORECAST %d" % wind_number(f, knots)
    if m is not None:
        d = "" if m.direction is None else compass.name(m.direction) + " "
        gust = ", GUSTS %d" % wind_number(m.gust, knots) if (m.gust is not None and m.gust > m.speed + 5) else ""
        return "AIRPORT NOW %s%d%s" % (d, wind_number(m.speed, knots), gust)
    if c.wind_gust is not None and c.wind_speed is not None and c.wind_gust > c.wind_speed + 5:
        return "GUSTS " + format_wind(c.wind_gust, knots)
    return ""


def weather_icon(code, is_day, wind_kmh):
    """WMO weather code -> icon name."""
    c = code or 0
    if c >= 95:
        return "storm"
    if 71 <= c <= 77 or c in (85, 86):
        return "snow"
    if 51 <= c <= 57:
        return "drizzle"
    if 61 <= c <= 67 or 80 <= c <= 82:
        return "rain"
    if c in (45, 48):
        return "fog"
    if (wind_kmh or 0) >= 45:
        return "wind"
    if c == 3:
        return "cloud"
    if c == 2:
        return "partly_cloudy_day" if is_day else "partly_cloudy_night"
    return "sun" if is_day else "moon"


# ------------------------------------------------------------------ sea

BAND = 0.2  # height of the band holding the three swell lines, share of the screen
STEPS = 48


def band_top(h, tide, bottom_inset):
    """Top of the swell band: at the top of the screen at high tide, just
    above the week panel at low tide."""
    travel = max(0.0, h - bottom_inset - h * BAND)
    return (1 - max(0.0, min(1.0, tide))) * travel


def sky_for(color):
    """Night blue with a touch of the surf colour."""
    return lerp(NIGHT, color, 0.2)


def _layers(h, color, tide, bottom_inset):
    top = band_top(h, tide, bottom_inset)
    # colour, base line, amplitude, waves across, offset, direction
    return [
        (lerp(color, MIST, 0.34), top + h * 0.05, 0.016, 0.55, 0.15, 1),
        (lerp(color, MIST, 0.15), top + h * 0.10, 0.015, 0.75, 1.9, -1),
        (color, top + h * 0.15, 0.014, 0.65, 3.6, 1),
    ]


def band_rect(w, h, color, tide, bottom_inset):
    """The rows the moving swell lines can touch (everything above is sky,
    everything below is the front water, neither changes as they roll)."""
    layers = _layers(h, color, tide, bottom_inset)
    y0 = min(base - h * amp * 1.35 for _, base, amp, *_ in layers) - 2
    y1 = max(base + h * amp * 1.35 for _, base, amp, *_ in layers) + 3
    y0 = max(0, int(math.floor(y0)))
    y1 = min(h, int(math.ceil(y1)))
    return pygame.Rect(0, y0, w, max(0, y1 - y0))


def draw_sea(surf, color, tide, phase, bottom_inset, height=None, top=0):
    """Paints the sky and the three swell lines. surf is normally the whole
    picture. To paint only some rows (the band where the lines roll), pass a
    surface just for those rows, the picture's full height, and the number of
    the first row.

    Always paint onto a surface of its own, never a subsurface: pygame's
    smoothed lines blend with the wrong pixels on subsurfaces."""
    w = surf.get_width()
    h = surf.get_height() if height is None else height
    surf.fill(sky_for(color))
    t = phase * 2 * math.pi
    for col, base, amp, freq, off, d in _layers(h, color, tide, bottom_inset):
        crest = []
        for i in range(STEPS + 1):
            u = i / STEPS
            y = (base + h * amp * math.sin(2 * math.pi * u * freq + off + t * d)
                 + h * amp * 0.35 * math.sin(2 * math.pi * u * freq * 2.3 + off * 1.7 - t * d))
            crest.append((w * u, y - top))
        pygame.draw.polygon(surf, col, [(0, h - top)] + crest + [(w, h - top)])
        pygame.draw.aalines(surf, col, False, crest)


# ----------------------------------------------------------- the readout


class Readout:
    """What's written over the sea, worked out once a minute."""

    def __init__(self, now, beach, forecast, settings, status, controls):
        self.now = now
        self.beach = beach
        self.forecast = forecast
        c = forecast.at(now) if (forecast is not None and forecast.covers(now)) else None
        if c is not None and settings["useMeasuredWind"]:
            c = c.with_measured_wind()
        self.c = c
        self.rating = rate_surf(beach, c) if c is not None else None
        self.surf = self.rating.surf if self.rating else None  # what reaches the beach
        self.color = self.rating.color if self.rating else LOADING_COLOR
        self.tide = c.tide_fraction if (c is not None and c.tide_fraction is not None) else 0.5
        self.week = week_outlook(forecast, beach, now) if forecast is not None else []
        self.unit = settings["unit"]
        self.use24h = settings["use24h"]
        self.knots = settings["windInKnots"]
        self.show_rating = settings["showRating"]
        self.status = status
        self.controls = controls


def is_portrait(w, h):
    return w < h


def week_inset(w, h):
    """Space the week panel takes at the bottom (the swell band stays above)."""
    if is_portrait(w, h):
        s = min(w / 768, h / 1024)
        return 20 * s + 182 * s + 2 + 8 * s
    s = min(w / 1024, h / 600)
    return 16 * s + 160 * s + 2 + 8 * s


def draw_readout(ov, g, r):
    w, h = ov.get_size()
    if is_portrait(w, h):
        _portrait(ov, g, r, w, h)
    else:
        _landscape(ov, g, r, w, h)


def _rating_line(ov, g, r, x, y, s_dot, s_text):
    dot = g.disc(s_dot, lerp(r.rating.color, WHITE, 0.15), ring=(255, 255, 255, 178), ring_width=s_dot * 0.11)
    row_h = max(s_dot, s_text)
    ov.blit(dot, (int(x), int(y + (row_h - dot.get_height()) / 2)))
    blit_text(ov, g, "NOW %d/10 · %s" % (r.rating.grade, r.rating.label.upper()), s_text,
              x + s_dot + s_dot * 0.57, y + (row_h - s_text) / 2, opacity=0.85, shadow=True)


def _temp_row(ov, g, temp, icon, right, top, text_size, icon_size, box_w, gap):
    row_h = max(text_size, icon_size)
    img = g.icon(icon, icon_size)
    ov.blit(img, (int(right - box_w / 2 - img.get_width() / 2), int(top + (row_h - img.get_height()) / 2)))
    label = "--°" if temp is None else "%d°" % int(round(temp))
    blit_text(ov, g, label, text_size, right - box_w - gap, top + (row_h - text_size) / 2, anchor="tr", shadow=True)
    return row_h


def _big_value(ov, g, cx, top, value, unit, big, small, gap, unit_lift):
    """Big number with an optional small unit, bottoms lined up."""
    wv = g.text_size(value, big, True)[0]
    wu = g.text_size(unit, small)[0] + gap if unit else 0
    x = cx - (wv + wu) / 2
    blit_text(ov, g, value, big, x, top, bold=True, shadow=True)
    if unit:
        blit_text(ov, g, unit, small, x + wv + gap, top + big - unit_lift, anchor="bl", shadow=True)


def _columns(r):
    """Texts for the swell and wind columns: (big value, unit, line, caption,
    arrow bearing) for each."""
    c, surf = r.c, r.surf
    height = format_height(surf.face, r.unit) if surf is not None else None
    period = None if surf is None else surf.period
    swell = (height[0] if height else "-", height[1] if height else None,
             "" if period is None else "%d S" % round_half_up(period),
             "" if c is None else swell_caption(c, r.unit),
             None if surf is None else surf.direction)
    wind_dir = None if c is None else c.wind_direction
    wind_kmh = None if c is None else c.wind_speed
    wind = ("-" if wind_dir is None else compass.name(wind_dir), None,
            "" if wind_kmh is None else format_wind(wind_kmh, r.knots),
            "" if c is None else wind_caption(c, r.knots),
            wind_dir)
    return swell, wind


def _tide_time(e, use24h):
    return "--:--" if e is None else format_clock(e.time, use24h)


def _status(ov, g, text, size, cx, bottom, width):
    lines = g.wrap(text, size, width)
    y = bottom - size * 1.15 * len(lines)
    for line in lines:
        blit_text(ov, g, line, size, cx, y, opacity=0.8, shadow=True, anchor="tc")
        y += size * 1.15


def _portrait(ov, g, r, w, h):
    s = min(w / 768, h / 1024)
    c = r.c
    weekh = (20 * s + 182 * s + 2) if r.week else 0

    # Clock, beach and the score right now.
    x, y = 40 * s, 34 * s
    blit_text(ov, g, format_clock(r.now, r.use24h), 92 * s, x, y, bold=True, shadow=True)
    y += 92 * s + 10 * s
    blit_text(ov, g, r.beach.name.upper(), 34 * s, x + 6 * s, y, opacity=0.92, shadow=True)
    y += 34 * s
    if r.show_rating and r.rating is not None:
        _rating_line(ov, g, r, x + 6 * s, y + 10 * s, 14 * s, 20 * s)

    # Air and sea temperature.
    right, y = w - 36 * s, 36 * s
    icon = "sun" if c is None else weather_icon(c.weather_code, c.is_day, c.wind_speed)
    y += _temp_row(ov, g, None if c is None else c.air_temp, icon, right, y, 44 * s, 64 * s, 70 * s, 14 * s)
    y += 14 * s
    _temp_row(ov, g, None if c is None else c.sea_temp, "water_temp", right, y, 44 * s, 60 * s, 70 * s, 14 * s)

    swell, wind = _columns(r)
    cap = max(18 * s, 13)

    def column(cx, top, icon_name, value, unit, sub, caption, arrow_from):
        img = g.icon(icon_name, 58 * s)
        ov.blit(img, (int(cx - img.get_width() / 2), int(top)))
        top += 58 * s + 8 * s
        _big_value(ov, g, cx, top, value, unit, 132 * s, 36 * s, 10 * s, 12 * s)
        top += 132 * s + 14 * s
        if sub:
            blit_text(ov, g, sub, 38 * s, cx, top, shadow=True, anchor="tc")
        top += 38 * s + 10 * s
        if caption:
            blit_text(ov, g, caption, cap, cx, top, opacity=0.82, shadow=True, anchor="tc")
        top += 20 * s + 16 * s
        if arrow_from is not None:
            a = g.arrow(arrow_from, 78 * s)
            ov.blit(a, (int(cx - a.get_width() / 2), int(top + 39 * s - a.get_height() / 2)))

    column(w * 0.27, h * 0.255, "swell", *swell)
    column(w * 0.73, h * 0.255, "wind", *wind)

    # Tides.
    for cx, icon_name, e in ((w * 0.27, "tide_low", None if c is None else c.next_low),
                             (w * 0.73, "tide_high", None if c is None else c.next_high)):
        top = h - weekh - 160 * s
        img = g.icon(icon_name, 58 * s)
        ov.blit(img, (int(cx - img.get_width() / 2), int(top)))
        blit_text(ov, g, _tide_time(e, r.use24h), 30 * s, cx, top + 66 * s, shadow=True, anchor="tc")

    if r.status:
        _status(ov, g, r.status, 20 * s, w / 2, h - weekh - 16 * s, w - 80 * s)

    if r.week:
        rect = pygame.Rect(int(22 * s), int(h - 20 * s - 182 * s - 2), int(w - 44 * s), int(182 * s + 2))
        draw_week(ov, g, r.week, r.unit, rect, s, compact=False)


def _landscape(ov, g, r, w, h):
    s = min(w / 1024, h / 600)
    c = r.c
    weekh = (16 * s + 160 * s + 2) if r.week else 0

    x, y = 34 * s, 24 * s
    blit_text(ov, g, format_clock(r.now, r.use24h), 80 * s, x, y, bold=True, shadow=True)
    y += 80 * s + 8 * s
    blit_text(ov, g, r.beach.name.upper(), 30 * s, x + 4 * s, y, opacity=0.92, shadow=True)
    y += 30 * s
    if r.show_rating and r.rating is not None:
        _rating_line(ov, g, r, x + 4 * s, y + 9 * s, 13 * s, 18 * s)

    right, y = w - 32 * s, 26 * s
    icon = "sun" if c is None else weather_icon(c.weather_code, c.is_day, c.wind_speed)
    y += _temp_row(ov, g, None if c is None else c.air_temp, icon, right, y, 40 * s, 56 * s, 62 * s, 12 * s)
    y += 8 * s
    _temp_row(ov, g, None if c is None else c.sea_temp, "water_temp", right, y, 40 * s, 52 * s, 62 * s, 12 * s)

    swell, wind = _columns(r)
    cap = max(17 * s, 13)

    mid_top = 172 * s
    mid_bottom = h - weekh - 10 * s

    def column(cx, icon_name, value, unit, sub, caption, arrow_from):
        top = mid_top
        img = g.icon(icon_name, 46 * s)
        ov.blit(img, (int(cx - img.get_width() / 2), int(top)))
        top += 46 * s + 6 * s
        _big_value(ov, g, cx, top, value, unit, 104 * s, 30 * s, 8 * s, 10 * s)
        top += 104 * s + 12 * s
        # Small line with the arrow beside it.
        arrow = g.arrow(arrow_from, 50 * s) if arrow_from is not None else None
        tw = g.text_size(sub, 32 * s)[0] if sub else 0
        gap = 16 * s if (sub and arrow) else 0
        aw = 50 * s if arrow else 0
        x0 = cx - (tw + gap + aw) / 2
        row_mid = top + 25 * s
        if sub:
            blit_text(ov, g, sub, 32 * s, x0, row_mid, shadow=True, anchor="ml")
        if arrow:
            ov.blit(arrow, (int(x0 + tw + gap + aw / 2 - arrow.get_width() / 2), int(row_mid - arrow.get_height() / 2)))
        if caption:
            blit_text(ov, g, caption, cap, cx, top + 52 * s, opacity=0.82, shadow=True, anchor="tc")

    column(w * 0.215, "swell", *swell)
    column(w * 0.535, "wind", *wind)

    # Tides, one above the other.
    cx = w * 0.84
    block = 2 * (46 * s + 6 * s + 30 * s) + 34 * s
    top = mid_top + max(0, (mid_bottom - mid_top - block) / 2)
    for icon_name, e in (("tide_low", None if c is None else c.next_low),
                         ("tide_high", None if c is None else c.next_high)):
        img = g.icon(icon_name, 46 * s)
        ov.blit(img, (int(cx - img.get_width() / 2), int(top)))
        blit_text(ov, g, _tide_time(e, r.use24h), 30 * s, cx, top + 52 * s, shadow=True, anchor="tc")
        top += 46 * s + 6 * s + 30 * s + 34 * s

    if r.status:
        # Top middle, between the clock and the temperatures: the columns
        # and their captions fill the space above the week.
        left = x + g.text_size("12:59 PM", 80 * s, True)[0] + 28 * s
        right = w - 32 * s - 62 * s - 12 * s - g.text_size("88°", 40 * s)[0] - 28 * s
        size = 18 * s
        yy = 30 * s
        for line in g.wrap(r.status, size, right - left)[:5]:
            blit_text(ov, g, line, size, (left + right) / 2, yy, opacity=0.8, shadow=True, anchor="tc")
            yy += size * 1.15

    if r.week:
        rect = pygame.Rect(int(20 * s), int(h - 16 * s - 160 * s - 2), int(w - 40 * s), int(160 * s + 2))
        draw_week(ov, g, r.week, r.unit, rect, s, compact=True)


def draw_week(ov, g, days, unit, rect, s, compact):
    """The coming week: three small bars per day (morning, midday, evening)
    whose height and colour show the score, with the day's best score and
    biggest surf underneath."""
    ov.blit(g.panel(rect.w, rect.h, 20 * s, (0x0B, 0x10, 0x28, 0xCC), (255, 255, 255, 0x1F)), rect.topleft)
    if compact:
        pad_x, pad_top, head, head_gap = 16 * s, 12 * s, 16 * s, 8 * s
        name_size, name_gap, area, bar_w, bar_gap = 15 * s, 6 * s, 46 * s, 20 * s, 4 * s
        grade_gap, grade_size, small_gap, small_size = 6 * s, 26 * s, 3 * s, 12 * s
        sub_size = 13 * s
    else:
        pad_x, pad_top, head, head_gap = 16 * s, 12 * s, 17 * s, 10 * s
        name_size, name_gap, area, bar_w, bar_gap = 16 * s, 8 * s, 54 * s, 16 * s, 3 * s
        grade_gap, grade_size, small_gap, small_size = 7 * s, 28 * s, 3 * s, 13 * s
        sub_size = 14 * s
    # Not too small to read across a room on a 7 inch screen.
    name_size, small_size, sub_size = max(name_size, 13), max(small_size, 12), max(sub_size, 12)
    x0, x1 = rect.x + pad_x, rect.right - pad_x
    y = rect.y + pad_top
    blit_text(ov, g, "THIS WEEK", head, x0, y, opacity=0.8)
    blit_text(ov, g, "MORNING · MIDDAY · EVENING", sub_size, x1, y + head / 2, opacity=0.55, anchor="mr")
    y += head + head_gap
    col_w = (x1 - x0) / max(1, len(days))
    for i, d in enumerate(days):
        cx = x0 + col_w * (i + 0.5)
        blit_text(ov, g, "TODAY" if i == 0 else DAY_NAMES[d.day.weekday()], name_size, cx, y,
                  opacity=1.0 if i == 0 else 0.75, anchor="tc")
        bars_bottom = y + name_size + name_gap + area
        total = len(d.sessions) * bar_w + (len(d.sessions) - 1) * bar_gap
        bx = cx - total / 2
        for sess in d.sessions:
            gr = sess.grade
            bh = 4 * s if gr is None else area * (0.18 + 0.82 * gr / 10)
            if gr is None:
                rgba = (255, 255, 255, 0x33)
            else:
                rgba = lerp(GRADE_COLORS[gr - 1], WHITE, 0.12) + (255,)
            if sess.is_past:
                rgba = rgba[:3] + (int(rgba[3] * 0.4),)
            bar = _bar(g, int(round(bar_w)), max(1, int(round(bh))), rgba, s)
            ov.blit(bar, (int(round(bx)), int(round(bars_bottom - bar.get_height()))))
            bx += bar_w + bar_gap
        gy = bars_bottom + grade_gap
        blit_text(ov, g, "–" if d.grade is None else str(d.grade), grade_size, cx, gy, bold=True, anchor="tc")
        if d.max_height is not None:
            v, u = format_height(d.max_height, unit)
            blit_text(ov, g, v + u, small_size, cx, gy + grade_size + small_gap, opacity=0.65, anchor="tc")


def _bar(g, w, h, rgba, s):
    def make():
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        top_r = max(0, min(int(round(4 * s)), w // 2, h // 2))
        bot_r = max(0, min(int(round(1.5 * s)), w // 2, h // 2))
        pygame.draw.rect(surf, rgba, surf.get_rect(), border_top_left_radius=top_r, border_top_right_radius=top_r,
                         border_bottom_left_radius=bot_r, border_bottom_right_radius=bot_r)
        return surf
    return g._misc.get_or(("bar", w, h, rgba, round(s, 3)), make)


# ------------------------------------------------------------- the screen


class DisplayScreen:
    """The main screen. Redraws everything once a minute (or when data or
    settings change), and in between only the band where the swell lines
    roll, a few times a second."""

    CONTROLS_SECONDS = 8

    def __init__(self, app):
        self.app = app
        self.g = app.gfx
        self.overlay = None
        self.readout = None
        self._key = None
        self.phase = 0.0
        self._last_frame = None
        self.controls_until = 0.0
        self.buttons = {}
        self.full = True
        self._scratch = {}

    # -- state ------------------------------------------------------------

    def invalidate(self):
        self.full = True
        self._key = None

    def _status(self, fc, now):
        net = getattr(self.app, "net", None)
        if net is not None:
            try:
                text = net.status_text()
            except Exception:  # noqa: BLE001
                text = None
            if text:
                return text
        use24 = self.app.settings["use24h"]
        nxt = fc.next_update
        again = "Trying again soon." if nxt is None else "Trying again at %s." % format_clock(nxt, use24)
        f = fc.forecast
        if f is None:
            if fc.error and not fc.loading:
                return "%s %s" % (fc.error, again)
            return "Getting the forecast for %s..." % fc.beach.name
        if not f.covers(now):
            return "The forecast is out of date. Updating..." if fc.loading else "The forecast is out of date. %s" % again
        if fc.is_stale:
            return "Offline. Showing the forecast from %s." % format_clock(f.fetched_at, use24)
        return None

    def controls_visible(self, now):
        return now < self.controls_until

    def animating(self):
        app = self.app
        return (app.settings["animate"] and app.night.state == "day" and app.settings["waveFps"] > 0)

    # -- drawing ----------------------------------------------------------

    def _ensure_overlay(self, canvas, now):
        app = self.app
        fc = app.forecast
        minute = int(now // 60)
        controls = self.controls_visible(now)
        status = self._status(fc, now)
        key = (minute, fc.version, app.settings.version, controls, status, canvas.get_size(), app.night.state)
        if key == self._key and self.overlay is not None:
            return False
        self._key = key
        t0 = time.time()
        r = Readout(now, fc.beach, fc.forecast, app.settings, status, controls)
        self.readout = r
        ov = pygame.Surface(canvas.get_size(), pygame.SRCALPHA)
        draw_readout(ov, self.g, r)
        if controls:
            self._draw_controls(ov)
        else:
            self.buttons = {}
        self.overlay = ov
        app.log.debug("readout drawn in %.0f ms", (time.time() - t0) * 1000)
        return True

    def _draw_controls(self, ov):
        w, h = ov.get_size()
        u = min(w, h) / 600
        size = 26 * u
        labels = [("beach", "Change beach"), ("settings", "Settings")]
        pad_x, bh, gap = 28 * u, 70 * u, 18 * u
        widths = [self.g.text_size(t, size)[0] + 2 * pad_x for _, t in labels]
        total = sum(widths) + gap * (len(labels) - 1)
        x = (w - total) / 2
        y = h - bh - (34 * u if w < h else 30 * u)
        self.buttons = {}
        for (key, label), bw in zip(labels, widths):
            rect = pygame.Rect(int(x), int(y), int(bw), int(bh))
            ov.blit(self.g.panel(rect.w, rect.h, bh / 2, (0x1C, 0x2B, 0x22, 0xF0), (255, 255, 255, 0x40)), rect)
            blit_text(ov, self.g, label, size, rect.centerx, rect.centery + size * 0.06, anchor="mc")
            self.buttons[key] = rect.inflate(int(12 * u), int(20 * u))
            x += bw + gap

    def _paint_sea(self, canvas, rows, inset):
        """Paints the sea's rows (a full-width rect) onto canvas, by way of a
        surface of their own (see draw_sea)."""
        r = self.readout
        surf = self._scratch.get(rows.size)
        if surf is None:
            if len(self._scratch) > 3:
                self._scratch.clear()
            surf = self._scratch[rows.size] = pygame.Surface(rows.size, 0, 32)
        draw_sea(surf, r.color, r.tide, self.phase, inset, height=canvas.get_height(), top=rows.y)
        canvas.blit(surf, rows.topleft)

    def render(self, canvas, now):
        """Draws onto canvas; returns the rects that changed."""
        app = self.app
        state = app.night.state
        changed = self._ensure_overlay(canvas, now)
        w, h = canvas.get_size()
        r = self.readout
        if state in ("black", "off"):
            if changed or self.full:
                canvas.fill((0, 0, 0))
                self.full = False
                return [canvas.get_rect()]
            return []
        inset = week_inset(w, h) if r.week else 0
        if changed or self.full:
            self.full = False
            self._paint_sea(canvas, canvas.get_rect(), inset)
            canvas.blit(self.overlay, (0, 0))
            if state == "dim":
                k = int(round(255 * (1 - app.settings["dimLevel"])))
                canvas.fill((k, k, k), special_flags=pygame.BLEND_RGB_MULT)
            self._last_frame = now
            return [canvas.get_rect()]
        if not self.animating():
            return []
        # Just the rolling band.
        band = band_rect(w, h, r.color, r.tide, inset)
        if band.h <= 0:
            return []
        self._paint_sea(canvas, band, inset)
        canvas.blit(self.overlay, band.topleft, band)
        return [band]

    def advance(self, dt):
        """Moves the swell lines on: one full roll every 45 seconds."""
        self.phase = (self.phase + dt / 45.0) % 1.0

    # -- touch ------------------------------------------------------------

    def on_tap(self, x, y, now):
        app = self.app
        if app.night.state != "day":
            app.night.wake_briefly(now)
            self.invalidate()
            return
        if self.controls_visible(now):
            for key, rect in self.buttons.items():
                if rect.collidepoint(x, y):
                    self.controls_until = 0
                    app.open(key)
                    return
            self.controls_until = 0  # second tap hides them
        else:
            self.controls_until = now + self.CONTROLS_SECONDS

    def next_change(self, now):
        """When the picture next needs redrawing without any input."""
        t = (int(now // 60) + 1) * 60
        if self.controls_visible(now):
            t = min(t, self.controls_until)
        return t
