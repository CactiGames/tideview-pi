"""Touch screens built from rows: the beach picker and settings.

A ListScreen has a header bar with a back button and a list of rows you can
drag to scroll. Rows are plain dicts, rebuilt each time the screen is drawn
so they always show the current values.
"""

import time

import pygame

from .gfx import NIGHT, WHITE, blit_text, lerp

ROW_LINE = (255, 255, 255, 0x1A)
SECTION = (0x8B, 0xC7, 0x9A)
PANEL = (0x16, 0x1D, 0x3A)
ON = (0x2F, 0x8C, 0x44)
OFF = (0x4A, 0x52, 0x6E)
STEPPER_SUB_DROP = 18  # a stepper's description starts below its buttons


def row(kind, label="", **kw):
    r = {"kind": kind, "label": label}
    r.update(kw)
    return r


class ListScreen:
    title = ""
    back_label = "Back"

    def __init__(self, app):
        self.app = app
        self.g = app.gfx
        self.scroll = 0.0
        self.max_scroll = 0.0
        self._touch = None
        self._hits = []
        self._dirty = True
        self._held = None  # (callback, next repeat time, interval)
        self._repeated = False
        self._last_render = 0.0
        self._back_rect = None
        self._size = None

    # -- to override --------------------------------------------------------

    def rows(self):
        return []

    def on_back(self):
        self.app.close_screen()

    # -- drawing --------------------------------------------------------------

    def invalidate(self):
        self._dirty = True

    def needs_render(self, now):
        # Redraw when something changed, and every few seconds to keep live
        # values (update status, temperature) fresh.
        return self._dirty or (self._touch is None and now - self._last_render > 5)

    def next_change(self, now):
        if self._held:
            return self._held[1]
        return now + 1.0

    def u(self, w, h):
        return min(w, h) / 600

    def _row_height(self, r, u):
        k = r["kind"]
        if k == "section":
            return 62 * u
        if k == "button":
            return 92 * u
        sub = r.get("sub")
        if sub:
            lines = len(self._sub_lines(r, u))
            return 74 * u + lines * 24 * u + (STEPPER_SUB_DROP * u if k == "stepper" else 0)
        return 80 * u

    def _sub_lines(self, r, u):
        w = self._size[0]
        return self.g.wrap(r["sub"], 18 * u, w - 2 * 28 * u - (0 if r["kind"] == "info" else 40 * u))

    def render(self, canvas, now):
        self._dirty = False
        self._last_render = now
        g = self.g
        w, h = canvas.get_size()
        self._size = (w, h)
        u = self.u(w, h)
        canvas.fill(NIGHT)
        head = int(86 * u)
        rows = self.rows()
        heights = [self._row_height(r, u) for r in rows]
        total = sum(heights) + 40 * u
        self.max_scroll = max(0.0, total - (h - head))
        self.scroll = max(0.0, min(self.scroll, self.max_scroll))
        self._hits = []
        y = head - self.scroll
        clip = pygame.Rect(0, head, w, h - head)
        canvas.set_clip(clip)
        for r, rh in zip(rows, heights):
            if y + rh >= head and y <= h:
                self._draw_row(canvas, r, pygame.Rect(0, int(y), w, int(rh)), u)
            y += rh
        canvas.set_clip(None)
        # Scroll hint.
        if self.max_scroll > 0:
            bar_h = max(40 * u, (h - head) * (h - head) / total)
            bar_y = head + (h - head - bar_h) * (self.scroll / self.max_scroll)
            pygame.draw.rect(canvas, (90, 100, 130), (w - 7 * u, bar_y, 4 * u, bar_h), border_radius=int(2 * u))
        # Header bar.
        pygame.draw.rect(canvas, PANEL, (0, 0, w, head))
        pygame.draw.line(canvas, (40, 48, 80), (0, head - 1), (w, head - 1))
        back = self.g.text("‹ " + self.back_label, 25 * u)
        self._back_rect = pygame.Rect(0, 0, int(back.get_width() + 56 * u), head)
        canvas.blit(back, (int(22 * u), int((head - back.get_height()) / 2)))
        blit_text(canvas, g, self.title, 27 * u, w / 2 + self._back_rect.w / 4, head / 2, bold=True, anchor="mc")
        return [canvas.get_rect()]

    def _draw_row(self, c, r, rect, u):
        g = self.g
        k = r["kind"]
        x0, x1 = 28 * u, rect.w - 28 * u
        if k == "section":
            blit_text(c, g, r["label"].upper(), 18 * u, x0, rect.bottom - 14 * u, color=SECTION, anchor="bl")
            return
        if k == "button":
            b = pygame.Rect(int(x0), int(rect.y + 12 * u), int(x1 - x0), int(rect.h - 24 * u))
            fill = r.get("color", (0x26, 0x30, 0x56))
            pygame.draw.rect(c, fill, b, border_radius=int(16 * u))
            blit_text(c, g, r["label"], 24 * u, b.centerx, b.centery + 1 * u, anchor="mc")
            self._hits.append((b, r.get("on_tap")))
            return
        has_sub = bool(r.get("sub"))
        label_y = rect.y + (24 * u if has_sub else rect.h / 2 - 12 * u)
        right = x1
        if k == "toggle":
            tw, th = 64 * u, 36 * u
            tr = pygame.Rect(int(x1 - tw), int(rect.y + (24 * u if has_sub else rect.h / 2 - th / 2) - (6 * u if has_sub else 0)), int(tw), int(th))
            on = bool(r.get("value"))
            pygame.draw.rect(c, ON if on else OFF, tr, border_radius=int(th / 2))
            knob = g.disc(th - 8 * u, WHITE)
            kx = tr.right - 4 * u - knob.get_width() if on else tr.x + 4 * u
            c.blit(knob, (int(kx), int(tr.y + 4 * u)))
            right = tr.x - 16 * u
            self._hits.append((rect, r.get("on_tap")))
        elif k == "stepper":
            bw = 62 * u
            bh = 50 * u
            by = rect.y + (16 * u if has_sub else (rect.h - bh) / 2)
            plus = pygame.Rect(int(x1 - bw), int(by), int(bw), int(bh))
            # A fixed width for the value keeps the buttons lined up row to row.
            val_w = max(g.text_size(r.get("value", ""), 23 * u)[0] + 24 * u, 132 * u)
            minus = pygame.Rect(int(plus.x - val_w - bw), int(by), int(bw), int(bh))
            arm, thick = int(round(9 * u)), max(2, int(round(3 * u)))
            for b, is_plus in ((minus, False), (plus, True)):
                pygame.draw.rect(c, (0x26, 0x30, 0x56), b, border_radius=int(12 * u))
                pygame.draw.rect(c, WHITE, (b.centerx - arm, b.centery - thick // 2, 2 * arm, thick))
                if is_plus:
                    pygame.draw.rect(c, WHITE, (b.centerx - thick // 2, b.centery - arm, thick, 2 * arm))
            blit_text(c, g, r.get("value", ""), 23 * u, (minus.right + plus.x) / 2, plus.centery + 1 * u, anchor="mc")
            right = minus.x - 14 * u
            self._hits.append((minus.inflate(int(10 * u), int(16 * u)), r.get("on_minus"), True))
            self._hits.append((plus.inflate(int(10 * u), int(16 * u)), r.get("on_plus"), True))
        elif k in ("nav", "cycle"):
            value = r.get("value", "")
            chevron = "›" if k == "nav" else ""
            vx = x1 - (22 * u if chevron else 0)
            if value:
                vr = blit_text(c, g, value, 23 * u, vx, label_y + 1 * u, opacity=0.75, anchor="tr")
                right = vr.x - 16 * u
            if chevron:
                blit_text(c, g, chevron, 34 * u, x1, label_y - 4 * u, opacity=0.6, anchor="tr")
            self._hits.append((rect, r.get("on_tap")))
        elif k == "check":
            if r.get("value"):
                d = g.disc(30 * u, ON)
                dx, dy = x1 - d.get_width(), label_y - 3 * u
                c.blit(d, (int(dx), int(dy)))
                # A tick (the font has no tick mark).
                cx, cy, k2 = dx + d.get_width() / 2, dy + d.get_height() / 2, d.get_width() / 30
                pts = [(cx - 7 * k2, cy + 0.5 * k2), (cx - 2.5 * k2, cy + 5 * k2), (cx + 7 * k2, cy - 5 * k2)]
                pygame.draw.lines(c, WHITE, False, pts, max(2, int(round(3 * k2))))
            right = x1 - 40 * u
            self._hits.append((rect, r.get("on_tap")))
        label = r["label"]
        size = 25 * u
        while g.text_size(label, size)[0] > right - x0 and size > 16 * u:
            size -= 1
        blit_text(c, g, label, size, x0, label_y, color=r.get("label_color", WHITE))
        if has_sub:
            yy = label_y + 34 * u + (STEPPER_SUB_DROP * u if k == "stepper" else 0)
            for line in self._sub_lines(r, u):
                blit_text(c, g, line, 18 * u, x0, yy, opacity=0.62)
                yy += 24 * u
        pygame.draw.line(c, lerp(NIGHT, WHITE, 0.09), (x0, rect.bottom - 1), (rect.w, rect.bottom - 1))

    # -- touch ----------------------------------------------------------------

    def on_touch(self, kind, x, y, now):
        if self._size is None:
            return
        if kind == "down":
            self._touch = {"x": x, "y": y, "scroll": self.scroll, "drag": False}
            self._repeated = False
            hit = self._hit(x, y)
            # Steppers repeat while held: first repeat after half a second.
            self._held = (hit[1], now + 0.5, 0.12) if (hit and len(hit) > 2 and hit[1]) else None
            return
        t = self._touch
        if t is None:
            return
        if kind == "move":
            if not t["drag"] and abs(y - t["y"]) > 14 * self.u(*self._size):
                t["drag"] = True
                self._held = None
            if t["drag"]:
                self.scroll = max(0.0, min(self.max_scroll, t["scroll"] - (y - t["y"])))
                self._dirty = True
            return
        if kind == "up":
            self._held = None
            self._touch = None
            if t["drag"]:
                return
            if self._repeated:  # a held stepper already did its job
                self._repeated = False
                return
            if self._back_rect and self._back_rect.collidepoint(x, y):
                self.on_back()
                return
            hit = self._hit(x, y)
            if hit and hit[1]:
                hit[1]()
                self._dirty = True

    def _hit(self, x, y):
        if y < 86 * self.u(*self._size):
            return None
        for h in self._hits:
            if h[0].collidepoint(x, y):
                return h
        return None

    def tick(self, now):
        """Repeats a held stepper button, a little faster each time."""
        if self._held and now >= self._held[1]:
            cb, _t, interval = self._held
            cb()
            self._repeated = True
            self._held = (cb, now + interval, max(0.04, interval * 0.85))
            self._dirty = True


class RegionPicker(ListScreen):
    title = "Choose your region"

    def rows(self):
        from ..beaches import BEACHES, regions
        current = self.app.settings.beach
        out = []
        for reg in regions():
            n = sum(1 for b in BEACHES if b.region == reg)
            out.append(row("check" if reg == current.region else "nav", reg,
                           value=reg == current.region,
                           sub="%d beaches%s" % (n, " · now showing %s" % current.name if reg == current.region else ""),
                           on_tap=lambda reg=reg: self.app.push(BeachPicker(self.app, reg))))
        return out


class BeachPicker(ListScreen):
    def __init__(self, app, region):
        super().__init__(app)
        self.region = region
        self.title = region

    def rows(self):
        from ..beaches import BEACHES
        current = self.app.settings.beach.id
        out = []
        for b in BEACHES:
            if b.region != self.region:
                continue
            sub = "Best swell %s · offshore wind %s%s" % (
                b.ideal_swell, b.ideal_wind, "" if b.tide == "any" else " · %s tide" % b.tide)
            out.append(row("check", b.name, value=b.id == current, sub=sub, on_tap=lambda b=b: self._pick(b)))
        return out

    def _pick(self, b):
        self.app.choose_beach(b)


class ConfirmButton:
    """A button that needs a second tap within a few seconds."""

    def __init__(self, label, confirm_label, action):
        self.label = label
        self.confirm_label = confirm_label
        self.action = action
        self.armed_until = 0.0

    def current_label(self):
        return self.confirm_label if time.time() < self.armed_until else self.label

    def tap(self):
        if time.time() < self.armed_until:
            self.armed_until = 0.0
            self.action()
        else:
            self.armed_until = time.time() + 5
