"""Surf score on a 1 (worst) to 10 (best) scale, and the waves that reach a
beach: the same rules as the Android app (lib/services/rating.dart)."""

import math

from .compass import angle_between

GRADE_LABELS = [
    "Flat or blown out",
    "Very poor",
    "Poor",
    "Poor to fair",
    "Fair",
    "Average",
    "Fair to good",
    "Good",
    "Very good",
    "Firing",
]

# Red (1) through orange and yellow (average) to a rich dark green (10).
GRADE_COLORS = [
    (0x7A, 0x1C, 0x1C),  # 1
    (0x9B, 0x26, 0x26),  # 2
    (0xB5, 0x3A, 0x2A),  # 3
    (0xC7, 0x5A, 0x2B),  # 4
    (0xCF, 0x7F, 0x2D),  # 5
    (0xC9, 0xA6, 0x35),  # 6 average: yellow
    (0x9D, 0xB0, 0x3E),  # 7
    (0x63, 0xA6, 0x4A),  # 8 light green
    (0x2F, 0x8C, 0x44),  # 9
    (0x16, 0x65, 0x3A),  # 10 rich dark green
]

FEET = 3.28084


class SurfRating:
    __slots__ = ("grade", "score", "size", "period", "swell_direction", "wind", "tide", "surf")

    def __init__(self, grade, score, size, period, swell_direction, wind, tide, surf=None):
        self.grade = grade  # 1..10
        self.score = score  # 0..1 before rounding into a grade
        # Each part is 0 (bad) .. 1 (ideal).
        self.size = size
        self.period = period
        self.swell_direction = swell_direction
        self.wind = wind
        self.tide = tide
        self.surf = surf  # the SurfEstimate the score is based on, or None

    @property
    def label(self):
        return GRADE_LABELS[self.grade - 1]

    @property
    def color(self):
        return GRADE_COLORS[self.grade - 1]


UNKNOWN = SurfRating(5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5)


def _curve(x, pts):
    """Piecewise-linear lookup through (x, y) points sorted by x."""
    if x <= pts[0][0]:
        return pts[0][1]
    for i in range(1, len(pts)):
        if x <= pts[i][0]:
            a, b = pts[i - 1], pts[i]
            return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])
    return pts[-1][1]


def grade_for_score(score):
    return max(1, min(10, 1 + int(math.floor(max(0.0, min(1.0, score)) * 9.999))))


# ------------------------------------------------------- surf at the beach


class WaveTrain:
    """One group of waves: the swell, or the local wind chop."""
    __slots__ = ("height", "period", "direction")

    def __init__(self, height, period, direction):
        self.height = height  # significant height, m
        self.period = period  # peak period, s (or None)
        self.direction = direction  # where the waves come FROM, degrees (or None)


class SurfEstimate:
    """The waves that actually reach a beach."""
    __slots__ = ("face", "height", "period", "direction", "off_angle")

    def __init__(self, face, height, period=None, direction=None, off_angle=None):
        # Face height of the bigger waves (the sets) as they break, in metres:
        # the number surfers quote, like MetService's "set face".
        self.face = face
        # Significant height of the waves reaching the beach, metres.
        self.height = height
        # Peak period and direction of the waves that matter most here.
        self.period = period
        self.direction = direction
        # How far (degrees) those waves come from the beach's best swell direction.
        self.off_angle = off_angle


EXPOSURE = ((0, 1.0), (30, 0.95), (60, 0.7), (90, 0.35), (120, 0.1), (150, 0.0))


def exposure_for(off_angle):
    """How much of a wave train reaches a beach, by how far (degrees) it comes
    from the beach's best swell direction. Waves from the land side (for
    example chop made by an offshore wind, heading out to sea) don't arrive."""
    return _curve(off_angle, EXPOSURE)


# Set face from swell height and period: waves grow as they reach shallow
# water, more so for longer periods. A breaking-wave height formula (Komar &
# Gaughan) scaled to MetService's Lyall Bay surf page, where for example a
# 1.3 m, 12 s swell shows a 1.8 m set face and a 0.8 m, 11 s swell about 1.2 m.
SET_FACE_FACTOR = 0.54


def set_face(height, period):
    return SET_FACE_FACTOR * (period * height * height) ** 0.4


def wave_trains(c):
    """The wave trains in conditions c: the swell and the wind chop when the
    source splits them, otherwise all the waves as one."""
    out = []
    if c.swell_height is not None:
        out.append(WaveTrain(c.swell_height, c.period, c.swell_direction))
    if c.sea_height is not None and c.sea_height > 0:
        out.append(WaveTrain(c.sea_height, c.sea_period, c.sea_direction))
    if not out and c.wave_height is not None:
        out.append(WaveTrain(c.wave_height, c.period, c.swell_direction))
    return out


def estimate_surf(beach, c):
    """What reaches the beach: each wave train counts by how square-on it
    comes in, and the set face comes from the biggest of them. None when
    there are no waves in c."""
    trains = wave_trains(c)
    if not trains:
        return None
    energy = 0.0
    face = 0.0
    main, main_off, main_face = None, None, -1.0
    for t in trains:
        off = 45.0 if t.direction is None else angle_between(t.direction, beach.ideal_swell_deg)
        h = t.height * exposure_for(off)
        energy += h * h
        f = h if (t.period is None or t.period <= 0) else set_face(h, t.period)
        if f > main_face:  # on a tie the swell (listed first) stays the main train
            main_face, main = f, t
            main_off = None if t.direction is None else off
        face = max(face, f)
    height = math.sqrt(energy)
    return SurfEstimate(max(face, height), height, main.period, main.direction, main_off)


# ------------------------------------------------------------------ wind


def offshore_angle(beach, wind_from):
    """How far (degrees) the wind is from offshore at the beach: 0 = straight
    offshore. Offshore is the break's listed best wind, or straight off the
    land (opposite the way the beach faces the swell), whichever is closer.
    At Lyall Bay a northerly and a north-westerly both count."""
    return min(angle_between(wind_from, beach.ideal_wind_deg),
               angle_between(wind_from, (beach.ideal_swell_deg + 180) % 360))


OFFSHORE = ((0, 1.0), (12, 1.0), (20, 0.92), (30, 0.82), (40, 0.73), (50, 0.62), (60, 0.5), (75, 0.3),
            (90, 0.12), (100, 0.05))
CROSS = ((0, 1.0), (8, 1.0), (15, 0.85), (25, 0.6), (35, 0.4), (50, 0.2), (70, 0.08))
ONSHORE = ((0, 1.0), (5, 0.9), (10, 0.7), (15, 0.55), (20, 0.43), (30, 0.3), (40, 0.2), (60, 0.1))


def wind_factor(beach, c):
    """0 (ruins it) .. 1 (perfect) for the wind at the beach. Light wind is
    always fine. Offshore grooms the waves and stays good into a fresh
    breeze, but a strong one makes it hard work: matched to MetService's
    Lyall Bay ratings, where a long-period south swell rates 8 with a
    northerly averaging about 37 km/h. Cross-shore and onshore wind spoil it
    quickly. Uses the average wind, not the gusts: forecast gusts differ a
    lot between models, and the calibration allows for ordinary gustiness."""
    if c.wind_speed is None:
        return 0.85
    kmh = c.wind_speed
    off = 90.0 if c.wind_direction is None else offshore_angle(beach, c.wind_direction)
    offshore = _curve(kmh, OFFSHORE)
    cross = _curve(kmh, CROSS)
    onshore = _curve(kmh, ONSHORE)
    if off <= 45:
        return offshore
    if off <= 90:
        return offshore + (cross - offshore) * (off - 45) / 45
    if off <= 135:
        return cross + (onshore - cross) * (off - 90) / 45
    return onshore


# ----------------------------------------------------------------- score

# Size of the sets as they break, by face height in feet: flat is useless,
# 4-9 ft faces are the sweet spot, very big gets messy.
SIZE = ((0.5, 0.0), (1, 0.1), (1.5, 0.28), (2, 0.45), (2.6, 0.6), (3, 0.68), (4, 0.8), (5, 0.9), (6, 0.97),
        (7, 1.0), (9, 1.0), (12, 0.85), (16, 0.6), (20, 0.4))
# Period: short wind waves are weak and messy, long groundswell is clean.
PERIOD = ((4, 0.55), (6, 0.7), (8, 0.85), (10, 0.95), (12, 1.0))
# Swell direction: the size already allows for how much gets in; this adds
# the break's own preference for its best swell direction.
DIRECTION = ((0, 1.0), (25, 1.0), (50, 0.92), (80, 0.8), (110, 0.7), (150, 0.6))


def rate_surf(beach, c):
    """Scores how surfable conditions c are at beach."""
    surf = estimate_surf(beach, c)
    if surf is None:
        return UNKNOWN
    size = _curve(surf.face * FEET, SIZE)
    period = 0.85 if surf.period is None else _curve(surf.period, PERIOD)
    swell_dir = 0.92 if surf.off_angle is None else _curve(surf.off_angle, DIRECTION)
    wind = wind_factor(beach, c)

    # Tide: only matters for breaks that prefer one end of it.
    tide = 1.0
    f = c.tide_fraction
    if f is not None:
        if beach.tide == "high":
            tide = 0.3 + 0.7 * f
        elif beach.tide == "low":
            tide = 0.3 + 0.7 * (1 - f)

    # The swell sets how good it can be; wind and tide decide how much of
    # that you actually get. No amount of nice wind makes a flat day good.
    score = max(0.0, min(1.0, size * period * swell_dir * wind * (0.8 + 0.2 * tide)))
    return SurfRating(grade_for_score(score), score, size, period, swell_dir, wind, tide, surf)
