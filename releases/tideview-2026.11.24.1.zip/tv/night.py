"""Night mode: dim the picture, make it black, or turn the screen off, by
time of day. A tap at night brings the picture back for a minute."""

from datetime import datetime


class NightController:
    def __init__(self, settings):
        self.settings = settings
        self.state = "day"  # "day", "dim", "black" or "off"
        self._woken_until = 0.0

    def in_night_window(self, now):
        d = datetime.fromtimestamp(now)
        m = d.hour * 60 + d.minute
        start, end = self.settings["nightStart"], self.settings["dayStart"]
        if start == end:
            return False
        return (start <= m < end) if start < end else (m >= start or m < end)

    def wake_briefly(self, now, seconds=60):
        self._woken_until = now + seconds

    def evaluate(self, now):
        """Works out the state for now; returns True when it changed."""
        mode = self.settings["nightMode"]
        nxt = "day"
        if mode != "off" and self.in_night_window(now) and now >= self._woken_until:
            nxt = {"dim": "dim", "black": "black", "screenOff": "off"}.get(mode, "day")
        changed = nxt != self.state
        self.state = nxt
        return changed
