"""Compass helpers: 16-point names <-> degrees, and angular distance."""

POINTS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
          "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]


def name(deg):
    """16-point compass name for a bearing in degrees (0 = north, clockwise)."""
    d = deg % 360
    return POINTS[int((d + 11.25) // 22.5) % 16]


def degrees(point):
    """Bearing in degrees for a 16-point compass name."""
    return POINTS.index(point.upper()) * 22.5


def angle_between(a, b):
    """Smallest angle between two bearings, 0..180."""
    d = abs(a - b) % 360
    return 360 - d if d > 180 else d


def lerp_bearing(a, b, t):
    """Interpolates between two bearings the short way round."""
    diff = (b - a) % 360
    if diff > 180:
        diff -= 360
    return (a + diff * t) % 360
