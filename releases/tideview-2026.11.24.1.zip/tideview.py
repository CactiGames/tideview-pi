#!/usr/bin/env python3
"""TideView for Raspberry Pi: an always-on surf forecast for a picture frame.

On the Pi it runs as a service and draws straight to the screen:
    sudo systemctl start tideview      (install.sh sets this up)

To try it on a PC in a window (needs Python 3 and pygame):
    python3 tideview.py --window                 sideways, like the 7" panel
    python3 tideview.py --window --size 600x1024 any size
Mouse clicks act as taps. Esc goes back (or quits), R refreshes, Q quits.

Settings and the forecast cache are kept in /var/lib/tideview (or
~/.local/state/tideview when not run as root). API keys are read from
.env.txt next to this file, or in the tideview folder on the SD card.

On the Pi, tvupdate.py (next to this file) keeps TideView up to date. It
runs "tideview.py --selftest" on each new version before switching to it.
"""

import argparse
import logging
import os
import sys

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def parse_size(text):
    w, h = text.lower().split("x")
    return int(w), int(h)


def main(argv=None):
    p = argparse.ArgumentParser(description="TideView surf display")
    p.add_argument("--window", action="store_true", help="show in a window instead of the framebuffer")
    p.add_argument("--size", type=parse_size, help="panel size for --window/--screenshot, e.g. 1024x600")
    p.add_argument("--fb", default="/dev/fb0", help="framebuffer device (default /dev/fb0)")
    p.add_argument("--screenshot", metavar="PNG", help="fetch the forecast, save one picture and exit")
    p.add_argument("--verbose", action="store_true", help="more detail in the log")
    p.add_argument("--selftest", action="store_true", help="draw every screen once without a display, then exit")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    log = logging.getLogger("tideview")

    if args.selftest:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
    elif not args.window and not args.screenshot and os.path.exists(args.fb):
        # Framebuffer mode: no window system needed.
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    import pygame
    pygame.font.init()

    from tv.app import App, make_output
    from tv.settings import Settings, load_keys

    from tv.version import VERSION

    settings = Settings()
    keys = load_keys()
    if args.selftest:
        return selftest(settings, keys, log)
    log.info("TideView %s starting: beach %s, NIWA key %s, MetService key %s", VERSION, settings.beach.name,
             "found" if keys["niwa"] else "missing", "found" if keys["metocean"] else "missing")

    output, panel = make_output(args, settings)
    touch = None
    if output.kind == "framebuffer":
        from tv.touch import TouchReader
        touch = TouchReader()

    app = App(output, settings, keys, touch=touch, panel_size=panel)

    if args.screenshot:
        import time
        app.forecast.start()
        deadline = time.time() + 60
        while app.forecast.forecast is None and time.time() < deadline:
            time.sleep(0.5)
        while app.forecast.loading and time.time() < deadline:
            time.sleep(0.5)
        app.step(wait=False)
        app.forecast.stop()
        pygame.image.save(output.frame, args.screenshot)
        log.info("saved %s", args.screenshot)
        return 0

    code = app.run()
    log.info("stopped")
    logging.shutdown()
    # Leave straight away rather than wait for a download in progress.
    # (Settings and the forecast cache are always saved whole.)
    os._exit(code)


def selftest(settings, keys, log):
    """Draws every screen once, with no display, network or touch screen.
    The updater runs this on a new version before switching to it, so a
    version that can't start never reaches the screen."""
    import importlib
    import pkgutil

    import tv
    import tv.ui
    for package in (tv, tv.ui):  # every module must at least import
        for module in pkgutil.iter_modules(package.__path__, package.__name__ + "."):
            importlib.import_module(module.name)
    from tv.app import App
    from tv.output import ImageOutput, logical_size
    from tv.ui.frame import FrameEditor
    from tv.ui.lists import BeachPicker, RegionPicker
    from tv.ui.settings_screen import SettingsScreen
    from tv.version import VERSION

    panel = (1024, 600)
    rotation = settings.rotation
    output = ImageOutput(logical_size(panel[0], panel[1], rotation), rotation)
    app = App(output, settings, keys, panel_size=panel)  # the forecast comes from the cache, if any
    app.step(wait=False)
    region = app.forecast.beach.region
    for make in (SettingsScreen, RegionPicker, lambda a: BeachPicker(a, region), FrameEditor):
        app.push(make(app))
        app.step(wait=False)
        app.close_screen()
    app.step(wait=False)
    selftest_phone_and_wifi(app)
    if output.frame is None:
        raise RuntimeError("nothing was drawn")
    log.info("self-test passed: TideView %s drew every screen", VERSION)
    return 0


def selftest_phone_and_wifi(app):
    """What a phone sees, the card that links one, and the No Wi-Fi line,
    all drawn or built once (no network needed)."""
    import json
    import time

    from tv.netwatch import NetWatch

    remote = app.remote
    if remote is None:
        raise RuntimeError("phone control didn't set up")
    remote.preview_address = "192.168.1.23"
    state = remote.state()
    json.dumps(state)
    ids = [r.get("id") for r in state["rows"]]
    for need in ("beach", "use24h", "nightMode", "checkUpdates" if "checkUpdates" in ids else "refresh"):
        if need not in ids:
            raise RuntimeError("phones can't see the %s setting" % need)
    was = app.settings["use24h"]
    remote.act("use24h", "tap")
    remote.act("use24h", "tap")
    if app.settings["use24h"] != was:
        raise RuntimeError("a phone's tap didn't work")
    remote.act("nightMode", "choose", 0)
    json.dumps(remote.beaches())
    remote.show_code()
    app.step(wait=False)  # draws the card
    if app._card_rect is None:
        raise RuntimeError("the card for linking a phone wasn't drawn")
    remote.show_until = 0.0
    remote.preview_address = None
    net = NetWatch(fix=False)
    net.online = False
    net.offline_since = time.monotonic() - 600
    net.clock_ok = False
    net.diagnosis = "The Pi can't see any Wi-Fi networks at all, not even neighbours'."
    app.net = net
    app.display.invalidate()
    app.step(wait=False)
    app.net = None
    app.display.invalidate()
    app.step(wait=False)


if __name__ == "__main__":
    sys.exit(main())
