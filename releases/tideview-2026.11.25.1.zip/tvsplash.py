#!/usr/bin/env python3
"""Puts the TideView logo on the screen a few seconds after power-on.

tideview-splash.service runs this very early in each start-up (TideView
itself takes a while longer to get going). It copies splash.fb, a picture
TideView saved of its own splash screen, straight onto the framebuffer.

It only uses Python's standard library, so it starts fast, and it never
complains: if anything isn't right (no picture, a different screen, the
rescue start-up, night time) it quietly leaves the screen alone.
"""

import fcntl
import json
import os
import struct
import sys
import time

FB = "/dev/fb0"
TTY = "/dev/tty1"
STATE = os.environ.get("TIDEVIEW_STATE") or "/var/lib/tideview"
SPLASH = os.path.join(STATE, "splash.fb")
MAGIC = b"TVSPLASH1\n"
FBIOGET_VSCREENINFO = 0x4600
KDSETMODE = 0x4B3A
KD_GRAPHICS = 1
WAIT_FOR_SCREEN = 30  # seconds


def kernel_cmdline():
    try:
        with open("/proc/cmdline", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def night_now():
    """True during the night hours when the screen is meant to stay dark."""
    try:
        with open(os.path.join(STATE, "settings.json"), encoding="utf-8") as f:
            s = json.load(f)
    except (OSError, ValueError):
        return False
    if s.get("nightMode", "off") == "off":
        return False
    try:
        start, end = int(s.get("nightStart", 22 * 60)), int(s.get("dayStart", 6 * 60))
    except (TypeError, ValueError):
        return False
    lt = time.localtime()
    m = lt.tm_hour * 60 + lt.tm_min
    if start == end:
        return False
    return start <= m < end if start < end else (m >= start or m < end)


def read_splash():
    with open(SPLASH, "rb") as f:
        if f.read(len(MAGIC)) != MAGIC:
            return None, None
        head = json.loads(f.readline().decode("ascii"))
        return head, f.read()


def screen_info(fd):
    var = bytearray(160)
    fcntl.ioctl(fd, FBIOGET_VSCREENINFO, var, True)
    f = struct.unpack_from("8I", var)
    xres, yres, xres_v, xoff, yoff, bpp = f[0], f[1], f[2], f[4], f[5], f[6]
    stride = 0
    try:
        with open("/sys/class/graphics/fb0/stride") as s:
            stride = int(s.read().strip())
    except (OSError, ValueError):
        pass
    stride = stride or xres_v * bpp // 8
    return xres, yres, bpp, stride, yoff * stride + xoff * bpp // 8


def write_all(fd, data):
    view = memoryview(data)
    while view:
        n = os.write(fd, view)
        if n <= 0:
            break
        view = view[n:]


def main():
    cmdline = kernel_cmdline()
    if "systemd.run" in cmdline or "systemd.unit=" in cmdline:
        return 0  # the rescue start-up writes its own messages on the screen
    if night_now():
        return 0
    head, data = read_splash()
    if not head or not data:
        return 0
    deadline = time.monotonic() + WAIT_FOR_SCREEN
    while not os.path.exists(FB):
        if time.monotonic() > deadline:
            return 0
        time.sleep(0.2)
    fd = os.open(FB, os.O_RDWR)
    try:
        xres, yres, bpp, stride, offset = screen_info(fd)
        w, h, pitch = int(head["w"]), int(head["h"]), int(head["pitch"])
        if (w, h, bpp) != (xres, yres, int(head["bpp"])) or len(data) < pitch * h:
            return 0  # saved for a different screen: TideView saves a new one
        # Keep the text console from drawing over the picture.
        try:
            tty = os.open(TTY, os.O_RDWR | os.O_NOCTTY)
            try:
                fcntl.ioctl(tty, KDSETMODE, KD_GRAPHICS)
            finally:
                os.close(tty)
        except OSError:
            pass
        row = w * bpp // 8
        if pitch == stride:
            os.lseek(fd, offset, os.SEEK_SET)
            write_all(fd, data[:pitch * h])
        else:
            for y in range(h):
                os.lseek(fd, offset + y * stride, os.SEEK_SET)
                write_all(fd, data[y * pitch:y * pitch + row])
    finally:
        os.close(fd)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:  # noqa: BLE001  (never fails the start-up)
        sys.exit(0)
