#!/usr/bin/env python3
"""TideView for Raspberry Pi: an always-on surf forecast for a picture frame.

On the Pi it runs as a service and draws straight to the screen:
    sudo systemctl start tideview      (install.sh sets this up)

To try it on a PC in a window (needs Python 3 and pygame):
    python3 tideview.py --window                 sideways, like the 7" panel
    python3 tideview.py --window --size 600x1024 any size
Mouse clicks act as taps. Esc goes back (or quits), R refreshes, Q quits.

Settings and the forecast cache are kept in /var/lib/tideview (or
~/.local/state/tideview when not run as root). API keys are read from
.env.txt next to this file, or in the tideview folder on the SD card.

On the Pi, tvupdate.py (next to this file) keeps TideView up to date. It
runs "tideview.py --selftest" on each new version before switching to it.
"""

import argparse
import logging
import os
import sys

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def parse_size(text):
    w, h = text.lower().split("x")
    return int(w), int(h)


def main(argv=None):
    p = argparse.ArgumentParser(description="TideView surf display")
    p.add_argument("--window", action="store_true", help="show in a window instead of the framebuffer")
    p.add_argument("--size", type=parse_size, help="panel size for --window/--screenshot, e.g. 1024x600")
    p.add_argument("--fb", default="/dev/fb0", help="framebuffer device (default /dev/fb0)")
    p.add_argument("--screenshot", metavar="PNG", help="fetch the forecast, save one picture and exit")
    p.add_argument("--verbose", action="store_true", help="more detail in the log")
    p.add_argument("--selftest", action="store_true", help="draw every screen once without a display, then exit")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    log = logging.getLogger("tideview")

    if args.selftest:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
    elif not args.window and not args.screenshot and os.path.exists(args.fb):
        # Framebuffer mode: no window system needed.
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    import pygame
    pygame.font.init()

    from tv.app import App, make_output
    from tv.settings import Settings, load_keys

    from tv.version import VERSION

    settings = Settings()
    keys = load_keys()
    if args.selftest:
        return selftest(settings, keys, log)
    if not args.screenshot:
        log_to_file(log)
    log.info("TideView %s starting: beach %s, NIWA key %s, MetService key %s", VERSION, settings.beach.name,
             "found" if keys["niwa"] else "missing", "found" if keys["metocean"] else "missing")

    output, panel = make_output(args, settings)
    touch = None
    if output.kind == "framebuffer":
        from tv.touch import TouchReader
        touch = TouchReader()
        # The logo at power-on instead of the Pi's start-up text (checked each start).
        from tv import bootlook
        from tv.settings import state_dir
        bootlook.apply_soon(HERE, state_dir())

    # The logo over rolling water while the first forecast loads (not for a screenshot).
    app = App(output, settings, keys, touch=touch, panel_size=panel, splash=not args.screenshot)

    if args.screenshot:
        import time
        app.forecast.start()
        deadline = time.time() + 60
        while app.forecast.forecast is None and time.time() < deadline:
            time.sleep(0.5)
        while app.forecast.loading and time.time() < deadline:
            time.sleep(0.5)
        app.step(wait=False)
        app.forecast.stop()
        pygame.image.save(output.frame, args.screenshot)
        log.info("saved %s", args.screenshot)
        return 0

    code = app.run()
    log.info("stopped")
    logging.shutdown()
    # Leave straight away rather than wait for a download in progress.
    # (Settings and the forecast cache are always saved whole.)
    os._exit(code)


def log_to_file(log):
    """Keeps TideView's log in the state folder as well, across restarts
    (the Pi's own journal forgets it all at each restart). The report that
    can be saved to the SD card includes it."""
    try:
        from logging.handlers import RotatingFileHandler

        from tv import report
        h = RotatingFileHandler(report.log_path(), maxBytes=256 * 1024, backupCount=1, encoding="utf-8")
        h.setLevel(logging.INFO)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S"))
        logging.getLogger().addHandler(h)
    except Exception as e:  # noqa: BLE001
        log.warning("couldn't keep a log file: %s", e)


def selftest(settings, keys, log):
    """Draws every screen once, with no display, network or touch screen.
    The updater runs this on a new version before switching to it, so a
    version that can't start never reaches the screen."""
    import importlib
    import pkgutil

    import tv
    import tv.ui
    for package in (tv, tv.ui):  # every module must at least import
        for module in pkgutil.iter_modules(package.__path__, package.__name__ + "."):
            importlib.import_module(module.name)
    from tv.app import App
    from tv.output import ImageOutput, logical_size
    from tv.ui.frame import FrameEditor
    from tv.ui.lists import BeachPicker, RegionPicker
    from tv.ui.settings_screen import SECTIONS, SectionScreen, SettingsScreen
    from tv.ui.setup import PairScreen, SplashScreen, WelcomeScreen
    from tv.version import VERSION

    panel = (1024, 600)
    rotation = settings.rotation
    output = ImageOutput(logical_size(panel[0], panel[1], rotation), rotation)
    app = App(output, settings, keys, panel_size=panel)  # the forecast comes from the cache, if any
    app.step(wait=False)
    region = app.forecast.beach.region
    parent = SettingsScreen(app)
    screens = [SettingsScreen, RegionPicker, lambda a: BeachPicker(a, region), FrameEditor, SplashScreen,
               WelcomeScreen, PairScreen]
    screens += [lambda a, key=key, title=title: SectionScreen(a, parent, key, title) for key, title, _i in SECTIONS]
    for make in screens:
        app.push(make(app))
        app.step(wait=False)
        app.close_screen()
    app.step(wait=False)
    selftest_preview_and_frame(app)
    selftest_phone_and_wifi(app)
    selftest_wifi_settings_and_report(app)
    if output.frame is None:
        raise RuntimeError("nothing was drawn")
    log.info("self-test passed: TideView %s drew every screen", VERSION)
    return 0


def selftest_phone_and_wifi(app):
    """What a phone sees, the card that links one, and the No Wi-Fi line,
    all drawn or built once (no network needed)."""
    import json
    import time

    from tv.netwatch import NetWatch

    remote = app.remote
    if remote is None:
        raise RuntimeError("phone control didn't set up")
    remote.preview_address = "192.168.1.23"
    state = remote.state()
    json.dumps(state)
    ids = [r.get("id") for r in state["rows"]]
    for need in ("beach", "use24h", "nightMode", "checkUpdates" if "checkUpdates" in ids else "refresh"):
        if need not in ids:
            raise RuntimeError("phones can't see the %s setting" % need)
    was = app.settings["use24h"]
    remote.act("use24h", "tap")
    remote.act("use24h", "tap")
    if app.settings["use24h"] != was:
        raise RuntimeError("a phone's tap didn't work")
    remote.act("nightMode", "choose", 0)
    json.dumps(remote.beaches())
    if len(state.get("sections") or []) < 8 or "status" not in state:
        raise RuntimeError("phones can't see the sections or the status")
    from tv.ui.setup import PairScreen
    remote.show_code()
    app.step(wait=False)  # draws the code
    if not isinstance(app.screen, PairScreen):
        raise RuntimeError("Link a phone didn't show the code")
    app.home()
    app.step(wait=False)
    remote.preview_address = None
    net = NetWatch(fix=False)
    net.online = False
    net.offline_since = time.monotonic() - 600
    net.clock_ok = False
    net.diagnosis = "The Pi can't see any Wi-Fi networks at all, not even neighbours'."
    app.net = net
    app.display.invalidate()
    app.step(wait=False)
    app.net = None
    app.display.invalidate()
    app.step(wait=False)


def selftest_preview_and_frame(app):
    """The phone's preview picture and its arrow buttons for the picture's
    position (the settings are put back afterwards)."""
    import json

    remote = app.remote
    if remote is None:
        return
    for tap in (False, True):
        pic = remote.preview(240, tap=tap)
        if not pic.data or len(pic.data) < 200:
            raise RuntimeError("the preview came out empty")
    s = app.settings
    keep = {k: s[k] for k in ("frameEnabled", "frameLeftMm", "frameTopMm", "frameWidthMm", "frameHeightMm")}
    try:
        for body in ({"op": "move", "dx": 2, "dy": -2}, {"op": "edge", "edge": "left", "delta": 3},
                     {"op": "grow", "delta": -1}):
            json.dumps(remote.frame_change(body))
        app.step(wait=False)  # draws the outline
        remote.preview(240)
    finally:
        s.set(**keep)
        app.frame_guide_until = 0.0
        app.frame_changed()
        app.step(wait=False)


def selftest_wifi_settings_and_report(app):
    """Settings > Wi-Fi, the keyboard and the report, with a stand-in for
    NetworkManager (the self-test never touches the real Wi-Fi)."""
    import json

    from tv import report
    from tv.ui.keyboard import KeyboardScreen
    from tv.ui.settings_screen import SettingsScreen
    from tv.ui.wifi_screen import WifiScreen
    from tv.wifi import FakeWifi, WifiManager

    real = app.wifi
    fake = WifiManager(FakeWifi())
    fake._scan()  # right here, not on a thread
    app.wifi = fake
    try:
        app.push(SettingsScreen(app))
        app.step(wait=False)
        app.close_screen()
        app.push(WifiScreen(app))
        app.step(wait=False)
        if not any(r.get("label") == "Blackmore 5G" for r in app.screen.rows()):
            raise RuntimeError("the Wi-Fi screen didn't list the networks")
        typed = []
        kb = KeyboardScreen(app, "Wi-Fi password", on_done=typed.append, secret=True,
                            check=lambda t: "" if len(t) >= 8 else "too short")
        app.push(kb)
        for key in ("shift", "a", "b", "mode", "!", "@", "mode", "c", "d", "e", "f", "del", "f"):
            kb.press(key)
        app.step(wait=False)
        kb.show = True
        kb.symbols = True
        kb.invalidate()
        app.step(wait=False)
        kb.press("done")
        if typed != ["Ab!@cdef"]:
            raise RuntimeError("the keyboard typed %r" % typed)
        app.close_screen()
        if app.remote is not None:
            ids = [r.get("id") for r in app.remote.state()["rows"]]
            if "wifi" not in ids or "saveReport" not in ids:
                raise RuntimeError("phones can't see the Wi-Fi or report rows")
            json.dumps(app.remote.wifi_state())
        text = report.build(report.gather(app, "self-test"), run=lambda cmd, timeout=0: (0, "ok"))
        if "TideView report" not in text:
            raise RuntimeError("the report came out empty")
        if app.remote is not None and app.remote.pairing.code in text:
            raise RuntimeError("the report shows the phone code")
    finally:
        app.wifi = real
        app.home()
        app.step(wait=False)


if __name__ == "__main__":
    sys.exit(main())
