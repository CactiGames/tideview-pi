"""Watches the Wi-Fi: tells the screen when the Pi is offline, and nudges the
Wi-Fi back when it drops.

Every 30 seconds it checks that the Pi has an address and that the router
answers. Offline, it first makes sure the Wi-Fi isn't switched off (rfkill or
NetworkManager), asks NetworkManager to reconnect after 2 minutes, and
restarts NetworkManager after 15 minutes (then every half hour). It never
turns the Wi-Fi off and never restarts the Pi, and it only acts on a Pi
running as the service. While offline it works out why, in plain words, for
the screen and Settings.

It also notes whether the clock has been set from the internet since the Pi
started (a Pi has no clock battery), so the screen can say when the time on
it may be wrong.
"""

import logging
import os
import shutil
import subprocess
import threading
import time

from . import system

log = logging.getLogger("tideview.wifi")

CHECK_EVERY = 30  # seconds
FIRST_CHECK = 20  # seconds after TideView starts
STEPS = ((0, "unblock"), (120, "reconnect"), (900, "restart"))
DIAGNOSE_EVERY = 120
RESTART_AGAIN = 1800
SAY_AFTER = 60  # seconds offline before the screen says so
WIFI = "wlan0"


def _on_a_pi():
    """Root on Linux with a Wi-Fi driver or NetworkManager: the Pi service.
    (wlan0 itself may be missing: that's one of the problems it explains.)"""
    return (os.name == "posix" and hasattr(os, "geteuid") and os.geteuid() == 0
            and os.path.isdir("/sys/class/net") and (shutil.which("nmcli") is not None
                                                     or os.path.isdir("/sys/class/net/" + WIFI)))


def _run(cmd, timeout=60):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        return r.returncode, r.stdout.decode("utf-8", "replace").strip()
    except (OSError, subprocess.SubprocessError) as e:
        return -1, str(e)


def gateway():
    """The router's address from the routing table, or None."""
    try:
        with open("/proc/net/route") as f:
            next(f)
            for line in f:
                parts = line.split()
                if len(parts) > 3 and parts[1] == "00000000" and int(parts[3], 16) & 2:
                    g = int(parts[2], 16)
                    return "%d.%d.%d.%d" % (g & 255, (g >> 8) & 255, (g >> 16) & 255, (g >> 24) & 255)
    except (OSError, ValueError, StopIteration):
        pass
    return None


def router_answers(gw):
    """True if the router answers a ping, or at least its Wi-Fi address is
    known (some routers ignore pings)."""
    if shutil.which("ping"):
        code, _ = _run(["ping", "-c", "1", "-W", "3", gw], timeout=8)
        if code == 0:
            return True
    else:
        return True  # can't tell: trust the address
    code, out = _run(["ip", "neigh", "show", gw], timeout=5)
    if code != 0:
        return True
    return "lladdr" in out and "FAILED" not in out and "INCOMPLETE" not in out


def _nm(*args, timeout=20):
    if not shutil.which("nmcli"):
        return -1, ""
    return _run(["nmcli"] + list(args), timeout=timeout)


def wifi_blocked():
    """'soft' or 'hard' if rfkill has the Wi-Fi switched off, else None."""
    try:
        for name in sorted(os.listdir("/sys/class/rfkill")):
            d = os.path.join("/sys/class/rfkill", name)
            with open(os.path.join(d, "type")) as f:
                if f.read().strip() != "wlan":
                    continue
            with open(os.path.join(d, "hard")) as f:
                if f.read().strip() == "1":
                    return "hard"
            with open(os.path.join(d, "soft")) as f:
                if f.read().strip() == "1":
                    return "soft"
    except (OSError, ValueError):
        pass
    return None


def _nm_fields(text):
    """Splits nmcli -t output (colons, with \\: for a colon in a value)."""
    out = []
    for line in text.splitlines():
        parts, cur, esc = [], "", False
        for ch in line:
            if esc:
                cur += ch
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == ":":
                parts.append(cur)
                cur = ""
            else:
                cur += ch
        parts.append(cur)
        out.append(parts)
    return out


def power_dipped():
    try:
        r = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=5)
        value = int(r.stdout.strip().split("=")[1], 16)
    except (OSError, ValueError, IndexError, subprocess.SubprocessError):
        return False
    return bool(value & 0x1 or value & 0x10000)


def diagnose():
    """Plain words for why the Pi has no Wi-Fi."""
    if not os.path.isdir("/sys/class/net/" + WIFI):
        why = ("The Pi's Wi-Fi chip isn't showing up at all, so its driver didn't start. "
               "Turning the Pi off and on again usually brings it back.")
    elif wifi_blocked() == "hard":
        why = "The Wi-Fi is switched off by a hardware switch (rfkill)."
    elif wifi_blocked() == "soft":
        why = "The Wi-Fi was switched off (rfkill). TideView is switching it back on."
    else:
        code, out = _nm("-t", "-f", "WIFI", "general")
        if code == 0 and out.strip() == "disabled":
            why = "The Wi-Fi was turned off in NetworkManager. TideView is turning it back on."
        else:
            code, out = _nm("-t", "-f", "DEVICE,STATE", "device")
            state = dict((p[0], p[1]) for p in _nm_fields(out) if len(p) > 1).get(WIFI, "") if code == 0 else ""
            if state.startswith("unavailable"):
                why = "The Pi's Wi-Fi chip isn't responding (NetworkManager calls it unavailable)."
            else:
                why = _which_network()
    if power_dipped():
        why += " The Pi has also reported its power dipping since it started, which can stop Wi-Fi and USB."
    return why


def _which_network():
    code, out = _nm("-t", "-f", "NAME,TYPE", "connection", "show")
    names = [p[0] for p in _nm_fields(out) if len(p) > 1 and p[1] in ("802-11-wireless", "wifi")] if code == 0 else []
    ssids = []
    for name in names[:4]:
        c, o = _nm("-g", "802-11-wireless.ssid", "connection", "show", name)
        if c == 0 and o.strip():
            ssids.append(o.strip())
    code, out = _nm("-t", "-f", "SSID,SIGNAL", "device", "wifi", "list", "--rescan", "yes", timeout=40)
    seen = {}
    if code == 0:
        for p in _nm_fields(out):
            if len(p) > 1 and p[0]:
                try:
                    seen[p[0]] = max(seen.get(p[0], 0), int(p[1] or 0))
                except ValueError:
                    pass
    if not ssids:
        return "The Pi doesn't have a Wi-Fi network saved."
    if code != 0:
        return "The Pi couldn't scan for Wi-Fi networks."
    known = [x for x in ssids if x in seen]
    if not known:
        if not seen:
            return "The Pi can't see any Wi-Fi networks at all, not even neighbours'. Its aerial may be blocked (metal close by) or its Wi-Fi chip has stopped."
        return "The Pi can see %d Wi-Fi networks but not %s. It may be too far from the router, or %s is 5 GHz only." % (
            len(seen), " or ".join('"%s"' % x for x in ssids), "that network")
    best = max(known, key=lambda x: seen[x])
    sig = seen[best]
    if sig < 25:
        return '"%s" is very weak here (%d%%). Move the Pi or the router closer.' % (best, sig)
    return '"%s" is there (%d%%) but won\'t connect. If its password changed, the Pi needs the new one.' % (best, sig)


def _settings_busy():
    try:
        from . import wifi
        return wifi.busy()
    except Exception:  # noqa: BLE001
        return False


def clock_synced():
    """True once the clock has been set from the internet since start-up,
    False if not, None if it can't tell."""
    if os.path.exists("/run/systemd/timesync/synchronized"):
        return True
    if not shutil.which("timedatectl"):
        return None
    code, out = _run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"], timeout=10)
    if code != 0:
        return None
    return out.strip().lower() == "yes"


class NetWatch:
    def __init__(self, fix=None):
        self.fix = _on_a_pi() if fix is None else fix
        self.online = None  # None until the first check
        self.offline_since = None  # time.monotonic()
        self.clock_ok = None
        self.last_fix = None
        self.diagnosis = None
        self._diagnosed_at = -1e9
        self._done = set()
        self._restarted_at = -1e9
        self._stop = threading.Event()
        self._poke = threading.Event()
        self._thread = None

    def start(self):
        if os.name != "posix":
            return
        self._thread = threading.Thread(target=self._loop, name="wifi-watch", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._poke.set()

    def poke(self):
        """Check again now (the Wi-Fi settings just changed something)."""
        self._poke.set()

    def _loop(self):
        if self.fix:
            _run(["iw", "dev", WIFI, "set", "power_save", "off"], timeout=10)
        wait = FIRST_CHECK
        while True:
            self._poke.wait(wait)
            self._poke.clear()
            if self._stop.is_set():
                return
            wait = CHECK_EVERY
            try:
                self.check(time.monotonic())
            except Exception:  # noqa: BLE001
                log.exception("Wi-Fi check failed")

    def check(self, mono):
        ip = system.ip_address()
        gw = gateway()
        ok = bool(ip) and not ip.startswith("127.") and (gw is None or router_answers(gw))
        self.clock_ok = clock_synced()
        if ok:
            if self.online is False and self.offline_since is not None:
                log.info("back online after %d s offline", mono - self.offline_since)
            self.online = True
            self.offline_since = None
            self.diagnosis = None
            self._done.clear()
            return
        if self.online is not False or self.offline_since is None:
            self.offline_since = mono
            log.warning("offline: %s", "no address" if not ip else "the router doesn't answer")
        self.online = False
        if self.fix and mono - self._diagnosed_at >= DIAGNOSE_EVERY:
            self._diagnosed_at = mono
            try:
                self.diagnosis = diagnose()
                log.info("why there's no Wi-Fi: %s", self.diagnosis)
            except Exception:  # noqa: BLE001
                log.exception("couldn't work out why there's no Wi-Fi")
        if not self.fix or _settings_busy():
            return  # (someone is choosing a network in Settings > Wi-Fi: leave it be)
        gone = mono - self.offline_since
        for after, step in STEPS:
            if gone >= after and step not in self._done:
                self._done.add(step)
                self._repair(step, mono)
                return
        if "restart" in self._done and mono - self._restarted_at >= RESTART_AGAIN:
            self._repair("restart", mono)

    def _repair(self, step, mono):
        nm = bool(shutil.which("nmcli"))
        cmds = []
        if step == "unblock":
            # Never switch the Wi-Fi off: only back on, if something left it off.
            if wifi_blocked() == "soft" and shutil.which("rfkill"):
                cmds.append(["rfkill", "unblock", "wifi"])
            if nm:
                code, out = _nm("-t", "-f", "WIFI", "general")
                if code == 0 and out.strip() == "disabled":
                    cmds.append(["nmcli", "radio", "wifi", "on"])
        elif step == "reconnect":
            cmds = [["nmcli", "device", "connect", WIFI]] if nm else [["wpa_cli", "-i", WIFI, "reconnect"]]
        else:
            self._restarted_at = mono
            if not os.path.isdir("/sys/class/net/" + WIFI) and shutil.which("modprobe"):
                # The Wi-Fi chip didn't come up: load its driver again.
                cmds += [["modprobe", "-r", "brcmfmac"], ["sleep", "2"], ["modprobe", "brcmfmac"], ["sleep", "5"]]
            cmds.append(["systemctl", "restart", "NetworkManager" if nm else "dhcpcd"])
        for cmd in cmds:
            code, out = _run(cmd, timeout=90)
            log.info("Wi-Fi fix (%s): %s -> %s %s", step, " ".join(cmd), code, out[:200])
        if step == "restart":
            _run(["iw", "dev", WIFI, "set", "power_save", "off"], timeout=10)
        self.last_fix = (step, time.time())

    def status_text(self, mono=None):
        """A line for the screen when the Pi is offline, else None."""
        mono = time.monotonic() if mono is None else mono
        if self.online is not False or self.offline_since is None or mono - self.offline_since < SAY_AFTER:
            return None
        if self.clock_ok is False:
            return "No Wi-Fi since the Pi started, so the clock may be wrong."
        return "No Wi-Fi. Showing the last forecast."

    def offline_for(self, mono=None):
        """Seconds offline, or 0 when online or not known yet."""
        if self.online is not False or self.offline_since is None:
            return 0
        return (time.monotonic() if mono is None else mono) - self.offline_since
