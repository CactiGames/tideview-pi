"""A plain-text report for working out problems: the Wi-Fi, power, touch
screen, updates and recent logs.

It's saved to the SD card's boot partition, the part any PC can open, as
tideview/report.txt (the one before is kept as report-previous.txt), or shown
on a phone. TideView saves one by itself after 5 minutes without Wi-Fi, and
again when the Wi-Fi comes back. Wi-Fi passwords, API keys and the phone code
are hidden.

Building it runs a dozen commands, which takes a few seconds on a Pi Zero,
so it's always done on a thread of its own.
"""

import json
import logging
import os
import platform
import re
import shutil
import threading
import time

from . import settings as settings_mod
from . import system, updates
from .netwatch import WIFI, _nm_fields, _run
from .version import VERSION

log = logging.getLogger("tideview.report")

NAME = "report.txt"
PREVIOUS = "report-previous.txt"
LOG_FILE = "tideview.log"
MAX_BYTES = 400 * 1024
AUTO_LIMIT = 4  # reports TideView saves by itself per start, to spare the SD card

_saving = threading.Lock()
_building = threading.Lock()
last = {"at": None, "path": None, "error": None, "reason": None}


def boot_dir():
    """The SD card's boot partition, or None (not on a Pi)."""
    for d in settings_mod.BOOT_DIRS:
        if os.path.isfile(os.path.join(d, "config.txt")) or os.path.isfile(os.path.join(d, "cmdline.txt")):
            return d
    return None


def log_path():
    return os.path.join(settings_mod.state_dir(), LOG_FILE)


def _duration(seconds):
    seconds = int(max(0, seconds))
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m = rem // 60
    if d:
        return "%d d %d h" % (d, h)
    if h:
        return "%d h %d min" % (h, m)
    return "%d min" % m


def gather(app, reason):
    """What the report needs from the app. Quick: call it on the main
    thread. The slow part is build()."""
    info = {"reason": reason, "made": time.time(), "version": VERSION,
            "running_for": time.monotonic() - getattr(app, "_started", time.monotonic())}
    try:
        info["settings"] = dict(app.settings._data)
    except Exception:  # noqa: BLE001
        info["settings"] = {}
    keys = getattr(app, "keys", {}) or {}
    info["keys"] = {k: bool(v) for k, v in keys.items()}
    hide = [v for v in keys.values() if v]
    try:
        info["touch"] = app.touch_names()
        info["touch_drops"] = getattr(app.touch, "dropouts", 0) if app.touch is not None else None
    except Exception:  # noqa: BLE001
        info["touch"] = []
    net = getattr(app, "net", None)
    if net is not None:
        info["net"] = {"online": net.online, "offline_for": net.offline_for(), "diagnosis": net.diagnosis,
                       "clock_ok": net.clock_ok, "last_fix": net.last_fix}
    rc = getattr(app, "remote", None)
    if rc is not None:
        hide += [rc.pairing.code, "%s-%s" % (rc.pairing.code[:4], rc.pairing.code[4:])]
        info["remote"] = {"running": rc.running(), "port": rc.port, "error": rc.error,
                          "phones": len(rc.pairing.phones), "address": rc.web_address()}
    wifi = getattr(app, "wifi", None)
    if wifi is not None:
        try:
            info["wifi"] = wifi.snapshot()
        except Exception:  # noqa: BLE001
            pass
    fc = getattr(app, "forecast", None)
    if fc is not None:
        f = fc.forecast
        info["forecast"] = {"beach": getattr(fc.beach, "id", ""), "loading": fc.loading,
                            "error": str(fc.error) if fc.error else None,
                            "fetched_at": f.fetched_at if f is not None else None,
                            "next": fc.next_update}
    info["hide"] = [h for h in hide if h and len(h) >= 4]
    return info


def _section(out, title):
    out.append("")
    out.append("== %s ==" % title)


def _cmd(out, cmd, run, timeout=20, lines=None, title=None):
    if not shutil.which(cmd[0]):
        return
    code, text = run(cmd, timeout=timeout)
    out.append("$ %s%s" % (title or " ".join(cmd), "" if code == 0 else "   (exit %s)" % code))
    body = text.splitlines()
    if lines and len(body) > lines:
        body = ["... (%d earlier lines left out)" % (len(body) - lines)] + body[-lines:]
    out.extend("  " + x for x in body)


def _read(path, limit=4000):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except OSError:
        return None


def _tail(path, lines):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().splitlines()[-lines:]
    except OSError:
        return []


def _wifi_secrets(run):
    """The saved Wi-Fi passwords, so they can be blanked out of the report."""
    found = []
    if not shutil.which("nmcli"):
        return found
    code, text = run(["nmcli", "-t", "-f", "UUID,TYPE", "connection", "show"], timeout=15)
    if code != 0:
        return found
    for p in _nm_fields(text):
        if len(p) >= 2 and p[1] in ("802-11-wireless", "wifi"):
            c, o = run(["nmcli", "-s", "-g", "802-11-wireless-security.psk", "connection", "show", "uuid", p[0]],
                       timeout=15)
            if c == 0 and o.strip():
                found.append(_nm_fields(o.strip())[0][0])
    return found


def hide_secrets(text, secrets):
    for s in sorted(set(x for x in secrets if x and len(x) >= 4), key=len, reverse=True):
        text = text.replace(s, "[hidden]")
    # Anything that looks like a password or key in a config line.
    return re.sub(r"(?im)\b(psk|password|passphrase|wep-key\d|secret|api[_-]?key)(\s*[:=]\s*)(\S+)",
                  r"\1\2[hidden]", text)


def build(info, run=_run):
    """The report as text. Slow (runs commands): not on the main thread."""
    out = []
    made = info["made"]
    lt = time.localtime(made)
    out.append("TideView report")
    out.append("Made %s (%s UTC)" % (time.strftime("%Y-%m-%d %H:%M:%S %Z", lt),
                                      time.strftime("%H:%M:%S", time.gmtime(made))))
    net = info.get("net") or {}
    if net.get("clock_ok") is False:
        out.append("The clock hasn't been set from the internet since the Pi started, so that time may be wrong.")
    out.append("Why: %s" % info.get("reason", ""))
    up = system.uptime_hours()
    out.append("TideView %s, running %s. Pi up %s." % (
        info.get("version"), _duration(info.get("running_for", 0)), _duration(up * 3600) if up is not None else "?"))
    model = (_read("/proc/device-tree/model") or "").strip("\x00\n ")
    osname = ""
    rel = _read("/etc/os-release") or ""
    m = re.search(r'^PRETTY_NAME="?([^"\n]*)', rel, re.M)
    if m:
        osname = m.group(1)
    out.append("%s · %s · kernel %s · Python %s" % (model or platform.machine(), osname or platform.system(),
                                                     platform.release(), platform.python_version()))

    _section(out, "Wi-Fi")
    if net:
        if net.get("online"):
            out.append("Online.")
        elif net.get("online") is False:
            out.append("OFFLINE for %s." % _duration(net.get("offline_for") or 0))
        if net.get("diagnosis"):
            out.append("Why: %s" % net["diagnosis"])
        if net.get("last_fix"):
            step, at = net["last_fix"]
            out.append("Last thing TideView tried: %s at %s." % (step, time.strftime("%H:%M:%S", time.localtime(at))))
    wifi = info.get("wifi") or {}
    if wifi.get("status"):
        out.append("Status: %s" % json.dumps(wifi["status"]))
    if wifi.get("result"):
        r = wifi["result"]
        out.append("Last join from Settings: %s, %s (%s)" % (
            r.get("ssid"), "worked" if r.get("ok") else "failed", r.get("message")))
    _cmd(out, ["nmcli", "general"], run)
    _cmd(out, ["nmcli", "device"], run)
    _cmd(out, ["nmcli", "-f", "NAME,TYPE,DEVICE,AUTOCONNECT,AUTOCONNECT-PRIORITY,TIMESTAMP-REAL", "connection", "show"],
         run)
    _cmd(out, ["nmcli", "-f", "IN-USE,SSID,SIGNAL,SECURITY,CHAN,FREQ", "device", "wifi", "list", "--rescan", "no"], run,
         lines=40)
    _cmd(out, ["ip", "-br", "addr"], run)
    _cmd(out, ["ip", "route"], run)
    _cmd(out, ["iw", "dev", WIFI, "link"], run)
    _cmd(out, ["iw", "dev", WIFI, "get", "power_save"], run)
    _cmd(out, ["iw", "reg", "get"], run, lines=12)
    rf = []
    try:
        for name in sorted(os.listdir("/sys/class/rfkill")):
            d = os.path.join("/sys/class/rfkill", name)
            rf.append("%s %s soft=%s hard=%s" % (name, (_read(os.path.join(d, "type")) or "").strip(),
                                                 (_read(os.path.join(d, "soft")) or "").strip(),
                                                 (_read(os.path.join(d, "hard")) or "").strip()))
    except OSError:
        pass
    if rf:
        out.append("rfkill: " + "; ".join(rf))

    _section(out, "Power and heat")
    out.append(system.power_problems() or "Not known.")
    t = system.cpu_temperature()
    if t is not None:
        out.append("Processor %.1f°C." % t)
    _cmd(out, ["vcgencmd", "get_throttled"], run)
    _cmd(out, ["vcgencmd", "measure_volts"], run)

    _section(out, "Touch screen")
    out.append(", ".join(info.get("touch") or []) or "None found.")
    if info.get("touch_drops"):
        out.append("Dropped out %d times since TideView started." % info["touch_drops"])

    _section(out, "Forecast")
    fc = info.get("forecast") or {}
    if fc:
        fetched = fc.get("fetched_at")
        out.append("Beach %s. Last update %s.%s%s" % (
            fc.get("beach"), time.strftime("%Y-%m-%d %H:%M", time.localtime(fetched)) if fetched else "never",
            " Updating now." if fc.get("loading") else "", (" Last error: %s" % fc["error"]) if fc.get("error") else ""))
    out.append("Keys: %s" % ", ".join("%s %s" % (k, "found" if v else "missing") for k, v in info.get("keys", {}).items()))

    _section(out, "Updates")
    try:
        out.append(json.dumps(updates.read_state(), indent=1, sort_keys=True))
    except Exception as e:  # noqa: BLE001
        out.append("Couldn't read: %s" % e)
    rel_dir = "/opt/tideview/releases"
    if os.path.isdir(rel_dir):
        try:
            out.append("Releases on the Pi: %s" % ", ".join(sorted(os.listdir(rel_dir))))
            for link in ("current", "previous"):
                p = os.path.join("/opt/tideview", link)
                if os.path.islink(p):
                    out.append("%s -> %s" % (link, os.readlink(p)))
        except OSError:
            pass

    _section(out, "Phone control")
    rc = info.get("remote")
    if rc:
        out.append("Running: %s, port %s, address %s, %d phone(s) linked.%s" % (
            rc.get("running"), rc.get("port"), rc.get("address"), rc.get("phones", 0),
            (" Problem: %s" % rc["error"]) if rc.get("error") else ""))

    _section(out, "Settings")
    out.append(json.dumps(info.get("settings", {}), sort_keys=True))

    _section(out, "Disk")
    _cmd(out, ["df", "-h", "/", "/boot/firmware" if os.path.isdir("/boot/firmware") else "/boot"], run)

    _section(out, "TideView's own log (kept across restarts)")
    lines = _tail(log_path() + ".1", 150) + _tail(log_path(), 350)
    out.extend(lines[-400:] or ["(empty)"])

    if shutil.which("journalctl"):
        _section(out, "Start-ups the journal remembers")
        _cmd(out, ["journalctl", "--list-boots", "--no-pager"], run, lines=8)
        for title, args, n in (("TideView, this start-up", ["-u", "tideview"], 150),
                               ("Updates, this start-up", ["-u", "tideview-update"], 40),
                               ("NetworkManager, this start-up", ["-u", "NetworkManager"], 150),
                               ("wpa_supplicant, this start-up", ["-u", "wpa_supplicant"], 60),
                               ("Kernel, this start-up", ["-k"], 200),
                               ("Errors from anything, this start-up", ["-p", "err"], 80)):
            _section(out, title)
            _cmd(out, ["journalctl", "-b", "--no-pager", "-o", "short-iso", "-n", str(n)] + args, run, timeout=40,
                 lines=n)
        _section(out, "The start-up before, if the journal kept it")
        _cmd(out, ["journalctl", "-b", "-1", "--no-pager", "-o", "short-iso", "-n", "120",
                   "-u", "NetworkManager", "-u", "tideview", "-k"], run, timeout=40, lines=120)
    else:
        _section(out, "Kernel messages")
        _cmd(out, ["dmesg"], run, lines=200)

    text = "\n".join(out) + "\n"
    text = hide_secrets(text, list(info.get("hide", [])) + _wifi_secrets(run))
    if len(text) > MAX_BYTES:
        text = text[:MAX_BYTES] + "\n... (cut short)\n"
    return text


def save(text):
    """Writes the report to the boot partition. Returns its path."""
    d = boot_dir()
    if d is None:
        raise OSError("this isn't a Raspberry Pi with an SD card")
    folder = os.path.join(d, "tideview")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, NAME)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f:  # Windows line ends, for Notepad
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    if os.path.exists(path):
        os.replace(path, os.path.join(folder, PREVIOUS))
    os.replace(tmp, path)
    try:
        fd = os.open(folder, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass
    return path


def save_soon(app, reason, quiet=False):
    """Builds and saves a report on a thread of its own. Shows a message
    when it's done unless quiet. False if one is being saved already."""
    if _saving.locked():
        return False
    info = gather(app, reason)

    def tell(text, seconds):
        if not quiet:
            app.post(lambda: app.show_message(text, seconds))

    def run():
        if not _saving.acquire(blocking=False):
            return
        try:
            path = save(build(info))
            last.update(at=time.time(), path=path, error=None, reason=reason)
            log.info("saved a report to %s (%s)", path, reason)
            tell("Saved a report to the SD card, in the tideview folder (report.txt). A PC can open it.", 10)
        except Exception as e:  # noqa: BLE001
            last.update(error=str(e), reason=reason)
            log.warning("couldn't save a report: %s", e)
            tell("Couldn't save the report: %s" % e, 10)
        finally:
            _saving.release()
            app.post(app.display.invalidate)
    threading.Thread(target=run, name="report", daemon=True).start()
    return True


def build_for_phone(app):
    """The report text for a phone (from a server thread). None if another
    phone is building one right now."""
    if not _building.acquire(blocking=False):
        return None
    try:
        info = app.call_soon(lambda: gather(app, "Asked for from a phone"))
        return build(info)
    finally:
        _building.release()


def status_text(clock):
    """For Settings: when the last report was saved."""
    if _saving.locked():
        return "Saving one now..."
    if last["error"]:
        return "The last try failed: %s" % last["error"]
    if last["at"]:
        return "Last saved at %s (%s)." % (clock(last["at"]), (last["reason"] or "").lower())
    return ""
