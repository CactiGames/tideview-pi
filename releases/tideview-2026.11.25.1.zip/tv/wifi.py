"""Wi-Fi settings: the networks the Pi can see, and joining one.

Uses NetworkManager (nmcli), which Raspberry Pi OS Bookworm and Trixie use.
A scan or a join takes seconds, so WifiManager runs them on a thread of its
own and the screens show how it's going. The touch screen and phones share
the one WifiManager on the App.

Joining never changes or removes a network that was already saved (like the
one from the Imager). A network joined here gets a profile of its own,
"TideView <name>", which is tried before the others. A new profile is only
kept once it has connected; if it can't connect it's removed again and the
Pi goes back to the network it was on. Passwords are never logged.
"""

import logging
import os
import re
import shutil
import threading
import time

from .netwatch import WIFI, _nm_fields, _run

log = logging.getLogger("tideview.wifi")

PREFIX = "TideView "
TRYING = " (trying)"
PRIORITY = 50  # NetworkManager tries higher first; profiles default to 0
JOIN_WAIT = 45  # seconds for NetworkManager to connect
MAX_NETWORKS = 30

_busy = threading.Lock()  # one scan or join at a time; the Wi-Fi watch waits for it too
_last_join = [-1e9]


def busy():
    """True while a scan or join is running, and for a minute after a join
    (so the Wi-Fi watch doesn't get in its way)."""
    return _busy.locked() or time.monotonic() - _last_join[0] < 60


def check_password(text, required=True):
    """'' if text will do as a Wi-Fi password, else what's wrong with it."""
    if not text and not required:
        return ""
    if re.fullmatch(r"[0-9a-fA-F]{64}", text or ""):
        return ""
    if not 8 <= len(text or "") <= 63:
        return "Wi-Fi passwords have 8 to 63 characters."
    if any(ord(ch) < 32 or ord(ch) > 126 for ch in text):
        return "That has a character Wi-Fi passwords can't have."
    return ""


def check_name(text):
    if not text.strip():
        return "Type the network's name."
    if len(text.encode("utf-8")) > 32:
        return "Wi-Fi network names have at most 32 characters."
    return ""


def key_mgmt(security):
    """NetworkManager's key-mgmt for a scan's SECURITY text: None for an open
    network, 'wpa-psk' or 'sae', or '' if TideView can't join it."""
    sec = (security or "").replace("--", "").strip()
    if not sec:
        return None
    if "802.1X" in sec or "EAP" in sec:
        return ""
    if "WPA1" in sec or "WPA2" in sec or sec == "WPA":
        return "wpa-psk"
    if "WPA3" in sec or "SAE" in sec:
        return "sae"
    if "WEP" in sec:
        return ""
    return "wpa-psk"


class Network:
    __slots__ = ("ssid", "signal", "security", "freq", "saved", "active")

    def __init__(self, ssid, signal=0, security="", freq=0, saved=False, active=False):
        self.ssid = ssid
        self.signal = int(signal or 0)
        self.security = security or ""
        self.freq = int(freq or 0)
        self.saved = saved
        self.active = active

    @property
    def secure(self):
        return key_mgmt(self.security) is not None

    @property
    def band(self):
        if not self.freq:
            return ""
        return "5 GHz" if self.freq >= 4900 else "2.4 GHz"

    def sub(self):
        parts = ["Signal %d%%" % self.signal]
        mgmt = key_mgmt(self.security)
        if mgmt == "":
            parts.append("needs a username, so TideView can't join it")
        else:
            parts.append("password" if self.secure else "open, no password")
        if self.band:
            parts.append(self.band)
        if self.saved and not self.active:
            parts.append("saved")
        return " · ".join(parts)

    def to_json(self):
        return {"ssid": self.ssid, "signal": self.signal, "secure": self.secure, "saved": self.saved,
                "active": self.active, "band": self.band, "sub": self.sub(),
                "joinable": key_mgmt(self.security) != ""}


class NmWifi:
    """The real thing, through nmcli."""

    _available = None

    def available(self):
        if self._available is None:  # (asked on every frame the No Wi-Fi card shows)
            self._available = (shutil.which("nmcli") is not None and hasattr(os, "geteuid") and os.geteuid() == 0)
        return self._available

    def _nm(self, *args, timeout=20):
        return _run(["nmcli"] + list(args), timeout=timeout)

    def status(self):
        """{'ssid', 'signal', 'address', 'state'} for wlan0 (values may be None)."""
        out = {"ssid": None, "signal": None, "address": None, "state": None}
        code, text = self._nm("-t", "-f", "GENERAL.STATE,IP4.ADDRESS", "device", "show", WIFI)
        if code == 0:
            for line in text.splitlines():
                key, _, value = line.partition(":")
                if key == "GENERAL.STATE":
                    out["state"] = re.sub(r"^\d+\s*", "", value).strip("() ") or None
                elif key.startswith("IP4.ADDRESS") and value and not out["address"]:
                    out["address"] = value.split("/")[0]
        code, text = self._nm("-t", "-f", "IN-USE,SSID,SIGNAL", "device", "wifi", "list", "--rescan", "no",
                              "ifname", WIFI)
        if code == 0:
            for p in _nm_fields(text):
                if len(p) >= 3 and p[0].strip() == "*":
                    out["ssid"] = p[1] or None
                    out["signal"] = _int(p[2])
                    break
        return out

    def profiles(self):
        """Saved Wi-Fi profiles: [{'uuid', 'name', 'ssid', 'ours'}]."""
        code, text = self._nm("-t", "-f", "NAME,UUID,TYPE", "connection", "show")
        found = []
        if code != 0:
            return found
        for p in _nm_fields(text):
            if len(p) >= 3 and p[2] in ("802-11-wireless", "wifi"):
                c, o = self._nm("-g", "802-11-wireless.ssid", "connection", "show", "uuid", p[1])
                ssid = _nm_fields(o)[0][0] if (c == 0 and o) else ""
                found.append({"name": p[0], "uuid": p[1], "ssid": ssid, "ours": p[0].startswith(PREFIX)})
        return found

    def _active_uuid(self):
        code, text = self._nm("-t", "-f", "UUID,TYPE,DEVICE", "connection", "show", "--active")
        if code == 0:
            for p in _nm_fields(text):
                if len(p) >= 3 and p[2] == WIFI:
                    return p[0]
        return None

    def scan(self, rescan=True):
        with _busy:
            return self._scan(rescan)

    def _scan(self, rescan):
        args = ["-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY,FREQ", "device", "wifi", "list", "--rescan",
                "yes" if rescan else "no", "ifname", WIFI]
        code, text = self._nm(*args, timeout=45)
        if code != 0 and rescan:  # "scanning not allowed" right after another scan: use what it has
            code, text = self._nm(*args[:-3] + ["no", "ifname", WIFI], timeout=20)
        if code != 0:
            raise RuntimeError(_last_line(text) or "nmcli couldn't scan")
        saved = set(p["ssid"] for p in self.profiles())
        best = {}
        for p in _nm_fields(text):
            if len(p) < 5 or not p[1]:
                continue  # hidden networks have no name
            n = Network(p[1], _int(p[2]), p[3], _int(p[4].split()[0] if p[4] else 0), p[1] in saved,
                        p[0].strip() == "*")
            old = best.get(n.ssid)
            if old is None:
                best[n.ssid] = n
            else:
                old.active = old.active or n.active
                if n.signal > old.signal:
                    old.signal, old.freq, old.security = n.signal, n.freq, n.security
        nets = sorted(best.values(), key=lambda n: (not n.active, not n.saved, -n.signal, n.ssid.lower()))
        return nets[:MAX_NETWORKS]

    def _up(self, uuid):
        code, text = _run(["nmcli", "--wait", str(JOIN_WAIT), "connection", "up", "uuid", uuid],
                          timeout=JOIN_WAIT + 20)
        return code == 0, text

    def join(self, ssid, password=None, hidden=False, security=None):
        """Returns (ok, message, needs_password)."""
        with _busy:
            try:
                return self._join(ssid, password, hidden, security)
            finally:
                _last_join[0] = time.monotonic()

    def _join(self, ssid, password, hidden, security):
        profiles = self.profiles()
        before = self._active_uuid()
        mine = [p for p in profiles if p["ssid"] == ssid]
        if password is None and mine and not hidden:
            log.info("joining %s with its saved profile", ssid)
            for p in sorted(mine, key=lambda p: not p["ours"]):
                ok, text = self._up(p["uuid"])
                if ok:
                    return True, "Connected to %s." % ssid, False
                log.info("couldn't join %s with %s: %s", ssid, p["name"], _last_line(text))
            self._back_to(before)
            return False, "%s didn't take its saved password. Tap it again to type the password." % ssid, True

        mgmt = ("wpa-psk" if password else None) if (hidden or security is None) else key_mgmt(security)
        if mgmt == "":
            return False, "%s needs a username as well as a password, which TideView can't do." % ssid, False
        if mgmt and not password:
            return False, "%s needs its password." % ssid, True
        if password:
            problem = check_password(password)
            if problem:
                return False, problem, True
        trying = PREFIX + ssid + TRYING
        for p in profiles:  # a leftover from a join that was cut off
            if p["name"] == trying:
                self._nm("connection", "delete", "uuid", p["uuid"])
        cmd = ["nmcli", "connection", "add", "type", "wifi", "ifname", WIFI, "con-name", trying,
               "ssid", ssid, "connection.autoconnect", "yes",
               "connection.autoconnect-priority", str(PRIORITY)]
        if hidden:
            cmd += ["802-11-wireless.hidden", "yes"]
        if mgmt:
            cmd += ["wifi-sec.key-mgmt", mgmt, "wifi-sec.psk", password]
        code, text = _run(cmd, timeout=30)
        if password:
            text = text.replace(password, "[password]")
        uuid = _uuid(text)
        if code != 0 or not uuid:
            log.warning("couldn't add a profile for %s: %s", ssid, _last_line(text))
            return False, "Couldn't save %s: %s" % (ssid, _last_line(text) or "nmcli failed"), False
        log.info("joining %s (%s)", ssid, "hidden" if hidden else (mgmt or "open"))
        ok, text = self._up(uuid)
        if ok:
            for p in mine:
                if p["ours"]:  # the old TideView profile for this network
                    self._nm("connection", "delete", "uuid", p["uuid"])
            self._nm("connection", "modify", "uuid", uuid, "connection.id", PREFIX + ssid)
            log.info("joined %s", ssid)
            return True, "Connected to %s." % ssid, False
        why = _last_line(text)
        log.info("couldn't join %s: %s", ssid, why)
        self._nm("connection", "delete", "uuid", uuid)
        self._back_to(before)
        return (False,) + _explain(why, ssid)

    def _back_to(self, before):
        if before and self._active_uuid() is None:
            log.info("going back to the network the Pi was on")
            self._up(before)


def _explain(why, ssid):
    """(message, needs_password) for nmcli's error text."""
    low = (why or "").lower()
    if "secrets were required" in low or "psk" in low or "password" in low or "802.1x" in low:
        return "%s didn't accept that password. Check it and try again." % ssid, True
    if "could not be found" in low or "no network with ssid" in low or "not found" in low:
        return "The Pi can't find %s right now. It may be out of range, or 5 GHz only." % ssid, False
    if "ip configuration" in low or "dhcp" in low:
        return "Joined %s, but the router didn't give the Pi an address. Try again in a minute." % ssid, False
    if "timeout" in low or "timed out" in low:
        return "%s didn't answer in time. The Pi may be too far from the router." % ssid, False
    return "Couldn't join %s: %s" % (ssid, why or "no reason given"), False


def _int(text):
    try:
        return int(str(text).strip() or 0)
    except ValueError:
        return 0


def _uuid(text):
    m = re.search(r"\(([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\)", text or "")
    return m.group(1) if m else None


def _last_line(text):
    """nmcli's error, without its "Error:" and the "Hint:" line it adds."""
    lines = [x.strip() for x in (text or "").splitlines() if x.strip() and not x.strip().startswith("Hint:")]
    errors = [x for x in lines if x.startswith("Error:")]
    line = (errors or lines or [""])[-1]
    return re.sub(r"^Error:\s*", "", line)[:200]


class FakeWifi:
    """Stands in for NetworkManager in the tests, the screenshots and the
    self-test: a few networks, and one password that works."""

    PASSWORD = "correct horse"

    def __init__(self, networks=None, delay=0.0):
        self.delay = delay
        self.nets = networks if networks is not None else [
            Network("Blackmore 2.4", 71, "WPA2", 2437, saved=True, active=True),
            Network("Blackmore 5G", 64, "WPA2 WPA3", 5180),
            Network("Neighbours Wi-Fi", 48, "WPA2", 2462),
            Network("Cafe Guest", 30, "", 2412),
            Network("Work Laptop", 22, "WPA2 802.1X", 2437),
        ]
        self.joins = []

    def available(self):
        return True

    def status(self):
        a = next((n for n in self.nets if n.active), None)
        return {"ssid": a.ssid if a else None, "signal": a.signal if a else None,
                "address": "10.1.97.19" if a else None, "state": "connected" if a else "disconnected"}

    def scan(self, rescan=True):
        if self.delay:
            time.sleep(self.delay)
        return sorted([Network(n.ssid, n.signal, n.security, n.freq, n.saved, n.active) for n in self.nets],
                      key=lambda n: (not n.active, not n.saved, -n.signal))

    def join(self, ssid, password=None, hidden=False, security=None):
        self.joins.append((ssid, password, hidden))
        if self.delay:
            time.sleep(self.delay)
        n = next((x for x in self.nets if x.ssid == ssid), None)
        if n is None and not hidden:
            return False, "The Pi can't find %s right now. It may be out of range, or 5 GHz only." % ssid, False
        if n is not None and key_mgmt(n.security) == "":
            return False, "%s needs a username as well as a password, which TideView can't do." % ssid, False
        if n is not None and n.secure and password is None and not n.saved:
            return False, "%s needs its password." % ssid, True
        if password is not None and password != self.PASSWORD:
            return False, "%s didn't accept that password. Check it and try again." % ssid, True
        if n is None:
            n = Network(ssid, 50, "WPA2" if password else "", 2437)
            self.nets.append(n)
        for x in self.nets:
            x.active = x is n
        n.saved = True
        return True, "Connected to %s." % ssid, False


class WifiManager:
    """Scans and joins on a thread of their own, and remembers how they went,
    for the touch screen and phones alike."""

    RESULT_SHOWS = 10 * 60  # seconds the last join's result stays on the Wi-Fi screen

    def __init__(self, backend=None, on_change=None):
        self.backend = backend if backend is not None else NmWifi()
        self.on_change = on_change
        self._lock = threading.Lock()
        self.networks = []
        self.scanned_at = 0.0
        self.scan_error = None
        self.scanning = False
        self.joining = None  # the network being joined
        self.result = None  # {'ok', 'ssid', 'message', 'needs_password', 'at'}
        self.status = {}
        self._status_at = -1e9
        self._status_running = False
        self.failed_saved = set()  # saved networks whose saved password didn't work

    def available(self):
        try:
            return self.backend.available()
        except Exception:  # noqa: BLE001
            return False

    def _changed(self):
        if self.on_change is not None:
            try:
                self.on_change()
            except Exception:  # noqa: BLE001
                log.exception("Wi-Fi change callback failed")

    def _thread(self, fn, *args):
        def run():
            try:
                fn(*args)
            except Exception:  # noqa: BLE001
                log.exception("Wi-Fi task failed")
            finally:
                self._changed()
        threading.Thread(target=run, name="wifi", daemon=True).start()

    # -- scanning ---------------------------------------------------------

    def scan(self):
        """Starts a scan. False if one is running (or a join)."""
        with self._lock:
            if self.scanning or self.joining:
                return False
            self.scanning = True
        self._changed()
        self._thread(self._scan)
        return True

    def _scan(self):
        try:
            nets = self.backend.scan()
            err = None
        except Exception as e:  # noqa: BLE001
            nets, err = None, str(e) or "the scan failed"
            log.warning("Wi-Fi scan failed: %s", err)
        st = self._read_status()
        with self._lock:
            if nets is not None:
                self.networks = nets
                self.scanned_at = time.time()
            self.scan_error = err
            if st is not None:
                self.status, self._status_at = st, time.monotonic()
            self.scanning = False

    def _read_status(self):
        try:
            return self.backend.status()
        except Exception:  # noqa: BLE001
            log.exception("couldn't read the Wi-Fi status")
            return None

    def refresh_status(self, max_age=20):
        """Checks the status in the background if the last check is older
        than max_age seconds. Doesn't wait."""
        with self._lock:
            if self._status_running or time.monotonic() - self._status_at < max_age:
                return
            self._status_running = True

        def run():
            st = self._read_status()
            with self._lock:
                self._status_running = False
                self._status_at = time.monotonic()
                if st is not None:
                    self.status = st
        self._thread(run)

    # -- joining ----------------------------------------------------------

    def network(self, ssid):
        with self._lock:
            return next((n for n in self.networks if n.ssid == ssid), None)

    def needs_password(self, ssid):
        """True if joining ssid should ask for a password first."""
        n = self.network(ssid)
        if n is None:
            return True
        if not n.secure:
            return False
        return not n.saved or ssid in self.failed_saved

    def join(self, ssid, password=None, hidden=False):
        """Starts joining a network. False if a join is already running."""
        n = self.network(ssid)
        security = n.security if n is not None else None
        with self._lock:
            if self.joining:
                return False
            self.joining = ssid
            self.result = None
        self._changed()
        self._thread(self._join, ssid, password, hidden, security)
        return True

    def _join(self, ssid, password, hidden, security):
        try:
            ok, message, ask = self.backend.join(ssid, password, hidden, security)
        except Exception as e:  # noqa: BLE001
            log.exception("joining %s failed", ssid)
            ok, message, ask = False, "Couldn't join %s: %s" % (ssid, e), False
        try:
            nets = self.backend.scan(rescan=False)
        except Exception:  # noqa: BLE001
            nets = None
        st = self._read_status()
        with self._lock:
            self.result = {"ok": ok, "ssid": ssid, "message": message, "needs_password": bool(ask),
                           "at": time.time()}
            if ok:
                self.failed_saved.discard(ssid)
            elif password is None and ask:
                self.failed_saved.add(ssid)
            if nets is not None:
                self.networks = nets
                self.scanned_at = time.time()
            if st is not None:
                self.status, self._status_at = st, time.monotonic()
            self.joining = None

    def recent_result(self, now=None):
        r = self.result
        if r is None or (now or time.time()) - r["at"] > self.RESULT_SHOWS:
            return None
        return r

    def snapshot(self):
        """Everything a phone's Wi-Fi page shows, as plain values."""
        with self._lock:
            return {"available": self.available(), "status": dict(self.status), "scanning": self.scanning,
                    "scanned_at": self.scanned_at or None, "scan_error": self.scan_error,
                    "joining": self.joining, "result": self.recent_result(),
                    "networks": [dict(n.to_json(), ask_password=(n.secure and (not n.saved or n.ssid in self.failed_saved)))
                                 for n in self.networks]}
