"""The TideView logo at power-on, instead of the Raspberry Pi's start-up text.

Three parts, all checked each time TideView starts on the Pi (as root, on
the framebuffer), and only written when something needs changing:

1. cmdline.txt sends the start-up text to a hidden console (tty3 instead of
   the screen's tty1) and keeps it quiet. The old line is kept as
   cmdline.txt.before-splash. Nothing else on the line is touched.
2. tideview-splash.service runs tvsplash.py very early in each start-up. It
   copies a picture of the splash screen straight onto the screen, a few
   seconds after power-on, long before TideView itself is ready.
3. That picture (splash.fb in the state folder) is saved from the splash
   screen TideView draws, so the hand-over looks seamless. It's raw pixels
   in the screen's own format, with a header saying which format.

Every step is careful: a problem is logged and skipped, never fatal.
"""

import hashlib
import json
import logging
import os
import threading

log = logging.getLogger("tideview.bootlook")

BOOT_DIRS = ("/boot/firmware", "/boot")
UNIT_DIR = "/etc/systemd/system"
UNIT_NAME = "tideview-splash.service"
SPLASH_MAGIC = b"TVSPLASH1\n"
SPLASH_DESIGN = 1  # bump when the splash screen's look changes
QUIET = ("quiet", "loglevel=3", "logo.nologo", "vt.global_cursor_default=0", "consoleblank=0",
         "systemd.show_status=false")

UNIT_TEXT = """\
# Written by TideView, which puts it back if it changes.
[Unit]
Description=TideView logo at power-on
DefaultDependencies=no
ConditionPathExists={splash}

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 -I -S {script}
TimeoutStartSec=45

[Install]
WantedBy=sysinit.target
"""


def boot_dir():
    for d in BOOT_DIRS:
        if os.path.isfile(os.path.join(d, "cmdline.txt")):
            return d
    return None


def quiet_cmdline(line):
    """cmdline.txt's line with the start-up text moved off the screen.
    Returns None if the line doesn't look like a Pi's (nothing changes)."""
    tokens = line.split()
    if not any(t.startswith("root=") for t in tokens):
        return None
    out = []
    for t in tokens:
        if t in ("console=tty1", "console=tty0"):
            t = "console=tty3"
        if t not in out:
            out.append(t)
    if not any(t.startswith("console=") for t in out):
        out.append("console=tty3")  # no console= at all would mean the screen
    for opt in QUIET:
        key = opt.split("=", 1)[0]
        if not any(t == opt or t.startswith(key + "=") for t in out):
            out.append(opt)
    return " ".join(out)


def _same_except_console(old, new):
    """The new line keeps every token of the old one (bar the console)."""
    a = [t for t in old.split() if t not in ("console=tty1", "console=tty0")]
    b = set(new.split())
    return all(t in b for t in a)


def _write(path, data, mode=0o644):
    tmp = path + ".tideview-tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def fix_cmdline(boot):
    path = os.path.join(boot, "cmdline.txt")
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except OSError:
        return False
    text = raw.decode("utf-8", "replace")
    lines = text.splitlines()
    if not lines or not lines[0].strip():
        return False
    old = lines[0].strip()
    new = quiet_cmdline(old)
    if new is None or new == old or "root=" not in new or not _same_except_console(old, new):
        return False
    backup = path + ".before-splash"
    if not os.path.exists(backup):
        _write(backup, raw)
    _write(path, (new + "\n").encode("utf-8"))
    log.info("start-up text moved off the screen (cmdline.txt; the old one is cmdline.txt.before-splash)")
    return True


def fix_config(boot):
    """No rainbow square at power-on (install.sh normally sees to this)."""
    path = os.path.join(boot, "config.txt")
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return False
    if any(line.strip().replace(" ", "") == "disable_splash=1" for line in text.splitlines()):
        return False
    text = text.rstrip("\n") + "\n\n# TideView: no rainbow square at power-on\n[all]\ndisable_splash=1\n"
    _write(path, text.encode("utf-8"))
    log.info("turned off the rainbow square at power-on (config.txt)")
    return True


def install_unit(script, splash):
    path = os.path.join(UNIT_DIR, UNIT_NAME)
    text = UNIT_TEXT.format(script=script, splash=splash).encode("utf-8")
    changed = False
    try:
        with open(path, "rb") as f:
            same = f.read() == text
    except OSError:
        same = False
    if not same:
        _write(path, text)
        changed = True
    wants = os.path.join(UNIT_DIR, "sysinit.target.wants")
    link = os.path.join(wants, UNIT_NAME)
    if not os.path.islink(link):
        os.makedirs(wants, exist_ok=True)
        if os.path.lexists(link):
            os.remove(link)
        os.symlink(path, link)
        changed = True
    if changed:
        log.info("the logo now shows at power-on (%s)", UNIT_NAME)
    return changed


def apply(app_dir, state_dir):
    """Steps 1 and 2 (step 3 is save_splash, from the App). app_dir is where
    TideView runs from: /opt/tideview/current on the Pi, a link that moves
    on with each update, so the unit never needs changing."""
    if os.name != "posix" or os.geteuid() != 0:
        return
    boot = boot_dir()
    if boot is None or not os.path.isdir(UNIT_DIR):
        return
    script = os.path.join(app_dir, "tvsplash.py")
    splash = os.path.join(state_dir, "splash.fb")
    for step in (lambda: fix_cmdline(boot), lambda: fix_config(boot), lambda: install_unit(script, splash)):
        try:
            step()
        except Exception:  # noqa: BLE001  (never stops TideView)
            log.exception("couldn't set up the logo at power-on")


def apply_soon(app_dir, state_dir):
    t = threading.Thread(target=apply, args=(app_dir, state_dir), name="bootlook", daemon=True)
    t.start()
    return t


# -- the picture ------------------------------------------------------------

def splash_header(xres, yres, bpp, pitch, stride, signature):
    return SPLASH_MAGIC + json.dumps({"w": xres, "h": yres, "bpp": bpp, "pitch": pitch, "stride": stride,
                                      "sig": signature}).encode("ascii") + b"\n"


def read_header(path):
    try:
        with open(path, "rb") as f:
            if f.read(len(SPLASH_MAGIC)) != SPLASH_MAGIC:
                return None
            return json.loads(f.readline().decode("ascii"))
    except (OSError, ValueError):
        return None


def splash_signature(output, extra):
    text = json.dumps([SPLASH_DESIGN, output.xres, output.yres, output.bpp, output.stride, extra], sort_keys=True)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def save_splash(output, path, extra):
    """Saves what's on the screen now (the splash screen's first frame) for
    tvsplash.py, unless the same splash is already saved. `extra` holds
    whatever else changes the picture (rotation, frame box, version)."""
    if getattr(output, "kind", None) != "framebuffer":
        return False
    sig = splash_signature(output, extra)
    head = read_header(path)
    if head is not None and head.get("sig") == sig:
        return False
    panel = output.panel
    pitch = panel.get_pitch()
    buf = panel.get_buffer()
    try:
        data = buf.raw
    finally:
        del buf
    header = splash_header(output.xres, output.yres, output.bpp, pitch, output.stride, sig)

    def write():
        try:
            _write(path, header + data)
            log.info("saved the power-on logo (%d KB)", (len(header) + len(data)) // 1024)
        except OSError as e:
            log.warning("couldn't save the power-on logo: %s", e)

    threading.Thread(target=write, name="splash-save", daemon=True).start()
    return True
