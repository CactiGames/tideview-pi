"""Getting pictures onto the screen.

FramebufferOutput writes straight into the Linux framebuffer (/dev/fb0), so
no desktop, X11 or Wayland is needed. That is the lightest way to drive a
screen from a Pi Zero, and it only copies the rows that changed. The picture
can be turned a quarter turn for an upright frame.

WindowOutput opens a normal window (for trying TideView on a PC), and
ImageOutput just keeps the last frame (for screenshots and tests).
"""

import logging
import mmap
import os
import struct

import pygame

try:
    import fcntl
except ImportError:  # Windows: no framebuffer, window only
    fcntl = None

log = logging.getLogger("tideview.output")

FBIOGET_VSCREENINFO = 0x4600
FBIOBLANK = 0x4611
FB_BLANK_UNBLANK = 0
FB_BLANK_POWERDOWN = 4
KDSETMODE = 0x4B3A
KD_TEXT = 0
KD_GRAPHICS = 1


def logical_size(phys_w, phys_h, rotation):
    return (phys_h, phys_w) if rotation in (90, 270) else (phys_w, phys_h)


def to_physical_rect(r, rotation, lw, lh):
    """A rect in the (rotated) picture -> the same pixels on the panel.
    rotation is how far the picture is turned clockwise on the panel."""
    if rotation == 90:
        return pygame.Rect(lh - r.y - r.h, r.x, r.h, r.w)
    if rotation == 180:
        return pygame.Rect(lw - r.x - r.w, lh - r.y - r.h, r.w, r.h)
    if rotation == 270:
        return pygame.Rect(r.y, lw - r.x - r.w, r.h, r.w)
    return pygame.Rect(r)


def to_logical_point(px, py, rotation, lw, lh):
    """A point on the panel -> the same point in the (rotated) picture."""
    if rotation == 90:
        return py, lh - 1 - px
    if rotation == 180:
        return lw - 1 - px, lh - 1 - py
    if rotation == 270:
        return lw - 1 - py, px
    return px, py


class FramebufferOutput:
    kind = "framebuffer"

    def __init__(self, device="/dev/fb0", rotation=0, tty="/dev/tty1"):
        self.device = device
        self.fd = os.open(device, os.O_RDWR)
        var = bytearray(160)
        fcntl.ioctl(self.fd, FBIOGET_VSCREENINFO, var, True)
        f = struct.unpack_from("8I12I", var)
        self.xres, self.yres, xres_v, yres_v, xoff, yoff, self.bpp = f[0], f[1], f[2], f[3], f[4], f[5], f[6]
        red, green, blue = f[8:11], f[11:14], f[14:17]
        name = os.path.basename(device)
        self.stride = _read_int("/sys/class/graphics/%s/stride" % name) or xres_v * self.bpp // 8
        self.offset = yoff * self.stride + xoff * self.bpp // 8
        size = self.stride * max(yres_v, self.yres)
        self.mm = mmap.mmap(self.fd, size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)
        masks = tuple(((1 << c[1]) - 1) << c[0] if c[1] else 0 for c in (red, green, blue))
        if self.bpp not in (16, 24, 32):
            raise RuntimeError("unsupported framebuffer depth %d" % self.bpp)
        self.panel = pygame.Surface((self.xres, self.yres), 0, self.bpp, masks + (0,))
        self.rotation = rotation
        self.size = logical_size(self.xres, self.yres, rotation)
        self._blanked = None
        self._tty = None
        self._take_console(tty)
        log.info("framebuffer %s: %dx%d, %d bpp, stride %d, picture %dx%d (turned %d)",
                 device, self.xres, self.yres, self.bpp, self.stride, self.size[0], self.size[1], rotation)

    def _take_console(self, tty):
        """Stops the text console drawing over the picture (and hides its
        cursor) while TideView runs."""
        try:
            self._tty = os.open(tty, os.O_RDWR | os.O_NOCTTY)
            fcntl.ioctl(self._tty, KDSETMODE, KD_GRAPHICS)
        except OSError as e:
            log.warning("couldn't take over the console (%s); text may show through", e)
            if self._tty is not None:
                os.close(self._tty)
            self._tty = None

    def set_rotation(self, rotation):
        self.rotation = rotation
        self.size = logical_size(self.xres, self.yres, rotation)

    def present(self, frame, rects=None):
        lw, lh = frame.get_size()
        if rects is None:
            rects = [frame.get_rect()]
        dirty = None
        for r in rects:
            r = r.clip(frame.get_rect())
            if r.w <= 0 or r.h <= 0:
                continue
            part = frame.subsurface(r)
            if self.rotation:
                part = pygame.transform.rotate(part, -self.rotation)  # pygame turns anticlockwise
            pr = to_physical_rect(r, self.rotation, lw, lh)
            self.panel.blit(part, pr.topleft)
            dirty = pr if dirty is None else dirty.union(pr)
        if dirty is not None:
            self._copy(dirty.clip(self.panel.get_rect()))

    def _copy(self, r):
        """Copies part of the staging picture into the framebuffer."""
        if r.w <= 0 or r.h <= 0:
            return
        px = self.bpp // 8
        pitch = self.panel.get_pitch()
        buf = self.panel.get_buffer()
        try:
            with memoryview(buf) as src:
                if r.w * 10 >= self.xres * 6:
                    # Most of the width: whole rows, in one go when the rows
                    # are laid out the same.
                    if pitch == self.stride:
                        a = self.offset + r.top * self.stride
                        self.mm[a:a + r.h * pitch] = src[r.top * pitch:r.bottom * pitch]
                        return
                    x0, n = 0, self.xres * px
                else:
                    # A narrow strip (the swell band on an upright picture).
                    x0, n = r.left * px, r.w * px
                for y in range(r.top, r.bottom):
                    a = self.offset + y * self.stride + x0
                    b = y * pitch + x0
                    self.mm[a:a + n] = src[b:b + n]
        finally:
            del buf  # unlocks the surface for the next blit

    def blank(self, off):
        """Turns the HDMI signal off (most screens then go dark) or back on."""
        if self._blanked == off:
            return
        try:
            fcntl.ioctl(self.fd, FBIOBLANK, FB_BLANK_POWERDOWN if off else FB_BLANK_UNBLANK)
            self._blanked = off
        except OSError as e:
            log.warning("couldn't %s the screen: %s", "blank" if off else "unblank", e)
            self._blanked = off

    def close(self, keep_dark=False):
        """Gives the screen back to the text console. Run by systemd (the
        service), it leaves the last picture up instead: TideView is only
        restarting, and the console would show the Pi's start-up text."""
        if not keep_dark:
            try:
                self.blank(False)
            except Exception:  # noqa: BLE001
                pass
        if self._tty is not None:
            if not keep_dark and not os.environ.get("INVOCATION_ID"):
                try:
                    fcntl.ioctl(self._tty, KDSETMODE, KD_TEXT)
                except OSError:
                    pass
            os.close(self._tty)
            self._tty = None
        try:
            self.mm.close()
        finally:
            os.close(self.fd)


def _read_int(path):
    try:
        with open(path) as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


class WindowOutput:
    """A window on a PC, for trying TideView out. Mouse clicks act as taps.
    The window is shrunk to fit the computer's screen if need be."""
    kind = "window"

    def __init__(self, size, rotation=0, title="TideView"):
        self.rotation = rotation
        pygame.display.init()
        pygame.display.set_caption(title)
        self.resize(size)

    def set_rotation(self, rotation):
        self.rotation = rotation

    def resize(self, size):
        self.size = size
        self.scale = 1.0
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
            if dw > 0 and dh > 0:
                self.scale = min(1.0, dw * 0.92 / size[0], dh * 0.85 / size[1])
        except (AttributeError, IndexError, pygame.error):
            pass
        self.screen = pygame.display.set_mode((max(1, round(size[0] * self.scale)),
                                               max(1, round(size[1] * self.scale))))

    def to_picture(self, pos):
        """A mouse position in the window -> picture coordinates."""
        return pos[0] / self.scale, pos[1] / self.scale

    def present(self, frame, rects=None):
        if self.scale == 1.0:
            self.screen.blit(frame, (0, 0))
        else:
            pygame.transform.smoothscale(frame, self.screen.get_size(), self.screen)
        pygame.display.flip()

    def blank(self, off):
        pass

    def close(self, keep_dark=False):
        pygame.display.quit()


class ImageOutput:
    """Keeps the last frame (screenshots and tests)."""
    kind = "image"

    def __init__(self, size, rotation=0):
        self.size = size
        self.rotation = rotation
        self.frame = None
        self.blanked = False
        self.presents = 0

    def set_rotation(self, rotation):
        self.rotation = rotation

    def present(self, frame, rects=None):
        self.frame = frame.copy()
        self.presents += 1

    def blank(self, off):
        self.blanked = off

    def close(self, keep_dark=False):
        pass
