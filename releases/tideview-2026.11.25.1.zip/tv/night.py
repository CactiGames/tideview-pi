"""Night mode: dim the picture or make it black, by time of day. A tap at
night brings the picture back for a minute.

The HDMI signal is never turned off: the Jaycar screen then shows a blue
"No Signal" box instead of going dark, and the Pi can't switch the screen's
own power. A black picture is the darkest it can do."""

from datetime import datetime


class NightController:
    def __init__(self, settings):
        self.settings = settings
        self.state = "day"  # "day", "dim" or "black"
        self._woken_until = 0.0

    def in_night_window(self, now):
        d = datetime.fromtimestamp(now)
        m = d.hour * 60 + d.minute
        start, end = self.settings["nightStart"], self.settings["dayStart"]
        if start == end:
            return False
        return (start <= m < end) if start < end else (m >= start or m < end)

    def wake_briefly(self, now, seconds=60):
        self._woken_until = now + seconds

    def evaluate(self, now):
        """Works out the state for now; returns True when it changed."""
        mode = self.settings["nightMode"]
        nxt = "day"
        if mode != "off" and self.in_night_window(now) and now >= self._woken_until:
            nxt = {"dim": "dim", "black": "black", "screenOff": "black"}.get(mode, "day")
        changed = nxt != self.state
        self.state = nxt
        return changed
