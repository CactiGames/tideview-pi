"""Settings: a short list of sections (Beach, On screen, Display, Night,
Position, Forecast, Wi-Fi, Phone app, Device), each with its own page.

The same rows feed the phone app and the browser page: SettingsScreen.rows
(remote=True) gives every section's rows in one list, each section starting
with a "section" row that carries its key, title and icon name.

Labels are kept short and plain. A row only has a line underneath when it
tells you something you need.
"""

import threading
import time

from .. import report, system, updates
from ..settings import ELEMENTS, NIGHT_MODES, ORIENTATIONS, REFRESH_CHOICES, VISIBILITY
from ..version import VERSION
from .display import format_clock, round_half_up
from .frame import FrameEditor, format_length
from .lists import ConfirmButton, ListScreen, RegionPicker, row
from .wifi_screen import WifiScreen, status_line

NIGHT_LABELS = {"off": "Stay on", "dim": "Dim", "black": "Screen off"}
ORIENTATION_LABELS = {"upright": "Upright", "sideways": "Sideways", "upright-flipped": "Upright, flipped",
                      "sideways-flipped": "Sideways, flipped"}
VIS_LABELS = {"show": "Show", "tap": "On tap", "hide": "Hide"}

# (key, title, icon name for the phone app)
SECTIONS = [
    ("beach", "Beach", "beach"),
    ("screen", "On screen", "eye"),
    ("display", "Display", "display"),
    ("night", "Night", "moon"),
    ("position", "Position", "frame"),
    ("forecast", "Forecast", "forecast"),
    ("wifi", "Wi-Fi", "wifi"),
    ("phone", "Phone app", "phone"),
    ("device", "Device", "device"),
]


def _interval(m):
    return "%d min" % m if m < 60 else ("1 hour" if m == 60 else "%d hours" % (m // 60))


def _pct(v):
    return "%d%%" % round_half_up(v * 100)


def _clock(minutes):
    """A timestamp today at minutes past midnight (for formatting)."""
    lt = time.localtime()
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, minutes // 60, minutes % 60, 0, 0, 0, -1))


class SettingsScreen(ListScreen):
    """The list of sections."""

    title = "Settings"

    def __init__(self, app):
        super().__init__(app)
        self._pi_info = None
        self._pi_info_at = 0
        self._updates = None
        self._updates_at = 0
        self._asked_at = 0  # when "Check for updates" was tapped
        self.shutdown = ConfirmButton("Shut down", "Tap again to shut down", self._do_shutdown)
        self.restart = ConfirmButton("Restart TideView", "Tap again to restart", app.request_restart)
        self.unlink = ConfirmButton("Unlink all phones", "Tap again to unlink them", self._unlink)
        self.reset_frame = ConfirmButton("Reset position", "Tap again to reset", self._reset_frame)

    # -- the section list (touch screen) ------------------------------------

    def rows(self, remote=False):
        if remote:
            return self.all_rows()
        out = []
        for key, title, _icon in SECTIONS:
            out.append(row("nav", title, value=self.summary(key), id="section-" + key,
                           on_tap=lambda key=key, title=title: self.app.push(SectionScreen(self.app, self, key, title))))
        return out

    def all_rows(self):
        """Every section's rows, for phones."""
        out = []
        for key, title, icon in SECTIONS:
            out.append(row("section", title, key=key, icon=icon, value=self.summary(key)))
            out += self.section_rows(key, remote=True)
        return out

    def sections(self):
        return [{"key": key, "title": title, "icon": icon, "summary": self.summary(key)}
                for key, title, icon in SECTIONS]

    def summary(self, key):
        """A word or two for the section list."""
        app = self.app
        s = app.settings
        try:
            if key == "beach":
                return app.forecast.beach.name
            if key == "screen":
                vis = [s.visibility(k) for k, _n in ELEMENTS]
                hidden, tap = vis.count("hide"), vis.count("tap")
                if not hidden and not tap:
                    return "Everything shown"
                parts = []
                if tap:
                    parts.append("%d on tap" % tap)
                if hidden:
                    parts.append("%d hidden" % hidden)
                return ", ".join(parts)
            if key == "display":
                return "%s · %s" % ("Metres" if s["unit"] == "m" else "Feet", "Knots" if s["windInKnots"] else "km/h")
            if key == "night":
                mode = s["nightMode"]
                if mode == "off":
                    return "Stays on"
                use24 = s["use24h"]
                return "%s %s to %s" % (NIGHT_LABELS[mode], format_clock(_clock(s["nightStart"]), use24),
                                        format_clock(_clock(s["dayStart"]), use24))
            if key == "position":
                return "Fitted to frame" if s["frameEnabled"] else "Full screen"
            if key == "forecast":
                return "Every %s" % _interval(s["refreshMinutes"])
            if key == "wifi":
                net = app.net
                if net is not None and net.online is False:
                    return "Not connected"
                w = app.wifi
                if w is not None and w.available():
                    return w.status.get("ssid") or ("Joining..." if w.joining else "Not connected")
                return "Connected" if (net is not None and net.online) else ""
            if key == "phone":
                rc = app.remote
                if rc is None:
                    return "Off"
                n = len(rc.pairing.phones)
                return "Not linked" if n == 0 else ("1 phone" if n == 1 else "%d phones" % n)
            if key == "device":
                return VERSION
        except Exception:  # noqa: BLE001  (a summary must never break the list)
            return ""
        return ""

    # -- each section's rows ------------------------------------------------

    def section_rows(self, key, remote=False):
        return getattr(self, "_rows_" + key)(remote)

    def _rows_beach(self, remote):
        app = self.app
        beach = app.forecast.beach
        return [row("nav", "Beach", value=beach.name, sub=beach.region, id="beach", opens="beach",
                    on_tap=lambda: app.push(RegionPicker(app)), remote_tap=lambda: None)]

    def _rows_screen(self, remote):
        s = self.app.settings
        out = [row("info", "On tap shows it for 20 seconds after you tap the screen.")]
        for key, name in ELEMENTS:
            v = s.visibility(key)
            out.append(row("cycle", name, value=VIS_LABELS[v], id=key,
                           on_tap=lambda key=key: self._cycle(key, VISIBILITY),
                           **self._choices(key, VISIBILITY, VIS_LABELS.get)))
        return out

    def _rows_display(self, remote):
        s = self.app.settings
        return [
            row("cycle", "Wave height", value="Metres" if s["unit"] == "m" else "Feet", id="unit",
                on_tap=lambda: s.set(unit="ft" if s["unit"] == "m" else "m"),
                options=["Feet", "Metres"], selected=1 if s["unit"] == "m" else 0,
                on_choose=lambda i: s.set(unit="m" if i == 1 else "ft")),
            row("cycle", "Wind speed", value="Knots" if s["windInKnots"] else "km/h", id="windInKnots",
                on_tap=lambda: self._toggle("windInKnots"), options=["km/h", "Knots"],
                selected=1 if s["windInKnots"] else 0, on_choose=lambda i: s.set(windInKnots=i == 1)),
            row("cycle", "Clock", value="24-hour" if s["use24h"] else "12-hour", id="use24h",
                on_tap=lambda: self._toggle("use24h"), options=["12-hour", "24-hour"],
                selected=1 if s["use24h"] else 0, on_choose=lambda i: s.set(use24h=i == 1)),
            row("toggle", "Moving water", value=s["animate"], id="animate", on_tap=lambda: self._toggle("animate")),
            row("cycle", "Rotation", value=ORIENTATION_LABELS[s["orientation"]], id="orientation",
                on_tap=lambda: self._cycle("orientation", ORIENTATIONS),
                **self._choices("orientation", ORIENTATIONS, ORIENTATION_LABELS.get)),
        ]

    def _rows_night(self, remote):
        s = self.app.settings
        use24 = s["use24h"]
        out = [row("cycle", "At night", value=NIGHT_LABELS[s["nightMode"]], id="nightMode",
                   on_tap=lambda: self._cycle("nightMode", NIGHT_MODES),
                   **self._choices("nightMode", NIGHT_MODES, NIGHT_LABELS.get))]
        if s["nightMode"] != "off":
            out += [row("stepper", "From", value=format_clock(_clock(s["nightStart"]), use24), id="nightStart",
                        on_minus=lambda: self._step_time("nightStart", -15),
                        on_plus=lambda: self._step_time("nightStart", 15)),
                    row("stepper", "Until", value=format_clock(_clock(s["dayStart"]), use24), id="dayStart",
                        on_minus=lambda: self._step_time("dayStart", -15),
                        on_plus=lambda: self._step_time("dayStart", 15))]
            if s["nightMode"] == "dim":
                out.append(row("stepper", "How dim", value=_pct(s["dimLevel"]), id="dimLevel",
                               on_minus=lambda: self._step("dimLevel", -0.1, 0.1, 0.9),
                               on_plus=lambda: self._step("dimLevel", 0.1, 0.1, 0.9)))
            out.append(row("info", "A tap lights it up for a minute."))
            if remote:
                out.append(row("nav", "Light it up now", id="wake", on_tap=self._wake))
        return out

    def _rows_position(self, remote):
        app = self.app
        s = app.settings
        geo = app.frame_geometry
        screen = app.screen_size
        box = geo.box(screen)
        cm = s["frameInCm"]
        lx, ty, bw, bh = geo.mm(box)

        def nudge(field, sign):
            return lambda: (geo.nudge(screen, field, sign), app.frame_changed(), app.show_frame_guide())

        out = [row("toggle", "Fit to frame", value=s["frameEnabled"], id="frameEnabled",
                   sub="Shrinks the picture to fit a frame's window.",
                   on_tap=lambda: (self._toggle("frameEnabled"), app.frame_changed(), app.show_frame_guide()))]
        if remote:
            out.append(row("nav", "Move and resize", id="frameAdjust", opens="frame", remote_tap=lambda: None))
        else:  # dragging needs the touch screen
            out.append(row("nav", "Move and resize", sub="Drag the corners and the middle.",
                           on_tap=lambda: app.push(FrameEditor(app))))
        out += [row("stepper", "Width", value=format_length(bw, cm), on_minus=nudge("w", -1), on_plus=nudge("w", 1),
                    id="frameWidth"),
                row("stepper", "Height", value=format_length(bh, cm), on_minus=nudge("h", -1), on_plus=nudge("h", 1),
                    id="frameHeight"),
                row("stepper", "Left gap", value=format_length(lx, cm), id="frameLeft",
                    on_minus=nudge("x", -1), on_plus=nudge("x", 1)),
                row("stepper", "Top gap", value=format_length(ty, cm), id="frameTop",
                    on_minus=nudge("y", -1), on_plus=nudge("y", 1)),
                row("cycle", "Units", value="Centimetres" if cm else "Inches", id="frameInCm",
                    on_tap=lambda: s.set(frameInCm=not cm), options=["Inches", "Centimetres"],
                    selected=1 if cm else 0, on_choose=lambda i: s.set(frameInCm=i == 1)),
                row("stepper", "Screen size", value="%.1f in" % s["screenDiagonalIn"], id="screenDiagonal",
                    sub="Corner to corner. The Jaycar screen is 7 in.",
                    on_minus=lambda: (self._step("screenDiagonalIn", -0.1, 3.0, 30.0, 1), app.frame_changed()),
                    on_plus=lambda: (self._step("screenDiagonalIn", 0.1, 3.0, 30.0, 1), app.frame_changed())),
                row("button", self.reset_frame.current_label(), id="frameReset", on_tap=self.reset_frame.tap,
                    remote_tap=self._reset_frame, confirm="Reset the picture to fill the screen?")]
        return out

    def _rows_forecast(self, remote):
        app = self.app
        s = app.settings
        fc = app.forecast
        f = fc.forecast
        out = [row("cycle", "Update every", value=_interval(s["refreshMinutes"]), id="refreshMinutes",
                   on_tap=lambda: self._cycle("refreshMinutes", REFRESH_CHOICES),
                   **self._choices("refreshMinutes", REFRESH_CHOICES, _interval)),
               row("nav", "Update now", sub=self._forecast_status(), on_tap=fc.refresh, id="refresh"),
               row("toggle", "Use airport wind", value=s["useMeasuredWind"], id="useMeasuredWind",
                   sub="Score with the wind measured at the airport, not the forecast.",
                   on_tap=lambda: self._toggle("useMeasuredWind"))]
        if f is not None:
            out.append(row("info", "Sources", sub="Swell: %s\nWind: %s\nTide: %s" % (
                f.swell_source, f.wind_source, f.tide_source)))
        keys = app.keys
        out.append(row("info", "Data keys", sub="NIWA: %s · MetService: %s" % (
            "found" if keys.get("niwa") else "none (tide model)",
            "found" if keys.get("metocean") else "none (free models)")))
        return out

    def _rows_wifi(self, remote):
        app = self.app
        w = app.wifi
        net = app.net
        if w is None or not w.available():
            if net is not None and net.online is not None:  # can't change it, but can say how it is
                return [row("info", "Wi-Fi", value="Connected" if net.online else "Not connected",
                            sub=None if net.online else self._offline_text())]
            return [row("info", "Wi-Fi", value="Can't be changed here")]
        w.refresh_status()
        st = w.status
        if net is not None and net.online is False:
            sub = self._offline_text()
        elif w.joining:
            sub = "Joining %s..." % w.joining
        elif st.get("ssid"):
            sub = status_line(w, net)[1]
        else:
            sub = None
        value = st.get("ssid") or ("Joining..." if w.joining else ("Not connected" if st else ""))
        return [row("nav", "Network", value=value, sub=sub, id="wifi", opens="wifi", remote_tap=lambda: None,
                    on_tap=lambda: app.push(WifiScreen(app)))]

    def _rows_phone(self, remote):
        app = self.app
        rc = app.remote
        if rc is None:
            return [row("info", "Phone link is off", sub="Restart TideView to try again.")]
        out = [row("nav", "Link a phone", id="showCode", sub="Shows a code to scan with the TideView app.",
                   on_tap=lambda: app.open("pair"))]
        if rc.running() and rc.web_address():
            from ..remote import pretty_code
            out.append(row("info", "Address and code", sub="%s · %s" % (rc.web_address(), pretty_code(rc.pairing.code))))
        elif rc.running():
            out.append(row("info", "Waiting for Wi-Fi", sub="The code shows once TideView is online."))
        else:
            out.append(row("info", "Not running", sub=rc.error or "Starting..."))
        out.append(row("info", "Linked phones", sub=rc.pairing.describe(time.time())))
        if rc.pairing.linked:
            out.append(row("button", self.unlink.current_label(), on_tap=self.unlink.tap, id="unlink",
                           remote_tap=rc.unlink_all,
                           confirm="Unlink every phone? Each one will need to scan the new code."))
        return out

    def _rows_device(self, remote):
        app = self.app
        now = time.time()
        use24 = app.settings["use24h"]
        pi = self._pi()
        out = [row("info", "Version", value=VERSION, sub=self._update_status(now, use24))]
        if updates.available():
            out.append(row("nav", "Check for updates", id="checkUpdates", on_tap=self._check_updates))
        out += [row("info", "IP address", value=pi["ip"]),
                row("info", "Temperature", value=pi["temp"], sub=pi["temp_note"]),
                row("info", "Touch screen", sub=self._touch_text()),
                row("nav", "Save report to SD card", id="saveReport", sub=report.status_text(
                    lambda t: format_clock(t, use24)) or "For working out problems.",
                    on_tap=lambda: report.save_soon(app, "Asked for on the touch screen"),
                    remote_tap=lambda: report.save_soon(app, "Asked for from a phone"))]
        if remote:
            out.append(row("nav", "Show report", id="showReport", opens="report", remote_tap=lambda: None))
        out += [row("button", self.restart.current_label(), on_tap=self.restart.tap, id="restart",
                    remote_tap=self._later(app.request_restart),
                    confirm="Restart TideView? The screen goes dark for about half a minute."),
                row("button", self.shutdown.current_label(), on_tap=self.shutdown.tap, color=(0x6B, 0x23, 0x23),
                    id="shutdown", remote_tap=self._later(self._do_shutdown),
                    confirm="Shut down the Pi? To start it again, unplug it and plug it back in.")]
        return out

    # -- helpers --------------------------------------------------------------

    def _unlink(self):
        if self.app.remote is not None:
            self.app.remote.unlink_all()

    def _reset_frame(self):
        s = self.app.settings
        s.set(frameEnabled=False, frameLeftMm=None, frameTopMm=None, frameWidthMm=None, frameHeightMm=None)
        self.app.frame_changed()

    def _later(self, fn, seconds=1.0):
        """For a phone: answer it first, then do fn (restart, shut down)."""
        def run():
            t = threading.Timer(seconds, fn)
            t.daemon = True
            t.start()
        return run

    def _choose(self, key, choices):
        return lambda i: self.app.settings.set(**{key: choices[i]})

    def _choices(self, key, choices, labels):
        """Extra fields for a cycle row, so a phone can show a list."""
        cur = self.app.settings[key]
        return {"options": [labels(c) for c in choices],
                "selected": choices.index(cur) if cur in choices else -1,
                "on_choose": self._choose(key, choices)}

    def _cycle(self, key, choices):
        s = self.app.settings
        cur = s[key]
        i = choices.index(cur) if cur in choices else -1
        s.set(**{key: choices[(i + 1) % len(choices)]})

    def _toggle(self, key):
        self.app.settings.set(**{key: not self.app.settings[key]})

    def _step_time(self, key, minutes):
        s = self.app.settings
        s.set(**{key: (s[key] + minutes) % (24 * 60)})

    def _step(self, key, delta, lo, hi, digits=2):
        s = self.app.settings
        s.set(**{key: round(min(hi, max(lo, (s[key] or 0) + delta)), digits)})

    def _do_shutdown(self):
        self.app.show_message("Shutting down. Unplug when the green light stops flashing.")
        system.shutdown()

    def _check_updates(self):
        if updates.request_check():
            self._asked_at = time.time()
            self._updates_at = 0
            self.app.show_message("Checking for updates...", 6)
        else:
            self.app.show_message("Couldn't check for updates. Try again soon.", 6)

    def _update_status(self, now, use24):
        if self._updates is None or now - self._updates_at > 2:
            self._updates_at = now
            self._updates = updates.read_state()
        st = self._updates
        if now - self._asked_at < 30 and not updates.busy_text(st, now) and \
                float(st.get("last_try") or 0) < self._asked_at - 1:
            return "Checking for updates..."
        return updates.describe(st, now, lambda t: format_clock(t, use24))

    def _pi(self):
        now = time.time()
        if self._pi_info is None or now - self._pi_info_at > 10:
            self._pi_info_at = now
            ip = system.ip_address()
            temp = system.cpu_temperature()
            power = system.power_problems()
            notes = []
            if temp is not None and temp >= 75:
                notes.append("Hot. Give the frame some air gaps.")
            if power:
                notes.append(power)
            self._pi_info = {
                "ip": ip or "Not connected",
                "temp": "-" if temp is None else "%d°C" % round(temp),
                "temp_note": " ".join(notes) or None,
            }
        return self._pi_info

    def _wake(self):
        app = self.app
        app.night.wake_briefly(time.time())
        app.frame_changed()
        app.display.invalidate()

    def _offline_text(self):
        net = self.app.net
        if net is None or net.online:
            return None
        gone = time.monotonic() - (net.offline_since or time.monotonic())
        text = "Offline for %d min. It keeps trying by itself." % max(1, round(gone / 60))
        if net.diagnosis:
            text += " " + net.diagnosis
        return text

    def _touch_text(self):
        names = self.app.touch_names()
        text = ", ".join(names) if names else "None found. Check the USB cable."
        drops = getattr(self.app.touch, "dropouts", 0)
        if drops:
            text += ". Dropped out %s. The screen may need its own charger." % (
                "once" if drops == 1 else "%d times" % drops)
        return text

    def _forecast_status(self):
        fc = self.app.forecast
        use24 = self.app.settings["use24h"]
        if fc.loading:
            return "Updating..."
        parts = []
        f = fc.forecast
        if f is not None:
            parts.append("Updated %s." % format_clock(f.fetched_at, use24))
        if fc.error:
            parts.append("Last try failed: %s" % fc.error)
        return " ".join(parts) or "Waiting for the first update."


class SectionScreen(ListScreen):
    """One section's page on the touch screen."""

    def __init__(self, app, parent, key, title):
        super().__init__(app)
        self.parent = parent
        self.key = key
        self.title = title
        self.back_label = "Settings"

    def rows(self):
        return self.parent.section_rows(self.key, remote=False)
