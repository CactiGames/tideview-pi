"""The card on the main screen that links a phone: a QR code holding this
Pi's address and code, with the same written underneath for typing in."""

import functools

import pygame

from .. import qrcodegen
from .gfx import NIGHT, WHITE, blit_text

QUIET = 4  # blank modules round the code, as scanners expect
CARD = (0x0B, 0x10, 0x28, 0xFF)  # opaque, so drawing it again over itself changes nothing
EDGE = (255, 255, 255, 0x40)


@functools.lru_cache(maxsize=4)  # encoding takes a moment on a Pi Zero
def qr_surface(text, module):
    """The QR code for text, black on white, module pixels per square."""
    qr = qrcodegen.QrCode.encode_text(text, qrcodegen.QrCode.Ecc.MEDIUM)
    n = qr.get_size()
    surf = pygame.Surface(((n + 2 * QUIET) * module,) * 2)
    surf.fill(WHITE)
    for y in range(n):
        x = 0
        while x < n:  # one rectangle per run of dark squares
            if not qr.get_module(x, y):
                x += 1
                continue
            start = x
            while x < n and qr.get_module(x, y):
                x += 1
            surf.fill((0, 0, 0), ((QUIET + start) * module, (QUIET + y) * module, (x - start) * module, module))
    return surf


def card(gfx, size, info):
    """The card as a surface, sized for a canvas of size (w, h)."""
    w, h = size
    u = min(w, h) / 600.0
    pad = 26 * u
    width = int(min(w - 24 * u, 420 * u))
    inner = width - 2 * pad
    url = info.get("url")
    parts = []  # (kind, payload, height)

    def text(s, px, bold=False, opacity=1.0, gap=8):
        for line in gfx.wrap(s, px, inner, bold):
            parts.append(("text", (line, px, bold, opacity), px * 1.3))
        parts.append(("gap", None, gap * u))

    if info.get("offline"):
        text("No Wi-Fi", 27 * u, bold=True, gap=10)
        if info.get("why"):
            text(info["why"], 19 * u, gap=10)
        text("TideView keeps trying to reconnect by itself%s Phone control starts once it's back." % (
            ", and the clock may be wrong until then." if info.get("clock") else "."), 17 * u, opacity=0.7,
             gap=12 if info.get("tap") else 0)
        if info.get("tap"):
            text("Tap here to choose a network or type a new password.", 20 * u, bold=True, gap=0)
    elif url:
        text("Link your phone", 27 * u, bold=True, gap=14)
        module = max(2, int((min(inner, h * 0.52)) // 41))
        code = qr_surface(url, module)
        parts.append(("qr", code, code.get_height()))
        parts.append(("gap", None, 14 * u))
        text("Scan this with the TideView app.", 22 * u, gap=4)
        text("Your phone's camera works too: it opens the settings in the browser.", 17 * u, opacity=0.7, gap=10)
        text("%s  ·  code %s" % (info.get("address") or "", info.get("code") or ""), 18 * u, opacity=0.85, gap=0)
        if info.get("hides_in"):
            parts.append(("gap", None, 8 * u))
            text("This hides by itself in %d min." % info["hides_in"], 16 * u, opacity=0.6, gap=0)
    else:
        text("Link your phone", 27 * u, bold=True, gap=10)
        text("TideView isn't on Wi-Fi, so the code to link a phone can't show yet. It shows here as soon "
             "as the Wi-Fi is back.", 19 * u, opacity=0.8, gap=0)

    height = int(pad * 2 + sum(p[2] for p in parts))
    surf = gfx.panel(width, height, 22 * u, CARD, EDGE).copy()
    y = pad
    for kind, payload, ph in parts:
        if kind == "text":
            line, px, bold, opacity = payload
            blit_text(surf, gfx, line, px, width / 2, y, bold=bold, opacity=opacity, anchor="tc")
        elif kind == "qr":
            surf.blit(payload, (int((width - payload.get_width()) / 2), int(y)))
        y += ph
    return surf


def place(canvas_size, card_size):
    """Where the card goes on the main screen: in the middle, clear of the
    clock at the top."""
    w, h = canvas_size
    cw, ch = card_size
    x = (w - cw) // 2
    if h > w:  # upright: just below the middle, so the clock and beach stay in view
        y = max(int(h * 0.2), (h - ch) // 2)
        y = min(y, h - ch - 8)
    else:
        y = (h - ch) // 2
    return pygame.Rect(x, max(0, y), cw, ch)


__all__ = ["card", "place", "qr_surface", "NIGHT"]
