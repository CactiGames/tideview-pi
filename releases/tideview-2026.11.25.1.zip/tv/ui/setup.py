"""The start-up splash, the first-run welcome, and the page that shows the
code for linking a phone.

All three use the brand look: the logo over deep blue, with teal water
rolling along the bottom (the same three swell lines as the forecast).
"""

import math
import os
import time

import pygame

from .gfx import ASSETS, WHITE, blit_text, lerp

TOP = (0x0A, 0x22, 0x36)
BOTTOM = (0x0B, 0x3D, 0x52)
WAVES = [(0x0F, 0x76, 0x6E), (0x14, 0xB8, 0xA6), (0x2D, 0xD4, 0xBF)]  # back to front
TEAL = (0x5E, 0xEA, 0xD4)
MUTED = (0x9F, 0xC4, 0xC8)
BUTTON = (0x13, 0x4E, 0x5E)
SPLASH_MIN = 2.5  # seconds the splash shows at least
SPLASH_MAX = 8.0  # ... and at most, while the first forecast loads
STEPS = 40


def _logo(size):
    """The logo mark, size pixels square (cached per size)."""
    cache = _logo.__dict__.setdefault("cache", {})
    size = max(8, int(round(size)))
    img = cache.get(size)
    if img is None:
        src = pygame.image.load(os.path.join(ASSETS, "brand", "mark.png"))
        if not (src.get_flags() & pygame.SRCALPHA):
            tmp = pygame.Surface(src.get_size(), pygame.SRCALPHA)
            tmp.blit(src, (0, 0))
            src = tmp
        img = cache[size] = pygame.transform.smoothscale(src, (size, size))
    return img


def background(w, h):
    """Deep blue, a little lighter at the bottom (cached per size)."""
    cache = background.__dict__.setdefault("cache", {})
    surf = cache.get((w, h))
    if surf is None:
        col = pygame.Surface((1, max(2, h)))
        for y in range(col.get_height()):
            col.set_at((0, y), lerp(TOP, BOTTOM, y / (col.get_height() - 1)))
        surf = pygame.transform.scale(col, (max(1, w), max(1, h)))
        if len(cache) > 4:
            cache.clear()
        cache[(w, h)] = surf
    return surf


def _wave_layers(h, level):
    """(colour, base line, amplitude, waves across, offset, direction) for the
    three lines, the back one highest. level: 0 top .. 1 bottom."""
    base = h * level
    return [
        (WAVES[0], base, 0.016 * h, 0.55, 0.15, 1),
        (WAVES[1], base + 0.045 * h, 0.015 * h, 0.75, 1.9, -1),
        (WAVES[2], base + 0.09 * h, 0.014 * h, 0.65, 3.6, 1),
    ]


def wave_band(w, h, level):
    """The rows the rolling water can touch."""
    layers = _wave_layers(h, level)
    y0 = min(b - a * 1.4 for _, b, a, *_ in layers) - 2
    return pygame.Rect(0, max(0, int(y0)), w, max(0, h - max(0, int(y0))))


def draw_waves(surf, w, h, level, phase, top=0):
    """Paints the three teal lines (and the water under them) onto surf,
    which holds the rows from top down of a w x h picture. surf must be a
    surface of its own (pygame's smoothed lines misbehave on subsurfaces)."""
    t = phase * 2 * math.pi
    for col, base, amp, freq, off, d in _wave_layers(h, level):
        crest = []
        for i in range(STEPS + 1):
            u = i / STEPS
            y = (base + amp * math.sin(2 * math.pi * u * freq + off + t * d)
                 + amp * 0.35 * math.sin(2 * math.pi * u * freq * 2.3 + off * 1.7 - t * d))
            crest.append((w * u, y - top))
        pygame.draw.polygon(surf, col, [(0, h - top)] + crest + [(w, h - top)])
        pygame.draw.aalines(surf, col, False, crest)


class _BrandScreen:
    """Shared drawing: background, water, buttons."""

    water_level = 0.80  # where the water sits (share of the height)
    animate = False

    def __init__(self, app):
        self.app = app
        self.g = app.gfx
        self._dirty = True
        self._buttons = []  # (rect, callback)
        self._press = None
        self._band = None
        self._scratch = None

    def invalidate(self):
        self._dirty = True

    def needs_render(self, now):
        return self._dirty or self.animate

    def next_change(self, now):
        return now + (0.12 if self.animate else 1.0)

    def _phase(self, now):
        return (now / 9.0) % 1.0

    def _paint_base(self, canvas, now):
        w, h = canvas.get_size()
        canvas.blit(background(w, h), (0, 0))
        self._band = wave_band(w, h, self.water_level)
        self._paint_band(canvas, now)

    def _paint_band(self, canvas, now):
        w, h = canvas.get_size()
        band = self._band
        if band is None or band.h <= 0:
            return None
        if self._scratch is None or self._scratch.get_size() != band.size:
            self._scratch = pygame.Surface(band.size, 0, 32)
        self._scratch.blit(background(w, h), (0, 0), band)
        draw_waves(self._scratch, w, h, self.water_level, self._phase(now), top=band.y)
        canvas.blit(self._scratch, band.topleft)
        return band

    def _text(self, canvas, text, size, x, y, bold=False, color=WHITE, anchor="tc", opacity=1.0):
        return blit_text(canvas, self.g, text, size, x, y, bold=bold, color=color, anchor=anchor, opacity=opacity)

    def _wordmark(self, canvas, cx, y, size):
        g = self.g
        a = g.text_size("Tide", size, True)[0]
        b = g.text_size("View", size, True)[0]
        left = cx - (a + b) / 2
        blit_text(canvas, g, "Tide", size, left, y, bold=True)
        blit_text(canvas, g, "View", size, left + a, y, bold=True, color=TEAL)

    def _button(self, canvas, label, rect, callback, primary=False, u=1.0):
        rect = pygame.Rect(rect)
        fill = (0x2D, 0xD4, 0xBF, 0xFF) if primary else BUTTON + (0xFF,)
        canvas.blit(self.g.panel(rect.w, rect.h, rect.h / 2, fill, None if primary else (255, 255, 255, 0x30)),
                    rect.topleft)
        self._text(canvas, label, 24 * u, rect.centerx, rect.centery, bold=False,
                   color=(0x06, 0x2A, 0x33) if primary else WHITE, anchor="mc")
        self._buttons.append((rect.inflate(int(16 * u), int(16 * u)), callback))

    def on_touch(self, kind, x, y, now):
        if kind == "down":
            self._press = (x, y)
        elif kind == "up" and self._press:
            px, py = self._press
            self._press = None
            if abs(x - px) > 40 or abs(y - py) > 40:
                return
            for rect, cb in self._buttons:
                if rect.collidepoint(x, y):
                    cb()
                    self._dirty = True
                    return


class SplashScreen(_BrandScreen):
    """The logo over rolling water while TideView starts. Closes itself after
    a couple of seconds, once the forecast (or the saved one) is ready."""

    animate = True
    water_level = 0.74

    def __init__(self, app, now=None):
        super().__init__(app)
        self.started = time.time() if now is None else now

    def done(self, now):
        waited = now - self.started
        fc = self.app.forecast
        ready = fc.forecast is not None or (fc.error and not fc.loading)
        return waited >= SPLASH_MAX or (waited >= SPLASH_MIN and ready)

    def tick(self, now):
        if self.done(now):
            self.app.splash_done()

    def render(self, canvas, now):
        w, h = canvas.get_size()
        if not self._dirty and self._band is not None:
            band = self._paint_band(canvas, now)
            return [band] if band else []
        self._dirty = False
        self._paint_base(canvas, now)
        u = min(w, h) / 600
        size = min(w, h) * 0.34
        logo = _logo(size)
        top = h * (0.30 if h > w else 0.24) - size / 2 + (0 if h > w else 20 * u)
        canvas.blit(logo, (int((w - size) / 2), int(top)))
        self._wordmark(canvas, w / 2, top + size + 14 * u, 52 * u)
        return [canvas.get_rect()]


def _qr(url, max_px):
    from .pairing import QUIET, qr_surface
    from .. import qrcodegen
    n = qrcodegen.QrCode.encode_text(url, qrcodegen.QrCode.Ecc.MEDIUM).get_size() + 2 * QUIET
    module = max(2, int(max_px // n))
    return qr_surface(url, module)


class _CodeScreen(_BrandScreen):
    """A screen with the QR code for linking a phone."""

    water_level = 0.86

    def _code_card(self, canvas, rect, u):
        """The white card with the QR code, or what's missing for one."""
        remote = self.app.remote
        url = remote.url() if remote is not None else None
        rect = pygame.Rect(rect)
        if url:
            card_fill = (255, 255, 255, 0xFF)
            canvas.blit(self.g.panel(rect.w, rect.h, 26 * u, card_fill), rect.topleft)
            qr = _qr(url, min(rect.w - 40 * u, rect.h - 110 * u))
            qx = rect.x + (rect.w - qr.get_width()) // 2
            qy = rect.y + int(18 * u)
            canvas.blit(qr, (qx, qy))
            dark = (0x0A, 0x22, 0x36)
            from ..remote import pretty_code
            self._text(canvas, "Scan with the TideView app", 22 * u, rect.centerx, qy + qr.get_height() + 6 * u,
                       color=dark)
            self._text(canvas, "Code %s" % pretty_code(remote.pairing.code), 19 * u, rect.centerx,
                       qy + qr.get_height() + 38 * u, color=(0x3B, 0x5B, 0x66))
            return True
        canvas.blit(self.g.panel(rect.w, rect.h, 26 * u, (0x10, 0x33, 0x45, 0xFF), (255, 255, 255, 0x30)), rect.topleft)
        if remote is None or not remote.running():
            msg, sub = "Phone link is off", "Restart TideView to try again."
        else:
            msg, sub = "Connect to Wi-Fi", "The code shows once TideView is online."
        self._text(canvas, msg, 28 * u, rect.centerx, rect.centery - 50 * u, bold=True)
        self._text(canvas, sub, 20 * u, rect.centerx, rect.centery - 8 * u, color=MUTED)
        wifi = self.app.wifi
        if wifi is not None and wifi.available():
            bw, bh = 230 * u, 60 * u
            self._button(canvas, "Choose Wi-Fi", (rect.centerx - bw / 2, rect.centery + 34 * u, bw, bh),
                         lambda: self.app.open("wifi"), primary=True, u=u)
        return False

    def _key(self):
        remote = self.app.remote
        return (remote.url() if remote is not None else None, self.app.wifi is not None and self.app.wifi.available())

    def needs_render(self, now):
        return self._dirty or self._key() != getattr(self, "_last_key", None)


class WelcomeScreen(_CodeScreen):
    """First power-on: link the TideView app, or set it up on the screen."""

    def render(self, canvas, now):
        self._dirty = False
        self._last_key = self._key()
        self._buttons = []
        w, h = canvas.get_size()
        u = min(w, h) / 600
        self._paint_base(canvas, now)
        if w >= h:  # sideways: words on the left, code on the right
            left_w = w * 0.5
            cx = left_w / 2 + 10 * u
            logo = _logo(120 * u)
            y = h * 0.16
            canvas.blit(logo, (int(cx - logo.get_width() / 2), int(y)))
            y += logo.get_height() + 18 * u
            self._text(canvas, "Welcome to", 26 * u, cx, y, color=MUTED)
            self._wordmark(canvas, cx, y + 34 * u, 50 * u)
            y += 34 * u + 66 * u
            self._text(canvas, "Scan the code with the app,", 21 * u, cx, y, color=MUTED)
            self._text(canvas, "or set it up here.", 21 * u, cx, y + 28 * u, color=MUTED)
            bw, bh = 250 * u, 62 * u
            self._button(canvas, "Set up here", (cx - bw / 2, y + 72 * u, bw, bh), self._here, u=u)
            card = pygame.Rect(int(w * 0.54), int(h * 0.12), int(w * 0.40), int(h * 0.64))
            card.w = card.h = min(card.w, card.h + int(60 * u))
            card.x = int(w * 0.54 + (w * 0.40 - card.w) / 2)
            self._code_card(canvas, card, u)
        else:  # upright: stacked
            cx = w / 2
            logo = _logo(110 * u)
            y = h * 0.06
            canvas.blit(logo, (int(cx - logo.get_width() / 2), int(y)))
            y += logo.get_height() + 12 * u
            self._text(canvas, "Welcome to", 26 * u, cx, y, color=MUTED)
            self._wordmark(canvas, cx, y + 34 * u, 50 * u)
            y += 34 * u + 76 * u
            side = int(min(w * 0.82, h * 0.42))
            card = pygame.Rect(int(cx - side / 2), int(y), side, side + int(40 * u))
            self._code_card(canvas, card, u)
            y = card.bottom + 26 * u
            self._text(canvas, "Scan the code with the app, or set it up here.", 20 * u, cx, y, color=MUTED)
            bw, bh = 250 * u, 62 * u
            self._button(canvas, "Set up here", (cx - bw / 2, y + 40 * u, bw, bh), self._here, u=u)
        sw, sh = 110 * u, 46 * u
        skip = pygame.Rect(int(w - sw - 18 * u), int(h - sh - 16 * u), int(sw), int(sh))
        self._text(canvas, "Skip", 20 * u, skip.centerx, skip.centery, color=MUTED, anchor="mc")
        self._buttons.append((skip, self._skip))
        return [canvas.get_rect()]

    def _here(self):
        app = self.app
        net = app.net
        offline = net is not None and net.online is False
        if offline and app.wifi is not None and app.wifi.available():
            app.open("wifi")
        else:
            app.open("beach")

    def _skip(self):
        self.app.finish_setup()


class PairScreen(_CodeScreen):
    """The code for linking a phone (Settings > Phone app > Link a phone).
    Closes itself when a phone links, or after five minutes."""

    LIFETIME = 5 * 60

    def __init__(self, app):
        super().__init__(app)
        self.opened = time.time()

    def tick(self, now):
        if now - self.opened > self.LIFETIME and self.app.screen is self:
            self.app.close_screen()

    def render(self, canvas, now):
        self._dirty = False
        self._last_key = self._key()
        self._buttons = []
        w, h = canvas.get_size()
        u = min(w, h) / 600
        self._paint_base(canvas, now)
        if w >= h:
            cx = w * 0.27
            self._text(canvas, "Link a phone", 40 * u, cx, h * 0.24, bold=True)
            self._text(canvas, "Open the TideView app,", 21 * u, cx, h * 0.24 + 66 * u, color=MUTED)
            self._text(canvas, "tap Add, then scan.", 21 * u, cx, h * 0.24 + 94 * u, color=MUTED)
            bw, bh = 200 * u, 60 * u
            self._button(canvas, "Done", (cx - bw / 2, h * 0.24 + 150 * u, bw, bh), self.app.close_screen, u=u)
            side = int(min(w * 0.42, h * 0.72))
            card = pygame.Rect(int(w * 0.52 + (w * 0.44 - side) / 2), int(h * 0.10), side, side + int(30 * u))
            self._code_card(canvas, card, u)
        else:
            cx = w / 2
            self._text(canvas, "Link a phone", 40 * u, cx, h * 0.07, bold=True)
            side = int(min(w * 0.84, h * 0.46))
            card = pygame.Rect(int(cx - side / 2), int(h * 0.07 + 70 * u), side, side + int(40 * u))
            self._code_card(canvas, card, u)
            y = card.bottom + 26 * u
            self._text(canvas, "Open the TideView app, tap Add, then scan.", 20 * u, cx, y, color=MUTED)
            bw, bh = 200 * u, 60 * u
            self._button(canvas, "Done", (cx - bw / 2, y + 40 * u, bw, bh), self.app.close_screen, u=u)
        return [canvas.get_rect()]
