"""An on-screen keyboard for the touch screen: a Wi-Fi password or a network
name. Letters and numbers, and a second page with every symbol on a normal
keyboard. Shift once for a capital, twice for caps lock. Hold Delete to
delete more."""

import time

import pygame

from .gfx import ACCENT, NIGHT, WHITE, blit_text, lerp
from .lists import PANEL

KEY = (0x26, 0x30, 0x56)
KEY_SPECIAL = (0x1C, 0x24, 0x47)
KEY_DOWN = (0x4A, 0x58, 0x94)
FIELD = (0x16, 0x1D, 0x3A)
ERROR = (0xF0, 0xA8, 0xA8)
SHOW_LAST = 1.5  # seconds the last typed character of a password stays readable

# (label, what it does, width in keys). A one-character action types itself.
_LETTER_ROWS = [
    [(c, c, 1) for c in "1234567890"],
    [(c, c, 1) for c in "qwertyuiop"],
    [(c, c, 1) for c in "asdfghjkl"],
    [("", "shift", 1.5)] + [(c, c, 1) for c in "zxcvbnm"] + [("", "del", 1.5)],
    [("?123", "mode", 1.5), (",", ",", 1), ("", " ", 4), (".", ".", 1), ("", "done", 2.5)],
]
_SYMBOL_ROWS = [
    [(c, c, 1) for c in "1234567890"],
    [(c, c, 1) for c in "!@#$%^&*()"],
    [(c, c, 1) for c in "~`-_=+[]{}"],
    [("abc", "mode", 1.5)] + [(c, c, 1) for c in "<\\|;:'\""] + [("", "del", 1.5)],
    [(">", ">", 1), (",", ",", 1), ("", " ", 3), (".", ".", 1), ("/", "/", 1), ("?", "?", 1), ("", "done", 2)],
]


class KeyboardScreen:
    """Type a line of text, then on_done(text) runs (after this screen
    closes). check(text) returns '' if the text will do, else what's wrong."""

    full_screen = False

    def __init__(self, app, title, on_done, prompt="", secret=False, check=None, done_label="Done",
                 text="", max_len=63):
        self.app = app
        self.g = app.gfx
        self.title = title
        self.on_done = on_done
        self.prompt = prompt
        self.secret = secret
        self.show = False
        self.check = check
        self.done_label = done_label
        self.text = text
        self.max_len = max_len
        self.error = ""
        self.symbols = False
        self.shift = False
        self.caps = False
        self._shift_at = 0.0
        self._typed_at = 0.0
        self._keys = []  # (rect, action, label)
        self._pressed = None  # the action under the finger
        self._down_on = None  # "back", "eye" or None
        self._repeat = None  # next time a held Delete deletes again
        self._repeated = False
        self._back_rect = None
        self._eye_rect = None
        self._dirty = True
        self._size = None

    # -- the screen interface -------------------------------------------

    def invalidate(self):
        self._dirty = True

    def needs_render(self, now):
        return self._dirty

    def next_change(self, now):
        if self._repeat:
            return self._repeat
        if self.secret and not self.show and self.text and now - self._typed_at < SHOW_LAST:
            return self._typed_at + SHOW_LAST  # hide the last character again
        return now + 2.0

    def tick(self, now):
        if self._repeat and now >= self._repeat and self._pressed == "del":
            self._delete()
            self._repeated = True
            self._repeat = now + 0.08
        if self.secret and not self.show and self.text and self._typed_at and now - self._typed_at >= SHOW_LAST:
            self._typed_at = 0.0
            self._dirty = True

    def on_back(self):
        self.app.close_screen()

    # -- drawing ----------------------------------------------------------

    def render(self, canvas, now):
        self._dirty = False
        g = self.g
        w, h = canvas.get_size()
        self._size = (w, h)
        u = min(w, h) / 600
        canvas.fill(NIGHT)

        head = int(86 * u)
        pygame.draw.rect(canvas, PANEL, (0, 0, w, head))
        pygame.draw.line(canvas, (40, 48, 80), (0, head - 1), (w, head - 1))
        back = g.text("‹ Cancel", 25 * u)
        self._back_rect = pygame.Rect(0, 0, int(back.get_width() + 56 * u), head)
        canvas.blit(back, (int(22 * u), int((head - back.get_height()) / 2)))
        blit_text(canvas, g, self.title, 27 * u, w / 2 + self._back_rect.w / 4, head / 2, bold=True, anchor="mc")

        sideways = w > h * 1.2
        margin = 22 * u
        y = head + (16 if sideways else 26) * u
        if self.prompt:
            size = 19 * u
            lines = g.wrap(self.prompt, size, w - 2 * margin)[:2 if sideways else 4]
            for line in lines:
                blit_text(canvas, g, line, size, margin, y, opacity=0.75)
                y += size * 1.3
            y += 10 * u

        # The text box.
        fh = (62 if sideways else 74) * u
        field = pygame.Rect(int(margin), int(y), int(w - 2 * margin), int(fh))
        pygame.draw.rect(canvas, FIELD, field, border_radius=int(14 * u))
        pygame.draw.rect(canvas, lerp(NIGHT, WHITE, 0.35), field, width=max(1, int(2 * u)), border_radius=int(14 * u))
        right = field.right - 18 * u
        self._eye_rect = None
        if self.secret:
            label = "Hide" if self.show else "Show"
            lw = g.text_size(label, 21 * u)[0]
            self._eye_rect = pygame.Rect(int(field.right - lw - 40 * u), field.y, int(lw + 40 * u), field.h)
            blit_text(canvas, g, label, 21 * u, self._eye_rect.centerx, field.centery + 1 * u, anchor="mc",
                      color=(0x8B, 0xC7, 0x9A))
            right = self._eye_rect.x - 6 * u
        shown = self._shown_text(now)
        size = 30 * u
        tx = field.x + 18 * u
        room = right - tx - 6 * u
        while shown and g.text_size(shown, size)[0] > room:
            shown = shown[1:]  # keep the end in view
        if shown:
            r = blit_text(canvas, g, shown, size, tx, field.centery + 1 * u, anchor="ml")
            cx = r.right + 3 * u
        else:
            cx = tx
        pygame.draw.rect(canvas, WHITE, (int(cx), int(field.centery - size * 0.45), max(2, int(2 * u)), int(size * 0.9)))
        y = field.bottom + 10 * u
        note = self.error or ("%d characters" % len(self.text) if self.secret and self.text else "")
        if note:
            blit_text(canvas, g, note, 19 * u, margin, y, color=ERROR if self.error else WHITE,
                      opacity=1.0 if self.error else 0.55)
        y += 19 * u * 1.3 + 8 * u

        # The keys, as big as fit below.
        rows = _SYMBOL_ROWS if self.symbols else _LETTER_ROWS
        gap = (7 if sideways else 8) * u
        bottom = h - 12 * u
        kh = min(88 * u, (bottom - y - gap * (len(rows) - 1)) / len(rows))
        kw = (w - 2 * 10 * u - gap * 9) / 10.0
        top = bottom - len(rows) * kh - (len(rows) - 1) * gap
        self._keys = []
        for i, keys in enumerate(rows):
            units = sum(k[2] for k in keys)
            row_w = units * kw + (len(keys) - 1) * gap + (units - len(keys)) * gap
            x = (w - row_w) / 2
            ky = top + i * (kh + gap)
            for label, action, width in keys:
                kwid = width * kw + (width - 1) * gap
                rect = pygame.Rect(int(x), int(ky), int(kwid), int(kh))
                self._draw_key(canvas, rect, label, action, u)
                self._keys.append((rect, action))
                x += kwid + gap
        return [canvas.get_rect()]

    def _shown_text(self, now):
        if not self.secret or self.show:
            return self.text
        if not self.text:
            return ""
        if self._typed_at and now - self._typed_at < SHOW_LAST:
            return "•" * (len(self.text) - 1) + self.text[-1]
        return "•" * len(self.text)

    def _draw_key(self, c, rect, label, action, u):
        g = self.g
        special = len(action) > 1
        fill = KEY_SPECIAL if special else KEY
        if action == "done":
            fill = ACCENT
        if action == "shift" and (self.shift or self.caps):
            fill = lerp(KEY, WHITE, 0.35)
        if action == self._pressed:
            fill = KEY_DOWN if action != "done" else lerp(ACCENT, WHITE, 0.3)
        pygame.draw.rect(c, fill, rect, border_radius=int(10 * u))
        cx, cy = rect.centerx, rect.centery
        if action == "shift":
            a = rect.h * 0.22
            pts = [(cx, cy - a * 1.1), (cx + a, cy), (cx + a * 0.45, cy), (cx + a * 0.45, cy + a * 0.9),
                   (cx - a * 0.45, cy + a * 0.9), (cx - a * 0.45, cy), (cx - a, cy)]
            pygame.draw.polygon(c, WHITE, pts, 0 if (self.shift or self.caps) else max(2, int(2 * u)))
            if self.caps:
                pygame.draw.rect(c, WHITE, (int(cx - a * 0.6), int(cy + a * 1.2), int(a * 1.2), max(2, int(3 * u))))
            return
        if action == "del":
            a = rect.h * 0.2
            pts = [(cx - a * 1.6, cy), (cx - a * 0.7, cy - a), (cx + a * 1.4, cy - a), (cx + a * 1.4, cy + a),
                   (cx - a * 0.7, cy + a)]
            pygame.draw.polygon(c, WHITE, pts, max(2, int(2 * u)))
            s = a * 0.45
            t = max(2, int(2 * u))
            pygame.draw.line(c, WHITE, (cx + 0.35 * a - s, cy - s), (cx + 0.35 * a + s, cy + s), t)
            pygame.draw.line(c, WHITE, (cx + 0.35 * a - s, cy + s), (cx + 0.35 * a + s, cy - s), t)
            return
        if action == " ":
            label = "space"
        elif action == "done":
            label = self.done_label
        elif not special and (self.shift or self.caps) and not self.symbols:
            label = label.upper()
        size = (rect.h * 0.4) if not special else min(rect.h * 0.32, 24 * u)
        while g.text_size(label, size)[0] > rect.w - 10 * u and size > 12 * u:
            size -= 1
        blit_text(c, g, label, size, cx, cy + 1 * u, anchor="mc", bold=action == "done")

    # -- touch ------------------------------------------------------------

    def _key_at(self, x, y):
        for rect, action in self._keys:
            if rect.inflate(4, 4).collidepoint(x, y):
                return action
        return None

    def on_touch(self, kind, x, y, now):
        if self._size is None:
            return
        if kind == "down":
            self._down_on = None
            self._repeated = False
            if self._back_rect and self._back_rect.collidepoint(x, y):
                self._down_on = "back"
                return
            if self._eye_rect and self._eye_rect.collidepoint(x, y):
                self._down_on = "eye"
                return
            self._pressed = self._key_at(x, y)
            if self._pressed == "del":
                self._delete()
                self._repeated = True
                self._repeat = now + 0.5
            self._dirty = True
            return
        if kind == "move":
            if self._down_on:
                return
            key = self._key_at(x, y)
            if key != self._pressed:
                if self._pressed == "del":
                    self._repeat = None
                self._pressed = key
                self._dirty = True
            return
        if kind == "up":
            down_on, self._down_on = self._down_on, None
            key, self._pressed = self._pressed, None
            self._repeat = None
            self._dirty = True
            if down_on == "back":
                if self._back_rect.collidepoint(x, y):
                    self.on_back()
                return
            if down_on == "eye":
                if self._eye_rect.collidepoint(x, y):
                    self.show = not self.show
                return
            if key is None or (key == "del" and self._repeated):
                return
            self.press(key, now)

    def press(self, action, now=None):
        """What a key does (also used by the tests)."""
        now = time.time() if now is None else now
        self._dirty = True
        if action == "shift":
            if self.caps:
                self.caps = self.shift = False
            elif self.shift and now - self._shift_at < 0.6:
                self.caps, self.shift = True, False
            else:
                self.shift = not self.shift
            self._shift_at = now
        elif action == "mode":
            self.symbols = not self.symbols
        elif action == "del":
            self._delete()
        elif action == "done":
            self._done()
        else:
            ch = action.upper() if (self.shift or self.caps) and not self.symbols else action
            if len(self.text) >= self.max_len:
                self.error = "That's as long as it can be."
                return
            self.text += ch
            self.error = ""
            self._typed_at = now
            if self.shift and not self.caps:
                self.shift = False

    def _delete(self):
        if self.text:
            self.text = self.text[:-1]
            self._typed_at = 0.0
        self.error = ""
        self._dirty = True

    def _done(self):
        problem = self.check(self.text) if self.check else ""
        if problem:
            self.error = problem
            return
        text = self.text
        self.app.close_screen()
        self.on_done(text)
