"""Settings > Wi-Fi on the touch screen: the networks the Pi can see, and
joining one (with the on-screen keyboard for its password)."""

import time

from ..wifi import check_name, check_password, key_mgmt
from .display import format_clock
from .keyboard import KeyboardScreen
from .lists import ListScreen, row

GOOD = (0x8B, 0xC7, 0x9A)
BAD = (0xF0, 0xA8, 0xA8)


def status_line(wifi, net=None):
    """(label, sub) for where the Wi-Fi is now."""
    st = wifi.status if wifi is not None else {}
    if wifi is not None and wifi.joining:
        return "Joining %s..." % wifi.joining, "This can take up to a minute."
    if st.get("ssid"):
        parts = []
        if st.get("signal") is not None:
            parts.append("Signal %d%%" % st["signal"])
        if st.get("address"):
            parts.append("address %s" % st["address"])
        if net is not None and net.online is False:
            parts.append("but the router isn't answering")
        return "Connected to %s" % st["ssid"], " · ".join(parts)
    why = net.diagnosis if (net is not None and net.online is False and net.diagnosis) else ""
    return "Not connected", (why + " " if why else "") + "Choose a network below."


class WifiScreen(ListScreen):
    title = "Wi-Fi"

    def __init__(self, app):
        super().__init__(app)
        self.wifi = app.wifi
        if self.wifi is not None and self.wifi.available():
            if time.time() - self.wifi.scanned_at > 15:
                self.wifi.scan()
            else:
                self.wifi.refresh_status(5)

    def needs_render(self, now):
        busy = self.wifi is not None and (self.wifi.scanning or self.wifi.joining)
        return super().needs_render(now) or (busy and self._touch is None and now - self._last_render > 1)

    def rows(self):
        app = self.app
        w = self.wifi
        if w is None or not w.available():
            return [row("section", "Wi-Fi"),
                    row("info", "Can't change the Wi-Fi here",
                        sub="TideView changes the Wi-Fi through NetworkManager, which Raspberry Pi OS has "
                            "had since 2023 (Bookworm). On this system, use the Raspberry Pi Imager instead.")]
        label, sub = status_line(w, app.net)
        out = [row("section", "Now"), row("info", label, sub=sub)]
        res = w.recent_result()
        if res and not w.joining:
            out.append(row("info", ("Joined %s" if res["ok"] else "Couldn't join %s") % res["ssid"],
                           sub=res["message"], label_color=GOOD if res["ok"] else BAD))

        out.append(row("section", "Networks the Pi can see"))
        if not w.networks:
            if w.scanning:
                out.append(row("info", "Looking for networks...", sub="This takes about ten seconds."))
            elif w.scan_error:
                out.append(row("info", "Couldn't look for networks", sub=w.scan_error))
            else:
                out.append(row("info", "None found", sub="Tap Look again. If nothing ever shows up, the Pi's "
                               "Wi-Fi chip may have stopped: restarting the Pi usually brings it back."))
        for n in w.networks:
            value = "Connected" if n.active else ("Joining" if w.joining == n.ssid else "")
            out.append(row("nav", n.ssid, value=value, sub=n.sub(), on_tap=lambda n=n: self._pick(n)))
        use24 = app.settings["use24h"]
        when = ("Last looked at %s." % format_clock(w.scanned_at, use24)) if w.scanned_at else None
        out += [row("nav", "Looking..." if w.scanning else "Look again", sub=when, on_tap=w.scan),
                row("nav", "Join a hidden network",
                    sub="One that doesn't show its name. You type its name and password.", on_tap=self._hidden),
                row("info", "Good to know",
                    sub="The Pi Zero only has 2.4 GHz Wi-Fi, so 5 GHz networks never show up here. A network "
                        "joined here is tried first from now on; the networks saved before are kept.")]
        return out

    def _pick(self, n):
        app = self.app
        w = self.wifi
        if w.joining:
            app.show_message("Wait a moment: the Pi is still joining %s." % w.joining, 5)
            return
        if n.active:
            app.show_message("The Pi is already on %s." % n.ssid, 5)
            return
        if key_mgmt(n.security) == "":
            app.show_message("%s needs a username as well as a password (work-style Wi-Fi). TideView can't "
                             "join networks like that." % n.ssid, 8)
            return
        if w.needs_password(n.ssid):
            app.push(KeyboardScreen(
                app, "Wi-Fi password", on_done=lambda pw: w.join(n.ssid, pw), secret=True, check=check_password,
                done_label="Join",
                prompt="For %s. Capitals matter. It's often on a sticker on the router." % n.ssid))
        else:
            w.join(n.ssid, None)
        self.scroll = 0

    def _hidden(self):
        app = self.app
        w = self.wifi

        def got_name(name):
            app.push(KeyboardScreen(
                app, "Wi-Fi password", on_done=lambda pw: w.join(name, pw or None, hidden=True), secret=True,
                check=lambda t: check_password(t, required=False), done_label="Join",
                prompt="For %s. Leave it empty if the network has no password." % name))
        app.push(KeyboardScreen(app, "Network name", on_done=got_name, check=check_name, done_label="Next",
                                max_len=32,
                                prompt="Exactly as it's set on the router. Capitals and spaces matter."))
