"""User choices, saved as JSON on the Pi, and the API keys.

Settings live in the state folder (/var/lib/tideview when running as the
service). You can also edit settings.json there by hand while TideView is
stopped.
"""

import json
import os
import threading

from .beaches import DEFAULT_BEACH_ID, beach_by_id
from .screenpower import SWITCH_PINS

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEFAULTS = {
    "beach": DEFAULT_BEACH_ID,
    "unit": "ft",  # "ft" or "m"
    "use24h": False,
    "windInKnots": False,  # wind in knots (as MetService's surf pages use) instead of km/h
    # Score and show the wind measured at the nearest airport (when there's a
    # recent reading) instead of the forecast wind. Off, the numbers match
    # MetService's surf page; the airport reading is shown under the wind.
    "useMeasuredWind": False,
    "animate": True,  # roll the swell lines
    "waveFps": 8,  # most frames per second for the swell lines (it slows itself down if the Pi is busy)
    "showRating": True,  # old name for showScore, kept so older phone apps still read it
    # What's on the main screen: "show", "tap" (shows for a while after a tap) or "hide".
    "showClock": "show",
    "showBeach": "show",
    "showScore": "show",
    "showWeather": "show",
    "showSeaTemp": "show",
    "showSwell": "show",
    "showWind": "show",
    "showTides": "show",
    "showWeek": "show",
    "refreshMinutes": 15,
    # Night: "off" (stays on), "dim" or "black" (a black picture). Older
    # versions also had "screenOff" (HDMI signal off), which made the Jaycar
    # screen show a blue "No Signal" box all night; it now means "black".
    "nightMode": "off",
    "nightStart": 22 * 60,  # minutes after midnight
    "dayStart": 6 * 60,
    "dimLevel": 0.6,  # how much darker "dim" makes the picture
    # A relay (or MOSFET) in the screen's 5 V wire, switched by this GPIO pin
    # (BCM number: 17, 27 or 22), cuts the screen's power at night. null:
    # none. "screenSwitchOff" is the pin's level that turns the screen off.
    "screenSwitchPin": None,
    "screenSwitchOff": "high",
    # How the picture sits on the panel: "upright", "upright-flipped",
    # "sideways" or "sideways-flipped". The Jaycar 7" panel is sideways.
    "orientation": "upright",
    # Frame (developer): shrink and move the picture to fit a frame's window.
    # Sizes in millimetres; null until first set.
    "frameEnabled": False,
    "frameInCm": False,
    "frameLeftMm": None,
    "frameTopMm": None,
    "frameWidthMm": None,
    "frameHeightMm": None,
    "screenDiagonalIn": 7.0,
    # Touch fixes for panels whose touch doesn't line up with the picture.
    "touchSwapXY": False,
    "touchInvertX": False,
    "touchInvertY": False,
    # False until the first set-up is done (a phone linked, or a beach chosen
    # on the screen). Units set up before this setting existed count as done.
    "setupDone": False,
}

REFRESH_CHOICES = [10, 15, 30, 60, 120]
NIGHT_MODES = ["off", "dim", "black"]
VISIBILITY = ["show", "tap", "hide"]
# The parts of the main screen that can be shown, hidden or shown on a tap:
# (setting, name on the settings page).
ELEMENTS = [
    ("showClock", "Clock"),
    ("showBeach", "Beach name"),
    ("showScore", "Surf score"),
    ("showWeather", "Weather"),
    ("showSeaTemp", "Sea temperature"),
    ("showSwell", "Swell"),
    ("showWind", "Wind"),
    ("showTides", "Tides"),
    ("showWeek", "Week ahead"),
]
ORIENTATIONS = ["upright", "sideways", "upright-flipped", "sideways-flipped"]

# Panel rotation (degrees clockwise) for each orientation. The panel itself
# is landscape, so "upright" turns the picture a quarter turn.
ROTATION = {"sideways": 0, "upright": 90, "sideways-flipped": 180, "upright-flipped": 270}


def state_dir():
    """Where settings and the forecast cache are written."""
    # systemd sets STATE_DIRECTORY (a list split by colons) for the service.
    d = os.environ.get("STATE_DIRECTORY", "").split(":")[0] or os.environ.get("TIDEVIEW_STATE")
    if not d:
        if os.name == "nt":  # trying it on a Windows PC
            d = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TideView")
        elif os.geteuid() == 0:
            d = "/var/lib/tideview"
        else:
            d = os.path.expanduser("~/.local/state/tideview")
    os.makedirs(d, exist_ok=True)
    return d


class Settings:
    def __init__(self, path=None):
        self.path = path or os.path.join(state_dir(), "settings.json")
        self._data = dict(DEFAULTS)
        self._lock = threading.Lock()
        self.version = 0  # bumped on every change
        saved = None
        try:
            with open(self.path, encoding="utf-8") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                self._data.update({k: v for k, v in saved.items() if k in DEFAULTS})
            else:
                saved = None
        except (OSError, ValueError):
            pass
        if saved is not None:
            # Settings saved by an older version: that unit is already set up,
            # and its "show the score" switch becomes the new three-way choice.
            if "setupDone" not in saved:
                self._data["setupDone"] = True
            if "showScore" not in saved and "showRating" in saved:
                self._data["showScore"] = "show" if saved.get("showRating") else "hide"
        if self._data.get("refreshMinutes") not in REFRESH_CHOICES:
            self._data["refreshMinutes"] = 15
        if self._data.get("nightMode") == "screenOff":
            self._data["nightMode"] = "black"
        if self._data.get("nightMode") not in NIGHT_MODES:
            self._data["nightMode"] = "off"
        for key, _name in ELEMENTS:
            if self._data.get(key) not in VISIBILITY:
                self._data[key] = "show"
        if self._data.get("orientation") not in ORIENTATIONS:
            self._data["orientation"] = "upright"
        if self._data.get("screenSwitchPin") not in SWITCH_PINS:
            self._data["screenSwitchPin"] = None
        if self._data.get("screenSwitchOff") not in ("high", "low"):
            self._data["screenSwitchOff"] = "high"

    def __getitem__(self, key):
        return self._data[key]

    def get(self, key, default=None):
        return self._data.get(key, default)

    def set(self, **values):
        changed = False
        with self._lock:
            for k, v in values.items():
                if k not in DEFAULTS:
                    raise KeyError(k)
                if self._data.get(k) != v:
                    self._data[k] = v
                    changed = True
            if changed:
                self.version += 1
                self._save()

    def _save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        except OSError:
            pass

    def visibility(self, key):
        """"show", "tap" or "hide" for one part of the main screen."""
        v = self._data.get(key)
        return v if v in VISIBILITY else "show"

    @property
    def beach(self):
        return beach_by_id(self._data["beach"])

    @property
    def rotation(self):
        return ROTATION.get(self._data["orientation"], 90)


def _read_env_file(path):
    """KEY=VALUE lines. Copes with Windows Notepad files (BOM, CRLF) and
    quotes around values."""
    out = {}
    try:
        with open(path, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                if k.lower().startswith("export "):
                    k = k[7:].strip()
                v = v.strip().strip('"').strip("'").strip()
                out[k] = v
    except OSError:
        pass
    return out


KEY_FILES = (".env.txt", ".env", "keys.txt", "keys.txt.txt")  # Windows hides extensions
BOOT_DIRS = ("/boot/firmware", "/boot")  # the SD card's bootfs, on the Pi


def load_keys():
    """API keys from the environment or a key file (the same .env.txt the
    Android build uses): next to the app, in the tideview folder on the SD
    card, or the copy install.sh keeps in the state folder. Missing keys are
    empty strings: TideView then uses the free, keyless sources."""
    found = {}
    candidates = [os.path.join(APP_DIR, n) for n in KEY_FILES]
    for boot in BOOT_DIRS:
        candidates += [os.path.join(boot, "tideview", n) for n in KEY_FILES]
        candidates.append(os.path.join(boot, ".env.txt"))
    candidates.append(os.path.join(state_dir(), "keys.env"))
    for path in candidates:
        for k, v in _read_env_file(path).items():
            if v and k not in found:
                found[k] = v
    return {
        "niwa": os.environ.get("NIWA_API_KEY") or found.get("NIWA_API_KEY", ""),
        "metocean": os.environ.get("METOCEAN_API_KEY") or found.get("METOCEAN_API_KEY", ""),
    }
