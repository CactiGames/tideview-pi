"""TideView for Raspberry Pi: ties the data, the screens, the touch panel and
the display together, and runs the main loop."""

import logging
import os
import queue
import signal
import threading
import time

import pygame

from . import settings as settings_mod
from . import updates
from .controller import ForecastController
from .night import NightController
from .output import FramebufferOutput, ImageOutput, WindowOutput, logical_size, to_logical_point
from .ui.display import DisplayScreen
from .ui.frame import FrameGeometry
from .ui.gfx import NIGHT, Gfx, blit_text
from .ui.lists import RegionPicker
from .ui.settings_screen import SettingsScreen
from .ui.setup import PairScreen, SplashScreen, WelcomeScreen


log = logging.getLogger("tideview")

TAP_SLOP = 0.05  # how far (share of the short side) a finger may slide and still tap
REPORT_AFTER_OFFLINE = 5 * 60  # seconds without Wi-Fi before a report goes on the SD card
REPORTS_PER_START = 4
IDLE_HOME = 10 * 60  # seconds without a touch before Settings (or the keyboard) goes back to the forecast


class App:
    def __init__(self, output, settings, keys, forecast=None, touch=None, panel_size=None, splash=False,
                 screen_power=None):
        self.log = log
        self.settings = settings
        self.keys = keys
        self.output = output
        self.touch = touch
        self.gfx = Gfx()
        self.night = NightController(settings)
        self.panel_size = panel_size or (output.size if output.rotation in (0, 180) else output.size[::-1])
        self.frame_geometry = FrameGeometry(settings, self.panel_size)
        cache = os.path.join(settings_mod.state_dir(), "forecast-cache.json")
        self.forecast = forecast or ForecastController(settings.beach, keys, settings["refreshMinutes"], cache)
        self.events = touch.events if touch is not None else queue.Queue()
        self.screen_size = output.size
        self.frame = pygame.Surface(self.screen_size, 0, 32)
        self.frame.fill((0, 0, 0))
        self.display = DisplayScreen(self)
        self.stack = [self.display]
        self.frame_guide_until = 0.0  # outline the picture's edges until then (while it's being moved)
        self._splash_saved = False  # the power-on logo (tv.bootlook) is saved from the first splash
        self._box = None
        self._seen = (None, None)  # (settings version, forecast version)
        self._next_render = 0.0
        self._next_night = 0.0
        self._full_present = True
        self._press = None
        self._quit = False
        self.exit_code = 0
        self._message = None
        self._anim_cost = None
        self._last_anim = 0.0
        self._applied = {"beach": settings["beach"], "refresh": settings["refreshMinutes"],
                         "rotation": settings.rotation}
        self._started = time.monotonic()
        self._last_touch = time.monotonic()
        self._proved = False  # told the updater this version works
        self._calls = queue.Queue()  # work from the phone server, run on this thread
        self._auto_reports = 0
        self._reported_spell = False  # saved a report during this spell without Wi-Fi
        self._next_report_check = 0.0
        self.net = None
        self.remote = None
        self.wifi = None
        try:
            from .remote import Remote
            self.remote = Remote(self)
        except Exception:  # noqa: BLE001  (phone control is optional; the display isn't)
            log.exception("phone control is off")
        try:
            from .wifi import WifiManager
            self.wifi = WifiManager(on_change=self._wifi_changed)
        except Exception:  # noqa: BLE001
            log.exception("Wi-Fi settings are off")
        # Start-up: the logo over rolling water (not at night: an update at
        # 3 AM shouldn't light up the room), then the welcome if this unit
        # hasn't been set up yet.
        dark = settings["nightMode"] != "off" and self.night.in_night_window(time.time())
        # The screen's own off switch (its backlight over DDC/CI, or a power
        # switch on a GPIO pin): only on the Pi's own screen.
        self.screen_power = screen_power
        if screen_power is None and output.kind == "framebuffer":
            try:
                from .screenpower import ScreenPower
                self.screen_power = ScreenPower(settings, settings_mod.state_dir(), output=output, touch=touch)
            except Exception:  # noqa: BLE001  (the display works without it)
                log.exception("screen power control is off")
        if self.screen_power is not None:
            self.screen_power.request(dark and settings["nightMode"] == "black")
        note = updates.announcement(time.time())
        self._pending_note = note if dark else None  # "TideView updated" waits for the morning
        if note and not dark:
            self.show_message(note, 12)
        if splash and not dark:
            self.stack.append(SplashScreen(self))
        elif not settings["setupDone"]:
            self.stack.append(WelcomeScreen(self))

    # -- navigation ---------------------------------------------------------

    @property
    def screen(self):
        return self.stack[-1]

    def push(self, screen):
        self.stack.append(screen)
        self._screen_changed()

    def close_screen(self):
        if len(self.stack) > 1:
            self.stack.pop()
        self._screen_changed()

    def open(self, key):
        if key == "beach":
            self.push(RegionPicker(self))
        elif key == "settings":
            self.push(SettingsScreen(self))
        elif key == "wifi":
            from .ui.wifi_screen import WifiScreen
            self.push(WifiScreen(self))
        elif key == "pair":
            if not isinstance(self.screen, PairScreen):
                self.push(PairScreen(self))

    def choose_beach(self, beach, from_phone=False):
        self.settings.set(beach=beach.id)
        self.forecast.set_beach(beach)
        self._applied["beach"] = beach.id
        if not self.settings["setupDone"]:
            self.finish_setup()
            return
        if not from_phone:
            del self.stack[1:]
        self._screen_changed()

    def home(self):
        """Back to the main screen."""
        del self.stack[1:]
        self._screen_changed()

    def splash_done(self):
        """The start-up splash has had its moment."""
        self.stack = [s for s in self.stack if not isinstance(s, SplashScreen)]
        if not self.settings["setupDone"] and not any(isinstance(s, WelcomeScreen) for s in self.stack):
            self.stack.append(WelcomeScreen(self))
        self._screen_changed()

    def finish_setup(self):
        """First-run set-up is done (a phone linked, a beach chosen here, or
        Skip): on to the forecast."""
        if not self.settings["setupDone"]:
            self.settings.set(setupDone=True)
        self.home()

    def phone_linked(self, name):
        """A new phone has the code (from the phone server, on this thread)."""
        if not self.settings["setupDone"]:
            self.settings.set(setupDone=True)
        if any(isinstance(s, (WelcomeScreen, PairScreen)) for s in self.stack):
            self.home()
        self.show_message("Linked to %s" % name, 6)
        self.frame_changed()

    def show_frame_guide(self, seconds=6.0):
        """Outlines the picture's edges for a few seconds (while a phone
        moves it to fit a frame)."""
        self.frame_guide_until = time.time() + seconds
        self.display.invalidate()
        self.frame_changed()

    def call_soon(self, fn, timeout=10.0):
        """Runs fn on the main loop's thread and returns what it returns.
        For the phone server's threads; raises TimeoutError if the loop
        doesn't get to it in time."""
        box = {"done": threading.Event()}
        self._calls.put((fn, box))
        if self.output.kind != "window":
            self.events.put(("wake", 0.0, 0.0))  # stop waiting for a touch
        if not box["done"].wait(timeout):
            raise TimeoutError("the main loop is busy")
        if "error" in box:
            raise box["error"]
        return box.get("result")

    def post(self, fn):
        """Runs fn on the main loop's thread soon, without waiting for it.
        For threads that finish work the screen should show."""
        self._calls.put((fn, {"done": threading.Event(), "posted": True}))
        self.wake()

    def wake(self):
        """From any thread: have the main loop look again now."""
        self._next_render = 0
        if self.output.kind != "window":
            self.events.put(("wake", 0.0, 0.0))

    def _wifi_changed(self):
        """A Wi-Fi scan or join moved on (on its own thread)."""
        def refresh():
            for scr in self.stack:
                scr.invalidate()
            if self.net is not None:
                self.net.poke()
        self.post(refresh)

    def _run_calls(self):
        while True:
            try:
                fn, box = self._calls.get_nowait()
            except queue.Empty:
                return
            try:
                box["result"] = fn()
            except Exception as e:  # noqa: BLE001
                box["error"] = e
                if box.get("posted"):  # nobody is waiting to hear about it
                    log.exception("a job from another thread failed")
            finally:
                box["done"].set()
            self._next_render = 0

    def frame_changed(self):
        self._box = None
        self._full_present = True
        self._next_render = 0

    def _screen_changed(self):
        self._box = None
        self._full_present = True
        self._next_render = 0
        self._next_night = 0
        for s in self.stack:
            s.invalidate()

    def request_restart(self):
        self.exit_code = 3
        self._quit = True

    def quit(self):
        self._quit = True

    def show_message(self, text, seconds=30):
        self._message = (text, time.time() + seconds)
        self._next_render = 0

    def touch_names(self):
        if self.touch is None:
            return ["mouse (window mode)"] if self.output.kind == "window" else []
        return self.touch.device_names()

    # -- geometry -------------------------------------------------------------

    def box(self):
        """Where the current screen is drawn: the frame box, or everything."""
        if getattr(self.screen, "full_screen", False) or not self.settings["frameEnabled"]:
            return pygame.Rect((0, 0), self.screen_size)
        return self.frame_geometry.box(self.screen_size)

    def _apply_settings(self):
        s = self.settings
        if s["beach"] != self._applied["beach"]:
            self._applied["beach"] = s["beach"]
            self.forecast.set_beach(s.beach)
        if s["refreshMinutes"] != self._applied["refresh"]:
            self._applied["refresh"] = s["refreshMinutes"]
            self.forecast.set_interval(s["refreshMinutes"])
        if s.rotation != self._applied["rotation"]:
            self._applied["rotation"] = s.rotation
            self.output.set_rotation(s.rotation)
            size = logical_size(self.panel_size[0], self.panel_size[1], s.rotation)
            if hasattr(self.output, "resize"):
                self.output.resize(size)
            else:
                self.output.size = size
            self.screen_size = size
            self.frame = pygame.Surface(size, 0, 32)
            self.frame.fill((0, 0, 0))
            self._screen_changed()
        if self.screen_power is not None:
            self.screen_power.refresh()  # a power switch may have been set up
        self._box = None
        self._full_present = True
        self._next_night = 0
        self._next_render = 0
        for scr in self.stack:
            scr.invalidate()

    # -- input ----------------------------------------------------------------

    def _panel_to_screen(self, u, v):
        s = self.settings
        if s["touchSwapXY"]:
            u, v = v, u
        if s["touchInvertX"]:
            u = 1 - u
        if s["touchInvertY"]:
            v = 1 - v
        pw, ph = self.panel_size
        lw, lh = self.screen_size
        return to_logical_point(u * (pw - 1), v * (ph - 1), self.output.rotation, lw, lh)

    def _gather_input(self, timeout):
        """Waits up to timeout seconds for input; returns (kind, x, y) in
        screen coordinates."""
        out = []
        if self.output.kind == "window":
            deadline = time.time() + timeout
            while True:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        self._quit = True
                    elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                        out.append(("down",) + self.output.to_picture(e.pos))
                    elif e.type == pygame.MOUSEMOTION and e.buttons[0]:
                        out.append(("move",) + self.output.to_picture(e.pos))
                    elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                        out.append(("up",) + self.output.to_picture(e.pos))
                    elif e.type == pygame.MOUSEWHEEL and hasattr(self.screen, "scroll"):
                        self.screen.scroll -= e.y * 60
                        self.screen.invalidate()
                        self._next_render = 0
                    elif e.type == pygame.KEYDOWN:
                        if e.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                            if len(self.stack) > 1:
                                self.close_screen()
                            elif e.key == pygame.K_ESCAPE:
                                self._quit = True
                        elif e.key == pygame.K_q:
                            self._quit = True
                        elif e.key == pygame.K_r:
                            self.forecast.refresh()
                if out or self._quit or time.time() >= deadline:
                    return out
                time.sleep(min(0.01, max(0.0, deadline - time.time())))
        try:
            ev = self.events.get(timeout=max(0.0, timeout))
            while True:
                kind, u, v = ev
                if kind != "wake":  # just a nudge from the phone server
                    x, y = self._panel_to_screen(u, v)
                    out.append((kind, x, y))
                ev = self.events.get_nowait()
        except queue.Empty:
            pass
        return out

    def _dispatch(self, kind, x, y, now):
        self._last_touch = time.monotonic()
        box = self._box or self.box()
        scr = self.screen
        lx, ly = x - box.x, y - box.y
        short = min(self.screen_size)
        if scr is self.display:
            # The display only needs taps.
            if kind == "down":
                self._press = (x, y, now)
            elif kind == "up" and self._press:
                px, py, _t = self._press
                self._press = None
                if abs(x - px) < short * TAP_SLOP and abs(y - py) < short * TAP_SLOP:
                    self.display.on_tap(lx, ly, now)
                    self._next_night = 0
            self._next_render = 0
            return
        if kind == "down" and not box.collidepoint(x, y):
            return
        scr.on_touch(kind, lx, ly, now)
        self._next_render = 0

    # -- main loop ------------------------------------------------------------

    def run(self):
        signal.signal(signal.SIGTERM, lambda *_: self.quit())  # systemctl stop
        signal.signal(signal.SIGINT, lambda *_: self.quit())  # Ctrl+C in a terminal
        try:
            # Older versions turned the HDMI signal off at night and may have
            # left it off when they restarted for this update.
            self.output.blank(False)
        except Exception:  # noqa: BLE001
            pass
        self.forecast.start()
        if self.touch is not None:
            self.touch.start()
        if self.screen_power is not None:
            try:
                self.screen_power.start()
            except Exception:  # noqa: BLE001
                log.exception("screen power control couldn't start")
        self._start_helpers()
        try:
            while not self._quit:
                self.step()
        finally:
            self.forecast.stop()
            if self.touch is not None:
                self.touch.stop()
            # A dark screen stays dark: restarting for an update at 3 AM
            # shouldn't light up the room.
            for helper in (self.remote, self.net, self.screen_power):
                if helper is not None:
                    try:
                        helper.stop()
                    except Exception:  # noqa: BLE001
                        pass
            # Leave a dark screen dark, so restarting for an update at 3 AM
            # doesn't light up the room with the text console.
            self.output.close(keep_dark=self.night.state != "day")
        return self.exit_code

    def _start_helpers(self):
        """Phone control and the Wi-Fi watch. Neither may stop the display."""
        if self.remote is not None:
            try:
                self.remote.start()
            except Exception:  # noqa: BLE001
                log.exception("phone control couldn't start")
        try:
            from .netwatch import NetWatch
            self.net = NetWatch()
            self.net.start()
        except Exception:  # noqa: BLE001
            log.exception("the Wi-Fi watch couldn't start")
            self.net = None

    def step(self, now=None, wait=True):
        """One pass of the loop: input, state, drawing."""
        wait_for = max(0.0, self._next_render - time.time()) if wait else 0.0
        for kind, x, y in self._gather_input(min(wait_for, 0.5) if wait else 0.0):
            self._dispatch(kind, x, y, time.time())
        self._run_calls()
        now = time.time() if now is None else now
        if not self._proved and time.monotonic() - self._started >= updates.PROVE_AFTER:
            self._proved = True
            updates.mark_working()

        key = (self.settings.version, self.forecast.version)
        if key != self._seen:
            settings_changed = key[0] != self._seen[0]
            self._seen = key
            if settings_changed:
                self._apply_settings()
            self.display.invalidate()
            for scr in self.stack[1:]:
                scr.invalidate()
            self._next_render = 0

        if now >= self._next_night:
            self._next_night = now + 10
            on_display = self.screen is self.display
            changed = self.night.evaluate(now) if on_display else False
            if not on_display and self.night.state != "day":
                self.night.state = "day"
                changed = True
            soon = self.night.next_change(now)  # the end of a test, or of a tap's minute
            if soon is not None:
                self._next_night = min(self._next_night, soon + 0.05)
            if self.screen_power is not None:
                self.screen_power.request(self.night.state == "black")
            if changed:
                self.display.invalidate()
                self._next_render = 0
                if self.night.state == "day" and self._pending_note:
                    self.show_message(self._pending_note, 12)
                    self._pending_note = None

        if now >= self._next_report_check:
            self._next_report_check = now + 15
            self._auto_report()
            if len(self.stack) > 1 and time.monotonic() - self._last_touch > IDLE_HOME \
                    and self.settings["setupDone"] and not isinstance(self.stack[1], SplashScreen):
                log.info("nobody has touched the screen for %d minutes: back to the forecast", IDLE_HOME // 60)
                self.home()
            if not self.settings["setupDone"] and self.screen is self.display:
                self.push(WelcomeScreen(self))  # not set up yet: the welcome stays until it is

        if hasattr(self.screen, "tick"):
            self.screen.tick(now)

        if now >= self._next_render or getattr(self.screen, "needs_render", lambda n: False)(now):
            self._render(now)

    def _auto_report(self):
        """Saves a report to the SD card after 5 minutes without Wi-Fi, and
        again when it comes back, so the card shows what happened."""
        net = self.net
        if net is None or not net.fix or self._auto_reports >= REPORTS_PER_START:
            return
        gone = net.offline_for()
        try:
            from . import report
            if gone >= REPORT_AFTER_OFFLINE and not self._reported_spell:
                if report.save_soon(self, "No Wi-Fi for %d minutes" % round(gone / 60), quiet=True):
                    self._reported_spell = True
                    self._auto_reports += 1
            elif net.online and self._reported_spell:
                if report.save_soon(self, "The Wi-Fi came back", quiet=True):
                    self._reported_spell = False
                    self._auto_reports += 1
        except Exception:  # noqa: BLE001
            log.exception("couldn't start a report")
            self._auto_reports = REPORTS_PER_START

    def _render(self, now):
        box = self.box()
        if box != self._box:
            self._box = box
            self.frame.fill((0, 0, 0))
            self._full_present = True
            self.screen.invalidate()
        canvas = self.frame.subsurface(box)
        scr = self.screen
        t0 = time.time()
        if scr is self.display:
            self.display.phase = (now / 45.0) % 1.0  # one roll every 45 seconds
            rects = self.display.render(canvas, now)
            band_frame = bool(rects) and rects[0].size != canvas.get_size()
        else:
            rects = scr.render(canvas, now) if scr.needs_render(now) else []
            band_frame = False
        rects = [r.move(box.x, box.y) for r in rects]
        if self._message:
            text, until = self._message
            if now > until:
                self._message = None
                scr.invalidate()
                self._next_render = 0
            else:
                rects.append(self._draw_message(text))
        if self._full_present:
            self._full_present = False
            rects = [self.frame.get_rect()]
        if rects:
            self.output.present(self.frame, rects)
            if not self._splash_saved and isinstance(scr, SplashScreen) and not self._message:
                self._save_splash(box)
        cost = time.time() - t0
        if band_frame:
            self._anim_cost = cost if self._anim_cost is None else self._anim_cost * 0.9 + cost * 0.1
        self._next_render = self._schedule(now)

    def _save_splash(self, box):
        """Keeps a copy of the splash for tvsplash.py to show at power-on."""
        self._splash_saved = True
        if self.output.kind != "framebuffer":
            return
        try:
            from . import bootlook
            bootlook.save_splash(self.output, os.path.join(settings_mod.state_dir(), "splash.fb"),
                                 [self.settings.rotation, [box.x, box.y, box.w, box.h]])
        except Exception:  # noqa: BLE001
            log.exception("couldn't save the power-on logo")

    def _schedule(self, now):
        scr = self.screen
        nxt = scr.next_change(now)
        if scr is self.display and self.display.animating() and self.night.state == "day":
            fps = float(self.settings["waveFps"])
            if self._anim_cost:
                # Keep the swell lines to about a third of the processor, so a
                # Pi Zero stays cool and responsive.
                fps = min(fps, max(1.0, 0.33 / self._anim_cost))
            nxt = min(nxt, now + 1.0 / fps)
        if self._message:
            nxt = min(nxt, self._message[1])
        return nxt

    def _draw_message(self, text):
        w, h = self.screen_size
        u = min(w, h) / 600
        lines = self.gfx.wrap(text, 24 * u, w * 0.8)
        ph = (len(lines) * 32 + 50) * u
        r = pygame.Rect(int(w * 0.07), int((h - ph) / 2), int(w * 0.86), int(ph))
        pygame.draw.rect(self.frame, NIGHT, r, border_radius=int(18 * u))
        y = r.y + 25 * u
        for line in lines:
            blit_text(self.frame, self.gfx, line, 24 * u, r.centerx, y, anchor="tc")
            y += 32 * u
        return r


def make_output(args, settings):
    rotation = settings.rotation
    if args.screenshot:
        panel = args.size or (1024, 600)
        return ImageOutput(logical_size(panel[0], panel[1], rotation), rotation), panel
    use_fb = not args.window and os.path.exists(args.fb)
    if use_fb:
        out = FramebufferOutput(args.fb, rotation)
        return out, (out.xres, out.yres)
    panel = args.size or (1024, 600)
    return WindowOutput(logical_size(panel[0], panel[1], rotation), rotation), panel
