"""Switching the screen itself off at night.

The Pi Zero W can't cut the power on its USB socket: that socket's 5 V is
joined straight to the Pi's power input, with no switch between them (bigger
Pis have a USB hub chip that can switch it; the Zero has none). The Jaycar
screen takes its power and touch through that socket, so it stays powered,
and turning the HDMI signal off only brings up its blue "No Signal" box.
What can still make it properly dark:

- DDC/CI: many monitor boards take commands over the HDMI cable's DDC wires
  (VESA MCCS): power mode (VCP D6), and backlight or brightness (VCP 13, 6B
  or 10). If this screen answers, night turns its backlight off while the
  HDMI signal stays on.
- A power switch on a GPIO pin: a relay (or MOSFET) in the screen's 5 V
  wire, wired so the screen is on unless the pin turns it off.
- Otherwise the picture goes black: the darkest the Pi can make it alone.

All of this is best effort: a failure is logged and falls back, and never
stops the display. Standard library only, so install.sh can use it on its
own to light the screen back up (light_up()).
"""

import errno
import glob
import json
import logging
import os
import shutil
import subprocess
import threading
import time

log = logging.getLogger("tideview.screen")

I2C_SLAVE = 0x0703
I2C_SLAVE_FORCE = 0x0706
DDC_ADDR = 0x37  # DDC/CI, on the HDMI cable's DDC wires
HOST = 0x51  # the host's source address in a DDC/CI request
VCP_POWER = 0xD6
VCP_BRIGHTNESS = 0x10
VCP_BACKLIGHT = 0x13  # "backlight control" (MCCS 2.0)
VCP_BACKLIGHT_WHITE = 0x6B  # "backlight level: white" (MCCS 2.2)
DIM_CODES = (VCP_BACKLIGHT, VCP_BACKLIGHT_WHITE, VCP_BRIGHTNESS)  # best first
POWER_ON = 0x01
# "DPM off". 0x05 ("power off") can leave a screen deaf to DDC/CI until it's
# unplugged, so it's never sent.
POWER_OFF = 0x04
POWER_DARK = (0x02, 0x03, 0x04, 0x05)  # standby, suspend, off, power off

# The pins Settings offers for a power switch (BCM numbers) and where they
# are on the header. Free on a Pi Zero: nothing TideView uses needs them.
SWITCH_PINS = [17, 27, 22]
HEADER_PIN = {17: 11, 27: 13, 22: 15}

# How "Screen off" works on this screen, best first.
METHODS = ("switch", "ddc", "dim", "picture")
METHOD_LABELS = {
    "switch": "Power cut",
    "ddc": "Backlight off",
    "dim": "Backlight lowest",
    "picture": "Black picture",
}


class DdcError(Exception):
    pass


def _xor(start, data):
    c = start
    for b in data:
        c ^= b
    return c


def get_vcp_request(code):
    body = bytes([HOST, 0x82, 0x01, code])
    return body + bytes([_xor(0x6E, body)])


def set_vcp_request(code, value):
    body = bytes([HOST, 0x84, 0x03, code, (value >> 8) & 0xFF, value & 0xFF])
    return body + bytes([_xor(0x6E, body)])


def parse_vcp_reply(code, reply):
    """(supported, current, maximum) from a Get VCP Feature reply. Raises
    DdcError when it isn't a proper answer to that request."""
    reply = bytes(reply)
    if len(reply) < 3 or reply[0] != 0x6E:
        raise DdcError("no DDC/CI reply")
    length = reply[1] & 0x7F
    if not reply[1] & 0x80 or length == 0:
        raise DdcError("the screen was busy")  # a null message: 6E 80 BE
    if length != 8 or len(reply) < 11:
        raise DdcError("unexpected reply length %d" % length)
    chk = reply[10]
    # The checksum counts the host's "virtual" address 0x50 and the screen's
    # own; some boards leave their own out.
    if chk != _xor(0x50, reply[:10]) and chk != _xor(0x50, reply[1:10]):
        raise DdcError("bad checksum")
    if reply[2] != 0x02 or reply[4] != code:
        raise DdcError("not the reply asked for")
    if reply[3] != 0x00:
        return False, None, None
    return True, (reply[8] << 8) | reply[9], (reply[6] << 8) | reply[7]


def _why(e):
    return getattr(e, "strerror", None) or str(e) or e.__class__.__name__


class DdcBus:
    """DDC/CI over a Linux I2C bus (/dev/i2c-N)."""

    REPLY_WAIT = 0.06  # a screen needs 40 ms before it can answer
    SET_WAIT = 0.06

    def __init__(self, path):
        import fcntl  # not on Windows, where a PC trial still imports this module

        self.path = path
        self.fd = os.open(path, os.O_RDWR)
        try:
            try:
                fcntl.ioctl(self.fd, I2C_SLAVE, DDC_ADDR)
            except OSError as e:
                if e.errno != errno.EBUSY:
                    raise
                fcntl.ioctl(self.fd, I2C_SLAVE_FORCE, DDC_ADDR)
        except OSError:
            os.close(self.fd)
            raise

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _write(self, data):
        os.write(self.fd, data)

    def _read(self, n):
        return os.read(self.fd, n)

    def get_vcp(self, code, tries=3):
        last = None
        for i in range(tries):
            try:
                self._write(get_vcp_request(code))
                time.sleep(self.REPLY_WAIT)
                return parse_vcp_reply(code, self._read(11))
            except (OSError, DdcError) as e:
                last = e
                if i + 1 < tries:
                    time.sleep(0.08 * (i + 1))
        raise last

    def set_vcp(self, code, value):
        self._write(set_vcp_request(code, value))
        time.sleep(self.SET_WAIT)


def edid_summary(raw):
    """Maker, product code and name from an EDID."""
    raw = bytes(raw or b"")
    if len(raw) < 128 or raw[:8] != b"\x00\xff\xff\xff\xff\xff\xff\x00":
        return {}
    m = (raw[8] << 8) | raw[9]
    maker = "".join(chr(((m >> s) & 0x1F) + 64) for s in (10, 5, 0))
    out = {"maker": maker, "product": "%04X" % (raw[10] | (raw[11] << 8))}
    for off in (54, 72, 90, 108):
        d = raw[off:off + 18]
        if d[0:3] == b"\x00\x00\x00" and d[3] == 0xFC:
            name = d[5:18].split(b"\x0a")[0].decode("ascii", "replace").strip()
            if name:
                out["name"] = name
    return out


def hid_summary(desc):
    """(vendor-defined page, feature reports) in a HID report descriptor: the
    places a screen could take backlight commands over its touch USB."""
    vendor = feature = False
    i = 0
    desc = bytes(desc or b"")
    while i < len(desc):
        p = desc[i]
        if p == 0xFE:  # a long item
            if i + 1 >= len(desc):
                break
            i += 3 + desc[i + 1]
            continue
        size = (0, 1, 2, 4)[p & 3]
        data = int.from_bytes(desc[i + 1:i + 1 + size], "little")
        if p & 0xFC == 0x04 and data >= 0xFF00:  # Usage Page, vendor defined
            vendor = True
        elif p & 0xFC == 0xB0:  # Feature
            feature = True
        i += 1 + size
    return vendor, feature


def _read_text(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return None


def _read_bytes(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except OSError:
        return b""


def hid_devices(root="/sys/class/hidraw"):
    """The USB HID devices (the screen's touch is one), for the report."""
    out = []
    for d in sorted(glob.glob(os.path.join(root, "hidraw*"))):
        fields = {}
        for line in (_read_text(os.path.join(d, "device", "uevent")) or "").splitlines():
            k, _s, v = line.partition("=")
            fields[k] = v
        parts = fields.get("HID_ID", "").split(":")  # bus:vendor:product, e.g. 0003:00001A86:0000E5E3
        ident = ("%s:%s" % (parts[1][-4:], parts[2][-4:])).upper() if len(parts) == 3 else ""
        vendor, feature = hid_summary(_read_bytes(os.path.join(d, "device", "report_descriptor")))
        item = {"name": fields.get("HID_NAME") or "?", "id": ident, "vendor": vendor, "feature": feature}
        if item not in out:
            out.append(item)
    return out[:6]


def find_hdmi(drm="/sys/class/drm", i2c="/sys/bus/i2c/devices"):
    """(connector folder, /dev/i2c-N of its DDC wires, EDID bytes) for the
    HDMI port in use. Any of them can be None or empty."""
    conns = sorted(glob.glob(os.path.join(drm, "card*-HDMI-A-*")))
    conn = None
    for want in ("connected", None):
        for c in conns:
            st = _read_text(os.path.join(c, "status"))
            if (st == want) if want else st != "disconnected":
                conn = c
                break
        if conn:
            break
    bus = None
    if conn:
        ddc = os.path.join(conn, "ddc")
        if os.path.exists(ddc):
            name = os.path.basename(os.path.realpath(ddc))
            if name.startswith("i2c-"):
                bus = "/dev/" + name
    if bus is None:
        # Older kernels have no "ddc" link: the Pi Zero's HDMI DDC wires are on
        # the BCM2835's third I2C controller (i2c@7e805000).
        for d in sorted(glob.glob(os.path.join(i2c, "i2c-*"))):
            name = (_read_text(os.path.join(d, "name")) or "").lower()
            if "7e805000" in name or "ddc" in name:
                bus = "/dev/" + os.path.basename(d)
                break
    edid = _read_bytes(os.path.join(conn, "edid")) if conn else b""
    return conn, bus, edid


def _load_i2c_dev(bus):
    """/dev/i2c-N only exists once the i2c-dev module is loaded."""
    if os.path.exists(bus):
        return True
    try:
        subprocess.run(["modprobe", "i2c-dev"], capture_output=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as e:
        log.info("couldn't load i2c-dev: %s", e)
        return False
    for _ in range(20):
        if os.path.exists(bus):
            return True
        time.sleep(0.1)
    return False


def set_pin(pin, high, run=subprocess.run):
    """Drives a GPIO pin high or low. True when it worked."""
    for tool in ("pinctrl", "raspi-gpio"):
        exe = shutil.which(tool)
        if not exe:
            continue
        try:
            r = run([exe, "set", str(int(pin)), "op", "dh" if high else "dl"], capture_output=True, timeout=10)
        except (OSError, subprocess.SubprocessError) as e:
            log.warning("couldn't set GPIO %s: %s", pin, e)
            return False
        if r.returncode == 0:
            return True
        log.warning("%s couldn't set GPIO %s: %s", tool, pin, (r.stderr or b"").decode(errors="replace").strip())
        return False
    log.warning("no pinctrl or raspi-gpio to set GPIO %s", pin)
    return False


def screen_id(info):
    return ":".join(str(info.get(k) or "") for k in ("maker", "product", "name")).strip(":")


class ScreenPower:
    """Makes the screen dark at night the best way it can, and lights it up
    again. request(dark) can be called as often as wanted; a background
    thread does the slow part (DDC/CI waits, the GPIO command)."""

    RECHECK = 5 * 60  # at night, make sure the screen is still off this often
    OFF_SETTLE = 2.5  # seconds before checking the screen stayed off
    WAKE_SETTLE = 2.0  # seconds before checking it came back on

    def __init__(self, settings, state_dir, output=None, touch=None, bus_factory=DdcBus, finder=None,
                 pin_setter=None, hid_finder=None, bus_ready=None):
        self.settings = settings
        self.path = os.path.join(state_dir, "screen.json")
        self.output = output
        self.touch = touch
        self._bus_factory = bus_factory
        self._finder = finder or find_hdmi
        self._set_pin = pin_setter or set_pin
        self._hid_finder = hid_finder or hid_devices
        self._bus_ready = bus_ready or _load_i2c_dev
        self.info = {"checked": False}  # what the screen can do
        self.dark = False  # what was last applied
        self.active = None  # how it's dark now (one of METHODS), or None
        self._want = False
        self._dirty = False
        self._lock = threading.Condition()
        self._stop = False
        self._thread = None
        self._pin_level = {}  # pin -> the level last set
        self._found_awake = 0  # times the screen was found back on by itself tonight
        self._state = self._load()  # what an earlier run did to the screen

    # -- for the app ------------------------------------------------------

    def start(self):
        self._thread = threading.Thread(target=self._run, name="screen-power", daemon=True)
        self._thread.start()

    def stop(self):
        with self._lock:
            self._stop = True
            self._lock.notify_all()

    def request(self, dark):
        with self._lock:
            if self._want != bool(dark):
                self._want = bool(dark)
                self._lock.notify_all()

    def refresh(self):
        """The settings changed (a power switch may have been set up)."""
        with self._lock:
            self._dirty = True
            self._lock.notify_all()

    def switch_pin(self):
        pin = self.settings.get("screenSwitchPin")
        return pin if pin in SWITCH_PINS else None

    def method(self):
        """How "Screen off" works on this screen: one of METHODS."""
        if self.switch_pin() is not None:
            return "switch"
        if self.info.get("power") and self.info.get("power_works") is not False:
            return "ddc"
        if self.info.get("dim_code") is not None:
            return "dim"
        return "picture"

    def method_label(self):
        if self.switch_pin() is None and not self.info.get("checked"):
            return "Checking..."
        m = self.method()
        if m == "dim" and self.info.get("dim_code") == VCP_BRIGHTNESS:
            return "Lowest brightness"
        return METHOD_LABELS[m]

    def public_info(self):
        """What the screen can do, for /api/info and the report (nothing private)."""
        keep = ("connector", "bus", "maker", "product", "name", "ddc", "power", "power_works", "dim_code",
                "error", "hid")
        out = {k: self.info[k] for k in keep if k in self.info}
        out["checked"] = bool(self.info.get("checked"))
        out["off"] = self.method()
        if self.switch_pin() is not None:
            out["switch_pin"] = self.switch_pin()
        out["dark"] = self.dark
        return out

    # -- the work ---------------------------------------------------------

    def _run(self):
        try:
            self._probe()
        except Exception as e:  # noqa: BLE001
            log.warning("couldn't check the screen: %s", e)
            self.info = {"checked": True, "error": _why(e)}
        first = True
        while True:
            with self._lock:
                if not first:
                    deadline = time.monotonic() + self.RECHECK
                    while not self._stop and not self._dirty and self._want == self.dark \
                            and time.monotonic() < deadline:
                        self._lock.wait(timeout=max(0.5, deadline - time.monotonic()))
                if self._stop:
                    return
                want, dirty = self._want, self._dirty
                self._dirty = False
            try:
                if first:
                    self._apply(want, start=True)
                elif want != self.dark or dirty:
                    self._apply(want)
                else:
                    self._apply(want, recheck=True)
            except Exception:  # noqa: BLE001
                log.exception("screen power")
            first = False

    def _probe(self):
        conn, bus, edid = self._finder()
        info = {"checked": False, "connector": os.path.basename(conn) if conn else None, "bus": bus}
        info.update(edid_summary(edid))
        try:
            info["hid"] = self._hid_finder()
        except Exception:  # noqa: BLE001
            pass
        tested = self._state.get("tested") or {}
        if tested.get("id") == screen_id(info):
            info["power_works"] = tested.get("works")  # found out on an earlier night
        if not bus:
            info["error"] = "no DDC bus found"
        elif not self._bus_ready(bus):
            info["error"] = "no %s" % bus
        else:
            try:
                with self._bus_factory(bus) as d:
                    self._probe_codes(d, info)
            except OSError as e:
                info["error"] = _why(e)
        info["checked"] = True
        self.info = info
        log.info("screen %s: DDC/CI %s; at night: %s", screen_id(info) or "?",
                 ("answers, power command %s, dimming %s" % (
                     "yes" if info.get("power") else "no",
                     "VCP %02X" % info["dim_code"] if info.get("dim_code") is not None else "no"))
                 if info.get("ddc") else "doesn't answer (%s)" % info.get("error", "?"),
                 self.method_label().lower())

    def _probe_codes(self, d, info):
        info["ddc"] = False
        try:
            ok, cur, _mx = d.get_vcp(VCP_POWER)
            info["ddc"] = True
            info["power"] = bool(ok)
            if ok:
                info["power_now"] = cur
        except DdcError as e:  # something answered, but not properly
            info["ddc"] = True
            info["error"] = _why(e)
        except OSError as e:
            info["error"] = _why(e)
            if self._state.get("ddcPower") and info.get("power_works"):
                # Off from an earlier run, and this screen goes quiet while
                # it's off: trust what that run found.
                info.update(ddc=True, power=True, asleep=True)
            return
        for code in DIM_CODES:
            try:
                ok, cur, mx = d.get_vcp(code)
            except (OSError, DdcError):
                continue
            if ok and mx:
                info.update(dim_code=code, dim_now=cur, dim_max=mx)
                break

    def _apply(self, dark, start=False, recheck=False):
        pin = self.switch_pin()
        old = self._state.get("switchPin")
        if old is not None and old != pin:
            # A switch set up before isn't now (or is on another pin): power on.
            self._drive(old, False, force=True)
        used = None
        if pin is not None:
            if self._drive(pin, dark, force=start or recheck):
                used = "switch"
        elif dark:
            used = self._ddc_dark(recheck)
        elif start or self.dark:
            self._ddc_light()
        if not dark:
            self._found_awake = 0
        changed = dark != self.dark or used != self.active
        self.dark = dark
        self.active = used if dark else None
        if dark and used is None and changed:
            log.info("night: black picture (this screen can't be switched off from here)")

    # The power switch on a GPIO pin

    def _drive(self, pin, dark, force=False):
        off_high = self.settings.get("screenSwitchOff") != "low"
        level = off_high if dark else not off_high
        if self.touch is not None and hasattr(self.touch, "expect_gone"):
            self.touch.expect_gone(dark)  # its touch going away isn't a fault then
        if force or self._pin_level.get(pin) != level:
            if not self._set_pin(pin, level):
                return False
            if self._pin_level.get(pin) != level:
                log.info("screen power %s (GPIO %d %s)", "cut" if dark else "on", pin, "high" if level else "low")
            self._pin_level[pin] = level
        self._save(switchPin=pin if dark else None)
        return True

    # DDC/CI

    def _read(self, d, code, tries=2):
        try:
            ok, cur, _mx = d.get_vcp(code, tries=tries)
            return cur if ok else None
        except (OSError, DdcError):
            return None

    def _works(self, flag):
        self.info["power_works"] = flag
        self._save(tested={"id": screen_id(self.info), "works": flag})

    def _ddc_dark(self, recheck):
        bus = self.info.get("bus")
        if not bus or not (self.info.get("power") or self.info.get("dim_code") is not None
                           or self._state.get("dimCode") is not None):
            return None
        try:
            with self._bus_factory(bus) as d:
                if self.info.get("power") and self.info.get("power_works") is not False:
                    if recheck and self.active == "ddc":
                        cur = self._read(d, VCP_POWER)
                        if cur is None or cur in POWER_DARK:
                            return "ddc"  # still off (some screens go quiet while off)
                        self._found_awake += 1
                        if self._found_awake >= 2:
                            log.info("the screen keeps turning itself back on: dimming it instead")
                            self._works(False)
                        else:
                            log.info("the screen was back on: turning it off again")
                    if self.info.get("power_works") is not False and self._power_off(d):
                        return "ddc"
                return self._dim(d)
        except (OSError, DdcError) as e:
            log.warning("couldn't make the screen dark over DDC/CI: %s", _why(e))
        return None

    def _power_off(self, d):
        """Turns the backlight off. The first time on a screen, checks that it
        stays off and that it can be woken again before trusting it."""
        self._save(ddcPower=True)
        if self.info.get("power_works"):
            try:
                d.set_vcp(VCP_POWER, POWER_OFF)
            except OSError:
                pass  # already off: some screens stop answering while they're off
            if self.active != "ddc":
                log.info("night: backlight off (DDC/CI)")
            return True
        d.set_vcp(VCP_POWER, POWER_OFF)
        time.sleep(self.OFF_SETTLE)
        cur = self._read(d, VCP_POWER)
        if cur in POWER_DARK:
            log.info("night: backlight off (DDC/CI power mode %d)", cur)
            self._works(True)
            return True
        if cur == POWER_ON:
            log.info("the screen turned itself straight back on: dimming it instead")
            self._works(False)
            self._save(ddcPower=None)
            return False
        # Quiet since the command: it may be off and not answering. Make sure
        # it can be woken before trusting it with the night.
        try:
            d.set_vcp(VCP_POWER, POWER_ON)
        except OSError:
            pass  # not even listening: a new HDMI signal may wake it
        time.sleep(self.WAKE_SETTLE)
        cur = self._read(d, VCP_POWER, tries=3)
        if cur is None:
            self._resync()
            cur = self._read(d, VCP_POWER, tries=3)
        if cur is None:
            # ddcPower stays noted, so every start and morning tries to wake it.
            log.warning("the screen stopped answering after the off command: not using it")
            self._works(False)
            return False
        self._works(True)
        d.set_vcp(VCP_POWER, POWER_OFF)
        log.info("night: backlight off (DDC/CI; the screen is quiet while it's off)")
        return True

    def _dim(self, d):
        code = self._state.get("dimCode")
        if code is None:
            code = self.info.get("dim_code")
            if code is None:
                return None
            cur = self._read(d, code, tries=3)
            if cur is None:
                return None  # can't put it back in the morning without knowing it
            self._save(dimCode=code, dimValue=cur)
        d.set_vcp(code, 0)
        if self.active != "dim":
            log.info("night: VCP %02X at 0 (lowest backlight or brightness)", code)
        return "dim"

    def _ddc_light(self):
        power = bool(self._state.get("ddcPower"))
        code, value = self._state.get("dimCode"), self._state.get("dimValue")
        if not power and code is None:
            return
        bus = self.info.get("bus")
        try:
            if not bus:
                raise OSError(errno.ENODEV, "no DDC bus")
            with self._bus_factory(bus) as d:
                if power:
                    d.set_vcp(VCP_POWER, POWER_ON)
                if code is not None and value is not None:
                    d.set_vcp(code, int(value))
                if power:
                    time.sleep(self.WAKE_SETTLE)
                    cur = self._read(d, VCP_POWER, tries=3)
                    if cur is None:
                        self._resync()  # it went quiet while off: a new signal wakes it
                    elif cur in POWER_DARK:
                        d.set_vcp(VCP_POWER, POWER_ON)
            log.info("screen on")
        except (OSError, DdcError) as e:
            log.info("the screen didn't answer (%s)%s", _why(e), ": waking it with a new HDMI signal" if power else "")
            if power:
                self._resync()
        self._save(ddcPower=None, dimCode=None, dimValue=None)

    def _resync(self):
        """Stops and restarts the HDMI signal: screens wake from standby when
        a signal comes back."""
        out = self.output
        if out is None or not hasattr(out, "blank"):
            return
        try:
            out.blank(True)
            time.sleep(1.0)
            out.blank(False)
            time.sleep(1.5)
        except Exception as e:  # noqa: BLE001
            log.warning("couldn't restart the HDMI signal: %s", e)

    # What an earlier run left behind

    def _load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self, **changes):
        state = dict(self._state)
        state.update(changes)
        state = {k: v for k, v in state.items() if v is not None}
        if state == self._state:
            return
        self._state = state
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f)
            os.replace(tmp, self.path)
        except OSError as e:
            log.warning("couldn't save the screen state: %s", e)


def describe(info):
    """Lines for the report's Screen section, from public_info()."""
    who = " ".join(x for x in (info.get("maker"), info.get("name")) if x)
    if info.get("product"):
        who += " (product %s)" % info["product"]
    lines = ["Screen: %s." % (who.strip() or "unknown (no EDID)")]
    if not info.get("checked"):
        lines.append("Not checked yet.")
    elif info.get("ddc"):
        works = info.get("power_works")
        lines.append("DDC/CI on %s: answers." % (info.get("bus") or "?"))
        lines.append("Power command (VCP D6): %s." % (
            "no" if not info.get("power") else
            "yes" if works else "yes, but it doesn't stay off" if works is False else "yes, not tried yet"))
        code = info.get("dim_code")
        lines.append("Backlight or brightness command: %s." % ("VCP %02X" % code if code is not None else "no"))
    else:
        lines.append("DDC/CI on %s: no answer (%s)." % (info.get("bus") or "no bus", info.get("error") or "?"))
    off = info.get("off")
    text = METHOD_LABELS.get(off, off or "?")
    if off == "switch":
        pin = info.get("switch_pin")
        text += " (GPIO %s, header pin %s)" % (pin, HEADER_PIN.get(pin, "?"))
    lines.append("Night \"Screen off\": %s%s." % (text, ", now dark" if info.get("dark") else ""))
    for h in info.get("hid") or []:
        lines.append("USB HID: %s %s%s." % (h.get("name"), h.get("id"), ", has vendor commands" if h.get("vendor")
                                           else ""))
    return lines


def light_up(state_dir="/var/lib/tideview"):
    """Undoes whatever an earlier run did to the screen (for install.sh
    --remove)."""
    path = os.path.join(state_dir, "screen.json")
    try:
        with open(path, encoding="utf-8") as f:
            state = json.load(f)
    except (OSError, ValueError):
        state = {}
    pin = state.get("switchPin")
    if pin in SWITCH_PINS:
        try:
            with open(os.path.join(state_dir, "settings.json"), encoding="utf-8") as f:
                off_high = json.load(f).get("screenSwitchOff") != "low"
        except (OSError, ValueError):
            off_high = True
        set_pin(pin, not off_high)
    if state.get("ddcPower") or state.get("dimCode") is not None:
        _conn, bus, _edid = find_hdmi()
        if bus and _load_i2c_dev(bus):
            try:
                with DdcBus(bus) as d:
                    if state.get("ddcPower"):
                        d.set_vcp(VCP_POWER, POWER_ON)
                    if state.get("dimCode") is not None and state.get("dimValue") is not None:
                        d.set_vcp(int(state["dimCode"]), int(state["dimValue"]))
            except (OSError, DdcError):
                pass
    try:
        os.remove(path)
    except OSError:
        pass
