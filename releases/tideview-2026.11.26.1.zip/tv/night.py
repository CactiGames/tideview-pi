"""Night mode: dim the picture or turn the screen off, by time of day. A
tap at night brings the picture back for a minute.

"Screen off" makes the picture black and, through tv.screenpower, turns the
screen's backlight off when the screen takes that command over the HDMI
cable (DDC/CI), or cuts its power with a switch on a GPIO pin if one is set
up. The HDMI signal itself is never turned off: the Jaycar screen then shows
a blue "No Signal" box instead of going dark."""

from datetime import datetime


class NightController:
    def __init__(self, settings):
        self.settings = settings
        self.state = "day"  # "day", "dim" or "black"
        self._woken_until = 0.0
        self._test_until = 0.0  # "Test screen off": dark until then

    def test_off(self, now, seconds=5):
        """Screen off for a few seconds, to see what night looks like."""
        self._test_until = now + seconds
        self._woken_until = 0.0

    def next_change(self, now):
        """When a test or a tap's minute of light ends, if one is running."""
        ends = [t for t in (self._test_until, self._woken_until) if t > now]
        return min(ends) if ends else None

    def in_night_window(self, now):
        d = datetime.fromtimestamp(now)
        m = d.hour * 60 + d.minute
        start, end = self.settings["nightStart"], self.settings["dayStart"]
        if start == end:
            return False
        return (start <= m < end) if start < end else (m >= start or m < end)

    def wake_briefly(self, now, seconds=60):
        self._woken_until = now + seconds
        self._test_until = 0.0

    def evaluate(self, now):
        """Works out the state for now; returns True when it changed."""
        mode = self.settings["nightMode"]
        nxt = "day"
        if now < self._test_until:
            nxt = "black"
        elif mode != "off" and self.in_night_window(now) and now >= self._woken_until:
            nxt = {"dim": "dim", "black": "black", "screenOff": "black"}.get(mode, "day")
        changed = nxt != self.state
        self.state = nxt
        return changed
