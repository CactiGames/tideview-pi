#!/bin/bash
# TideView installer for a Raspberry Pi (Zero W or newer) running Raspberry
# Pi OS Lite. Run it once, on the Pi:
#
#     sudo bash /boot/firmware/tideview/install.sh
#
# It installs pygame, copies TideView to /opt/tideview, makes it start
# whenever the Pi is switched on and keep itself up to date, tidies up the
# start-up screen and restarts the Pi. Running it again is safe. To undo it:
#
#     sudo bash /boot/firmware/tideview/install.sh --remove
#
# (The line below lets the script run even if Windows changed its line endings.)
if grep -q $'\r' "$0" 2>/dev/null; then tr -d '\r' < "$0" > /tmp/tideview-install.sh; TIDEVIEW_APP_DIR="$(cd "$(dirname "$0")" && pwd)" exec bash /tmp/tideview-install.sh "$@"; fi #
set -euo pipefail

APP_DIR="${TIDEVIEW_APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
ROOT="${TIDEVIEW_ROOT:-/opt/tideview}"  # where the versions are installed
UNIT_DIR="${TIDEVIEW_UNIT_DIR:-/etc/systemd/system}"
ETC="${TIDEVIEW_ETC:-/etc}"
WIFI_CONF="$ETC/NetworkManager/conf.d/tideview-wifi.conf"
CONFIG_START="# TideView (added by install.sh)"
CONFIG_END="# end of TideView settings"
SCREEN_MODE="video=HDMI-A-1:1024x600M-32@60D"  # the Jaycar 7" panel's own resolution
export PYGAME_HIDE_SUPPORT_PROMPT=1

say() { printf '\n\033[1m%s\033[0m\n' "$*"; }
fail() { printf '\n\033[31m%s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Please run it with sudo:  sudo bash $APP_DIR/install.sh"

BOOT="${TIDEVIEW_BOOT:-/boot/firmware}"
[ -f "$BOOT/cmdline.txt" ] || [ -n "${TIDEVIEW_BOOT:-}" ] || BOOT=/boot
CMDLINE="$BOOT/cmdline.txt"
CONFIG="$BOOT/config.txt"

# ---------------------------------------------------------------- undo
if [ "${1:-}" = "--remove" ]; then
  say "Removing TideView..."
  systemctl disable --now tideview-update.timer tideview.service 2>/dev/null || true
  # Light the screen back up if TideView had switched it off for the night.
  (cd "$APP_DIR" && PYTHONDONTWRITEBYTECODE=1 python3 -c \
    "from tv.screenpower import light_up; light_up('${TIDEVIEW_STATE:-/var/lib/tideview}')") 2>/dev/null || true
  rm -f "$UNIT_DIR/tideview.service" "$UNIT_DIR/tideview-update.service" "$UNIT_DIR/tideview-update.timer" \
        "$UNIT_DIR/tideview-splash.service" "$UNIT_DIR/sysinit.target.wants/tideview-splash.service" \
        "$WIFI_CONF"
  systemctl daemon-reload
  systemctl enable getty@tty1.service 2>/dev/null || true
  rm -rf "$ROOT"
  if [ -f "$CMDLINE.before-tideview" ]; then
    cp "$CMDLINE.before-tideview" "$CMDLINE"
    rm -f "$CMDLINE.before-tideview"
  elif [ -f "$CMDLINE.before-splash" ]; then
    cp "$CMDLINE.before-splash" "$CMDLINE"
  fi
  rm -f "$CMDLINE.before-splash"
  if [ -f "$CONFIG" ]; then
    sed -i "/^$CONFIG_START\$/,/^$CONFIG_END\$/d" "$CONFIG"
  fi
  say "Done. Your settings and keys are still in /var/lib/tideview (delete that folder to remove them too)."
  echo "Restart the Pi to finish:  sudo reboot"
  exit 0
fi

for f in tideview.py tvupdate.py VERSION tv/app.py; do
  [ -f "$APP_DIR/$f" ] || fail "Can't find $f in $APP_DIR. Copy the whole tideview folder onto the card again."
done
VERSION="$(tr -d '\r\n ' < "$APP_DIR/VERSION")"
need_reboot=0

# ---------------------------------------------------------------- 1. pygame
say "1/5  Installing pygame (5 to 15 minutes on a Pi Zero; it's normal for it to sit still for a while)..."
if python3 -c "import pygame" 2>/dev/null; then
  echo "pygame is already installed."
else
  # (Waits if the Pi is busy with its own updates just after first start.)
  apt-get -o DPkg::Lock::Timeout=900 update
  DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=900 install -y --no-install-recommends python3-pygame
fi
python3 -c "import pygame" 2>/dev/null \
  || fail "pygame didn't install. Check the Pi is online (try: ping -c 3 deb.debian.org), then run this again."
echo "Testing TideView $VERSION without the screen..."
test_dir="$(mktemp -d)"
if ! { python3 "$APP_DIR/tvupdate.py" selftest \
       && TIDEVIEW_STATE="$test_dir" PYTHONDONTWRITEBYTECODE=1 python3 "$APP_DIR/tideview.py" --selftest; } \
     > "$test_dir/test.log" 2>&1; then
  cat "$test_dir/test.log"
  rm -rf "$test_dir"
  fail "TideView's self-test failed (see above). Copy the whole tideview folder onto the card again."
fi
rm -rf "$test_dir"
echo "It works."

# ---------------------------------------------------------------- 2. install
say "2/5  Installing TideView $VERSION in $ROOT, to start at power-on and keep itself up to date..."
python3 "$APP_DIR/tvupdate.py" install "$APP_DIR"
systemctl disable getty@tty1.service 2>/dev/null || true
echo "Settings are kept in /var/lib/tideview. Logs: journalctl -u tideview"

# ---------------------------------------------------------------- 3. screen
say "3/5  Quiet start-up and the screen at 1024 x 600..."
if [ -f "$CMDLINE" ]; then
  [ -f "$CMDLINE.before-tideview" ] || cp "$CMDLINE" "$CMDLINE.before-tideview"
  line="$(head -n 1 "$CMDLINE" | tr -d '\r\n')"
  before="$line"
  for opt in consoleblank=0 logo.nologo quiet loglevel=3 vt.global_cursor_default=0 "$SCREEN_MODE"; do
    key="${opt%%=*}"
    case " $line " in
      *" $opt "*) ;;           # already there
      *" $key="*) ;;           # already set some other way: leave it alone
      *) line="$line $opt" ;;
    esac
  done
  if [ "$line" != "$before" ]; then
    printf '%s\n' "$line" > "$CMDLINE"
    need_reboot=1
    echo "Updated $CMDLINE (the old one is saved as cmdline.txt.before-tideview)."
  else
    echo "Already set."
  fi
else
  echo "No $CMDLINE here, so skipping this (is this a Raspberry Pi?)."
fi
if [ -f "$CONFIG" ] && ! grep -qx "$CONFIG_START" "$CONFIG"; then
  printf '\n%s\n[all]\ndisable_splash=1\n%s\n' "$CONFIG_START" "$CONFIG_END" >> "$CONFIG"
  need_reboot=1
fi

# ---------------------------------------------------------------- 4. tidy-ups
say "4/5  Wi-Fi and time zone..."
if [ -d "$ETC/NetworkManager/conf.d" ]; then
  # Wi-Fi power saving makes a Pi Zero W drop off the network now and then.
  printf '[connection]\nwifi.powersave = 2\n' > "$WIFI_CONF"
  echo "Wi-Fi power saving turned off."
fi
tz="$(timedatectl show -p Timezone --value 2>/dev/null || true)"
case "$tz" in
  ""|UTC|Etc/UTC|Europe/London)
    timedatectl set-timezone Pacific/Auckland && echo "Time zone set to Pacific/Auckland." ;;
  *) echo "Time zone: $tz" ;;
esac

# ---------------------------------------------------------------- 5. start
if [ "$need_reboot" = 1 ]; then
  say "5/5  All done. The Pi restarts in 10 seconds (Ctrl+C to stop that)."
  echo "TideView appears on the screen about a minute after the restart."
  sleep 10
  systemctl reboot
else
  say "5/5  All done. Starting TideView $VERSION now..."
  systemctl restart tideview.service
  echo "It's running. Check on it with:  systemctl status tideview"
fi
