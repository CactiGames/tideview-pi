"""Phone control: a small web server on the home network.

The screen shows a QR code holding this Pi's address and a code. The TideView
app on a phone scans it (any phone's camera also works: it opens the same
settings in the browser), then shows the touch screen's Settings page and
changes the settings here.

Only a phone that knows the code can see or change anything. The code is on
the screen, so anyone who can see the screen can link a phone, like a TV
remote. "Unlink all phones" makes a new code.

The server runs on threads of its own. Anything that reads or changes the app
runs on the main loop's thread (App.call_soon), just like a tap, so a phone
can never trip up the display. If the server can't start, TideView carries on
without it.
"""

import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import settings as settings_mod
from . import system
from .version import VERSION

log = logging.getLogger("tideview.remote")

API_VERSION = 1
PORTS = (8765, 8766, 8767, 8768, 8769)  # the first one that's free
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O or 1/I to mix up
CODE_LENGTH = 8
SHOW_AFTER_POWER_ON = 10 * 60  # the code shows this long after power-on, even with a phone linked
SHOW_WHEN_ASKED = 5 * 60
OFFLINE_CARD_AFTER = 120  # seconds without Wi-Fi before the card explains why
MAX_BODY = 16 * 1024
SAVE_SEEN_EVERY = 15 * 60  # "last used" times are saved at most this often (spares the SD card)
WRONG_CODES = 10  # wrong codes from one address before it has to wait
WRONG_CODE_WAIT = 60
WEB_PAGE = os.path.join(settings_mod.APP_DIR, "assets", "remote", "index.html")
ACTION_KINDS = ("nav", "toggle", "cycle", "stepper", "button", "check")


class BadRequest(Exception):
    pass


class NotFound(Exception):
    pass


class Busy(Exception):
    pass


def new_code():
    return "".join(secrets.choice(ALPHABET) for _ in range(CODE_LENGTH))


def pretty_code(code):
    return "%s-%s" % (code[:4], code[4:]) if code and len(code) == CODE_LENGTH else (code or "")


def clean_code(text):
    return re.sub(r"[^A-Z0-9]", "", str(text or "").upper())


def _ago(seconds):
    if seconds < 90:
        return "just now"
    if seconds < 90 * 60:
        return "%d minutes ago" % round(seconds / 60)
    if seconds < 36 * 3600:
        h = round(seconds / 3600)
        return "an hour ago" if h == 1 else "%d hours ago" % h
    d = round(seconds / 86400)
    return "yesterday" if d == 1 else "%d days ago" % d


class Pairing:
    """The code, and the phones that have used it. Kept in remote.json in
    the state folder (readable by root only, since it holds the code)."""

    def __init__(self, path=None):
        self.path = path or os.path.join(settings_mod.state_dir(), "remote.json")
        self._lock = threading.Lock()
        self.code = None
        self.phones = {}  # id -> {"name", "first", "last"}
        self._saved_at = 0.0
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            code = clean_code(data.get("code"))
            if len(code) == CODE_LENGTH:
                self.code = code
            phones = data.get("phones")
            if isinstance(phones, dict):
                for pid, p in phones.items():
                    if isinstance(p, dict):
                        self.phones[str(pid)[:64]] = {"name": str(p.get("name") or "Phone")[:60],
                                                      "first": float(p.get("first") or 0),
                                                      "last": float(p.get("last") or 0)}
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        if not self.code:
            self.code = new_code()
            self._save()

    def _save(self):
        tmp = self.path + ".tmp"
        try:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({"code": self.code, "phones": self.phones}, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
            self._saved_at = time.time()
        except OSError as e:
            log.warning("couldn't save %s: %s", self.path, e)

    @property
    def linked(self):
        return bool(self.phones)

    def check(self, code):
        return hmac.compare_digest(clean_code(code).encode(), self.code.encode())

    def link(self, phone_id, name):
        """Notes a phone that has the code. Returns True if it's new."""
        phone_id = str(phone_id or "")[:64] or "browser"
        name = re.sub(r"\s+", " ", str(name or "")).strip()[:60] or "Phone"
        now = time.time()
        with self._lock:
            p = self.phones.get(phone_id)
            new = p is None
            if new:
                p = self.phones[phone_id] = {"name": name, "first": now, "last": now}
            p["name"] = name
            p["last"] = now
            self._save()
        return new

    def seen(self, phone_id):
        phone_id = str(phone_id or "")[:64]
        with self._lock:
            p = self.phones.get(phone_id)
            if p is None:
                return
            p["last"] = time.time()
            if time.time() - self._saved_at > SAVE_SEEN_EVERY:
                self._save()

    def unlink_all(self):
        with self._lock:
            self.code = new_code()
            self.phones = {}
            self._save()

    def describe(self, now=None):
        now = time.time() if now is None else now
        with self._lock:
            phones = sorted(self.phones.values(), key=lambda p: -p["last"])
        if not phones:
            return "None yet. Scan the code on the main screen with the TideView app on your phone."
        return "\n".join("%s, last used %s" % (p["name"], _ago(max(0, now - p["last"]))) for p in phones[:6])


class Remote:
    """Phone control for one App: the code, the server, and what phones see."""

    def __init__(self, app, pairing=None):
        self.app = app
        self.pairing = pairing or Pairing()
        self.port = None
        self.error = None
        self.show_until = 0.0
        self.preview_address = None  # screenshots and the self-test pretend to have an address
        self._httpd = None
        self._thread = None
        self._screen = None
        self._ip = None
        self._ip_at = -1e9
        self._wrong = {}  # address -> (count, first wrong time)
        self._wrong_lock = threading.Lock()

    # -- the server -------------------------------------------------------

    def start(self):
        last = None
        for port in PORTS:
            try:
                httpd = _Server(("", port), _Handler)
            except OSError as e:
                last = e
                continue
            httpd.remote = self
            self._httpd = httpd
            self.port = port
            self._thread = threading.Thread(target=self._serve, name="phone-control", daemon=True)
            self._thread.start()
            log.info("phone control is on port %d", port)
            return True
        self.error = "Couldn't start: %s" % last
        log.warning("phone control couldn't start: %s", last)
        return False

    def _serve(self):
        try:
            self._httpd.serve_forever(poll_interval=1.0)
        except Exception:  # noqa: BLE001
            log.exception("phone control stopped")
            self.error = "Stopped by a problem. Restart TideView to try again."
            self.port = None

    def stop(self):
        httpd, self._httpd = self._httpd, None
        if httpd is not None:
            try:
                httpd.shutdown()
                httpd.server_close()
            except Exception:  # noqa: BLE001
                pass

    # -- what the screen shows ------------------------------------------

    def address(self):
        """This Pi's address on the home network (checked every 15 s)."""
        if self.preview_address:
            return self.preview_address
        now = time.monotonic()
        if now - self._ip_at > 15:
            self._ip_at = now
            self._ip = system.ip_address()
        return self._ip

    def running(self):
        return bool(self.port) or bool(self.preview_address)

    def url(self):
        ip = self.address()
        if not ip or not self.running():
            return None
        return "http://%s:%d/#%s" % (ip, self.port or PORTS[0], self.pairing.code)

    def web_address(self):
        ip = self.address()
        if not ip:
            return None
        port = self.port or PORTS[0]
        return "%s:%d" % (ip, port)

    def _offline(self):
        net = self.app.net
        return net is not None and net.offline_for() >= OFFLINE_CARD_AFTER

    def card_visible(self, now):
        if self._offline():
            return True
        if not self.running():
            return False
        if not self.pairing.linked or now < self.show_until:
            return True
        up = system.uptime_hours()
        return up is not None and up * 3600 < SHOW_AFTER_POWER_ON

    def card_info(self, now):
        """What the pairing card says, for tv.ui.pairing."""
        linked = self.pairing.linked
        hides_in = None
        if linked:
            left = self.show_until - now
            up = system.uptime_hours()
            if up is not None:
                left = max(left, SHOW_AFTER_POWER_ON - up * 3600)
            hides_in = max(1, int(round(left / 60))) if left > 0 else None
        info = {"url": self.url(), "address": self.web_address(), "code": pretty_code(self.pairing.code),
                "linked": linked, "hides_in": hides_in, "offline": False}
        if self._offline():
            net = self.app.net
            wifi = self.app.wifi
            info.update(offline=True, why=net.diagnosis or "", clock=net.clock_ok is False, url=None, hides_in=None,
                        tap=wifi is not None and wifi.available())
        return info

    def show_code(self, seconds=SHOW_WHEN_ASKED):
        self.show_until = time.time() + seconds
        self.app.frame_changed()

    def unlink_all(self):
        self.pairing.unlink_all()
        self.show_until = 0.0
        self.app.show_message("All phones are unlinked. Scan the new code to link one again.", 8)
        self.app.frame_changed()

    # -- what phones see (main thread only) -----------------------------

    def _settings_screen(self):
        if self._screen is None:
            from .ui.settings_screen import SettingsScreen
            self._screen = SettingsScreen(self.app)
        return self._screen

    def rows(self):
        return self._settings_screen().rows(remote=True)

    def state(self):
        app = self.app
        rows = self.rows()
        used = set()
        beach = app.forecast.beach
        return {
            "api": API_VERSION,
            "pi": {"name": system.hostname(), "version": VERSION, "address": self.address(), "port": self.port},
            "title": "TideView settings",
            "beach": {"id": beach.id, "name": beach.name, "region": beach.region},
            "features": ["wifi", "report"],
            "rows": [row_json(r, used) for r in rows],
        }

    def act(self, row_id, op, index=None):
        used = set()
        for r in self.rows():
            if row_json(r, used).get("id") != row_id:
                continue
            if op == "tap":
                fn = r.get("remote_tap") or r.get("on_tap")
                if fn is None:
                    raise BadRequest("That can't be tapped.")
                fn()
            elif op in ("minus", "plus"):
                fn = r.get("on_" + op)
                if fn is None:
                    raise BadRequest("That has no %s button." % op)
                fn()
            elif op == "choose":
                options = r.get("options") or []
                fn = r.get("on_choose")
                if fn is None or not isinstance(index, int) or not 0 <= index < len(options):
                    raise BadRequest("That isn't one of the choices.")
                fn(index)
            else:
                raise BadRequest("Unknown action.")
            self.app.frame_changed()
            return self.state()
        raise NotFound("That setting isn't there any more. Pull down to refresh.")

    def beaches(self):
        from .beaches import BEACHES, regions
        current = self.app.settings["beach"]
        out = []
        for reg in regions():
            items = []
            for b in BEACHES:
                if b.region != reg:
                    continue
                items.append({"id": b.id, "name": b.name,
                              "sub": "Best swell %s · offshore wind %s%s" % (
                                  b.ideal_swell, b.ideal_wind, "" if b.tide == "any" else " · %s tide" % b.tide)})
            out.append({"name": reg, "beaches": items})
        return {"current": current, "regions": out}

    def set_beach(self, beach_id):
        from .beaches import BEACHES
        for b in BEACHES:
            if b.id == beach_id:
                self.app.choose_beach(b, from_phone=True)
                return self.state()
        raise NotFound("No beach called %s." % beach_id)

    def wifi_state(self):
        """The Wi-Fi page for phones (any thread)."""
        w = self.app.wifi
        if w is None:
            return {"available": False, "status": {}, "networks": [], "scanning": False, "joining": None,
                    "result": None}
        w.refresh_status(10)
        return w.snapshot()

    def wifi_join(self, body):
        from .wifi import check_name, check_password
        w = self.app.wifi
        if w is None or not w.available():
            raise BadRequest("TideView can't change the Wi-Fi on this system.")
        ssid, password, hidden = body.get("ssid"), body.get("password"), bool(body.get("hidden"))
        if not isinstance(ssid, str) or check_name(ssid):
            raise BadRequest(check_name(ssid) if isinstance(ssid, str) else "Which network?")
        if password is not None and not isinstance(password, str):
            raise BadRequest("The password should be text.")
        if password:
            problem = check_password(password)
            if problem:
                raise BadRequest(problem)
        if not w.join(ssid, password or None, hidden):
            raise Busy("TideView is still joining %s. Wait a moment." % (w.joining or "a network"))
        log.info("a phone asked to join %s", ssid)
        return self.wifi_state()

    def phone_linked(self, name):
        self.app.show_message("Linked to %s. Change the settings there now." % name, 8)
        self.app.frame_changed()

    # -- for the server threads -------------------------------------------

    def info(self):
        return {"app": "tideview", "api": API_VERSION, "version": VERSION, "name": system.hostname(),
                "linked": self.pairing.linked}

    def locked_out(self, ip):
        with self._wrong_lock:
            n, first = self._wrong.get(ip, (0, 0.0))
            if n >= WRONG_CODES and time.time() - first < WRONG_CODE_WAIT:
                return True
            if n and time.time() - first >= WRONG_CODE_WAIT:
                self._wrong.pop(ip, None)
            return False

    def wrong_code(self, ip):
        with self._wrong_lock:
            n, first = self._wrong.get(ip, (0, time.time()))
            self._wrong[ip] = (n + 1, first)
            if len(self._wrong) > 200:
                self._wrong.clear()

    def handle(self, method, path, body, phone):
        """Runs one request that has the right code. Returns the reply."""
        app = self.app
        self.pairing.seen(phone)
        if path == "/api/hello" and method == "POST":
            name = body.get("name") if isinstance(body, dict) else None
            if self.pairing.link(phone, name):
                shown = re.sub(r"\s+", " ", str(name or "")).strip()[:60] or "a phone"
                app.call_soon(lambda: self.phone_linked(shown))
            return app.call_soon(self.state)
        if path == "/api/settings" and method == "GET":
            return app.call_soon(self.state)
        if path == "/api/action" and method == "POST":
            row_id, op, index = body.get("id"), body.get("op", "tap"), body.get("index")
            if not isinstance(row_id, str) or not isinstance(op, str):
                raise BadRequest("Which setting?")
            return app.call_soon(lambda: self.act(row_id, op, index))
        if path == "/api/beaches" and method == "GET":
            return app.call_soon(self.beaches)
        if path == "/api/beach" and method == "POST":
            beach_id = body.get("id")
            if not isinstance(beach_id, str):
                raise BadRequest("Which beach?")
            return app.call_soon(lambda: self.set_beach(beach_id))
        if path == "/api/wifi" and method == "GET":
            return self.wifi_state()
        if path == "/api/wifi/scan" and method == "POST":
            if app.wifi is not None and app.wifi.available():
                app.wifi.scan()
            return self.wifi_state()
        if path == "/api/wifi/join" and method == "POST":
            return self.wifi_join(body)
        if path == "/api/report" and method == "GET":
            from . import report
            text = report.build_for_phone(app)
            if text is None:
                raise Busy("TideView is putting a report together for another phone. Try again in a moment.")
            return {"text": text, "made": time.time(), "version": VERSION}
        raise NotFound("Not found.")


def _slug(text):
    return re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")[:40] or "row"


def row_json(r, used):
    """A settings row as phones see it: plain values, no callbacks."""
    kind = r["kind"]
    out = {"kind": kind, "label": str(r.get("label", ""))}
    sub = r.get("sub")
    if sub:
        out["sub"] = str(sub)
    value = r.get("value")
    if kind in ("toggle", "check"):
        out["value"] = bool(value)
    elif value not in (None, ""):
        out["value"] = str(value)
    if kind in ACTION_KINDS:
        rid = r.get("id") or _slug(r.get("label", ""))
        base, n = rid, 2
        while rid in used:
            rid = "%s-%d" % (base, n)
            n += 1
        used.add(rid)
        out["id"] = rid
        if r.get("options"):
            out["options"] = [str(o) for o in r["options"]]
            out["selected"] = int(r.get("selected", -1))
        if r.get("confirm"):
            out["confirm"] = str(r["confirm"])
        if r.get("color"):
            out["danger"] = True
        if r.get("opens"):
            out["opens"] = str(r["opens"])
    return out


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16
    remote = None


class _Handler(BaseHTTPRequestHandler):
    server_version = "TideView"
    sys_version = ""
    timeout = 20  # seconds a phone may take to send its request

    def log_message(self, fmt, *args):  # keep the journal quiet
        log.debug("%s %s", self.client_address[0], fmt % args)

    def do_GET(self):  # noqa: N802
        self._handle("GET")

    def do_POST(self):  # noqa: N802
        self._handle("POST")

    def do_HEAD(self):  # noqa: N802
        self._reply(405, b"", "text/plain")

    def _handle(self, method):
        remote = self.server.remote
        path = self.path.split("?", 1)[0].split("#", 1)[0]
        try:
            if path in ("/", "/index.html") and method == "GET":
                return self._page()
            if path == "/favicon.ico":
                return self._reply(404, b"", "text/plain")
            if path == "/api/info" and method == "GET":
                return self._json(200, remote.info())
            if not path.startswith("/api/"):
                return self._json(404, {"error": "Not found."})
            ip = self.client_address[0]
            if remote.locked_out(ip):
                return self._json(429, {"error": "Too many wrong codes. Wait a minute, then try again."})
            if not remote.pairing.check(self.headers.get("X-TideView-Code", "")):
                remote.wrong_code(ip)
                return self._json(401, {"error": "That code isn't right (or the phones were unlinked). "
                                                 "Scan the code on the TideView again."})
            body = self._body() if method == "POST" else {}
            phone = self.headers.get("X-TideView-Phone", "")
            self._json(200, remote.handle(method, path, body, phone))
        except BadRequest as e:
            self._json(400, {"error": str(e)})
        except NotFound as e:
            self._json(404, {"error": str(e)})
        except TimeoutError:
            self._json(503, {"error": "TideView is busy. Try again in a moment."})
        except Busy as e:
            self._json(503, {"error": str(e)})
        except (BrokenPipeError, ConnectionError):
            pass
        except Exception as e:  # noqa: BLE001
            log.exception("phone request %s %s failed", method, path)
            try:
                self._json(500, {"error": "Something went wrong on the TideView: %s" % e})
            except Exception:  # noqa: BLE001
                pass

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise BadRequest("Bad length.") from None
        if n < 0 or n > MAX_BODY:
            raise BadRequest("Too big.")
        raw = self.rfile.read(n) if n else b""
        if not raw.strip():
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise BadRequest("That isn't JSON.") from None
        if not isinstance(data, dict):
            raise BadRequest("Send a JSON object.")
        return data

    def _page(self):
        try:
            with open(WEB_PAGE, "rb") as f:
                data = f.read()
        except OSError:
            data = b"<!doctype html><title>TideView</title><p>Use the TideView app on your phone.</p>"
        self._reply(200, data, "text/html; charset=utf-8")

    def _json(self, status, obj):
        self._reply(status, json.dumps(obj).encode("utf-8"), "application/json")

    def _reply(self, status, data, ctype):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if data:
            self.wfile.write(data)
